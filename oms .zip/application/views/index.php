<!DOCTYPE html>
<html lang="zxx">
<head>
    <!-- End Google Tag Manager -->
    <title>KRH Occupancy Management System</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="UTF-8">
    <!-- External CSS libraries -->
    <link type="text/css" rel="stylesheet" href="<?php echo base_url() ?>assetes/vendor/css/bootstrap.min.css">
    <link type="text/css" rel="stylesheet" href="<?php echo base_url() ?>assetes/vendor/fonts/font-awesome/css/font-awesome.min.css">
    <link type="text/css" rel="stylesheet" href="<?php echo base_url() ?>assetes/vendor/fonts/flaticon/font/flaticon.css">

    <!-- Favicon icon -->
    <link rel="shortcut icon" href="home_assets/img/favicon.ico" type="image/x-icon" >

    <!-- Google fonts -->
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800%7CPoppins:400,500,700,800,900%7CRoboto:100,300,400,400i,500,700">

    <!-- Custom Stylesheet -->
    <link type="text/css" rel="stylesheet" href="<?php echo base_url() ?>assetes/vendor/css/style.css">
    <link rel="stylesheet" type="text/css" id="style_sheet" href="<?php echo base_url() ?>assetes/vendor/css/skins/default.css">
    <style type="text/css">
<!--
.style1 {
	color: #FFFFFF;
	font-size: 24px;
}

-->
    </style>
</head>
<body id="top">
<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-TAGCODE"
                  height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
<div class="page_loader"></div>

<!-- Login 20 start -->
<div class="login-20">
    <div class="container-fluid">
        <div class="row">
            <div class="col-xl-4 col-lg-5 col-md-12 bg-color-10">
                <div class="form-section">
                    <div class="clearfix logo style1"><strong>
                        
                          KRH                    </strong></div>
                    <h3 class="style1">Occupancy Management System</h3>
                    
                    <div class="extra-login clearfix">
                        <span>OMS LOGIN</span>
                    </div>
                    
                <?php if ($this->session->flashdata('adminnotlogin')): ?>
                 <div class="alert text-white bg-danger alert-dismissible" role="alert">
                 <div class="iq-alert-text"> <?php echo $this->session->flashdata('adminnotlogin'); ?></div>
                 <button type="button" class="close" data-dismiss="alert">&times;</button>
                 <i class="ri-close-line"></i>
                 </button>
                 </div>
                <?php endif; ?>
                
                    <div class="login-inner-form">
                        <form  action="<?php echo base_url() ?>Userlogin/adminlogin"  method="post">
                            <div class="form-group form-box">
                                <input type="email" name="email" class="input-text" placeholder="Email Address" required>
                                <i class="flaticon-mail-2"></i>
                            </div>
                            <div class="form-group form-box">
                                <input type="password" name="password" class="input-text" placeholder="Password" required>
                                <i class="flaticon-key"></i>
                            </div>
                            <div class="checkbox clearfix">
                                <div class="form-check checkbox-theme">
                                    <input class="form-check-input" type="checkbox" value="" id="rememberMe">
                                    <label class="form-check-label" for="rememberMe">
                                        Remember me
                                    </label>
                                </div>
                                <!--<a href="forgot-password-20.html">Forgot Password</a>-->
                            </div>
                            <div class="form-group">
                                <button type="submit" class="btn-md btn-theme btn-block">Login</button>
                            </div>
                        </form>
                    </div>
                    
                </div>
            </div>
            <div class="col-xl-8 col-lg-7 col-md-12 none-992" style="background-image:url(<?php echo base_url() ?>assetes/vendor/img/rightbanner.png)">
                <div class="info">
                    <h1></h1>
                    <p></p>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Login 20 end -->

<!-- External JS libraries -->
<script src="<?php echo base_url() ?>assetes/vendor/js/jquery-2.2.0.min.js"></script>
<script src="<?php echo base_url() ?>assetes/vendor/js/popper.min.js"></script>
<script src="<?php echo base_url() ?>assetes/vendor/js/bootstrap.min.js"></script>
<!-- Custom JS Script -->
</body>
</html>