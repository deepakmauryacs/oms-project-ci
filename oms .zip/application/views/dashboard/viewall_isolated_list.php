<!-- start page content -->
<style type="text/css">
	.card-head{
		line-height: 17px;
	}
</style>
			 <div class="page-content-wrapper">
				<div class="page-content">
					<div class="page-bar">
						<div class="page-title-breadcrumb">
							<div class=" pull-left">
								<div class="page-title">Dashboard</div>
							</div>
							<ol class="breadcrumb page-breadcrumb pull-right">
								<li><i class="fa fa-home"></i>&nbsp;<a class="parent-item"
										href="#">Home</a>&nbsp;<i class="fa fa-angle-right"></i>
								</li>
								<li class="active">Dashboard</li>
							</ol>
						</div>
					</div>
					
		     

					<!-- start widget -->
		 <div class="state-overview">
	         <div class="row">
	           <div class="col-md-12">
	             <div class="page-title center">Isolated Guest list</div>
	           </div>
             <div class="col-md-12 col-sm-12">
			 <div class="card card-topline-yellow">
			   <?php if ($this->session->flashdata('success')): ?>
             <div class="alert text-white bg-success alert-dismissible" role="alert">
             <div class="iq-alert-text"><?php echo $this->session->flashdata('success'); ?></div>
             <button type="button" class="close" data-dismiss="alert">&times;</button>
             <i class="ri-close-line"></i>
           
             </div>
             <?php endif; ?>


			 <?php if ($this->session->flashdata('update')): ?>
             <div class="alert text-white bg-success alert-dismissible" role="alert">
             <div class="iq-alert-text"><?php echo $this->session->flashdata('update'); ?></div>
             <button type="button" class="close" data-dismiss="alert">&times;</button>
             <i class="ri-close-line"></i>
           
             </div>
             <?php endif; ?>

             <?php if ($this->session->flashdata('delete')): ?>
             <div class="alert text-white bg-danger alert-dismissible" role="alert">
             <div class="iq-alert-text"> <?php echo $this->session->flashdata('delete'); ?></div>

             <button type="button" class="close" data-dismiss="alert">&times;</button>
             <i class="ri-close-line"></i>
             </div>
            <?php endif; ?>
										<div class="card-head">
											<header style="font-size: 15px;">Search Isolated Guests list </header>
										   <div class="container"> 

										   	<div class="row">
										  		 <div class="form-group col-md-3" style="display: none;">
											    	<label> Status</label>
											    	 <select class="form-control filter" id="status">
											    	 	<option value="">All</option>
											    	 	<option value="1">Checked In</option>
											    	 
											    	 </select>
											    </div>

											    <div class="form-group col-md-3">
											    	<label> Building </label>
											    	<div class="form-row">
											    	<select class="form-control filter" onchange="get_appartment(this.value);" id="building">
											    	 	<option value="">All</option>
											    	 	<?php foreach($buildings as $building){ ?>
											    	 	<option value="<?php  echo $building->id; ?>"><?php echo  $building->building_name; ?></option>
											    	 	<?php } ?>
											    	 </select>
											    	</div>
											    </div>

											    <div class="form-group col-md-3">
											    	<label> Apartment </label>
											    	<div class="form-row">
											    	   <select class="form-control filter" id="Appartments">
											    	 	<option value="">All</option>
											    	   </select>
											    	</div>
											    </div>

											     <div class="form-group col-md-3">
											    	
											    	<div class="form-row">
											    		<div class="form-group col-6">
											    			<label> Gender </label>
											    			  <select class="form-control filter" id="gender">
													    	 	<option value="">All</option>
													    	 	<option value="Male">Male</option>
													    	 	<option value="Female">Female</option>
													    	   </select>
											    		</div>
											    		<div class="form-group col-6">
											    			<label> Food Type </label>
											    			<select class="form-control filter" id="food_type">
													    	 	<option value="">All</option>
													    	 	<option value="Veg">Veg</option>
													    	 	<option value="Non-Veg">Non-Veg</option>
													    	   </select>
											    		</div>
											    	</div>
											    </div>


										  	</div>


										      <div class="row">
										  		 

											    <div class="form-group col-md-6">
											    	<label>Scheduled Exit Date </label>
											    	<div class="form-row">
											    		<div class="form-group col-6">
											    			<label>From</label>
											    			<input type="date"  class="form-control filter" id="scheduled_from">
											    		</div>
											    		<div class="form-group col-6">
											    			<label>To</label>
											    			<input type="date"  class="form-control filter"  id="scheduled_end" >
											    		</div>
											    	</div>
											    </div>


										  	</div>
                                           </div>
										   
										</div>
										<div class="card-body " style="">
											<div class="table-scrollable">
												 <table class="table table-bordered display full-width" id="data_list">
													<thead>
														<tr>
															<th>SL#</th>
															<th><div style="width: 66px;">Guest id</div></th>
															<th>Name</th>
															<th>Building</th>
															<th>Appartment</th>
															<th>Room</th>
															<th>Gender</th>
															<th><div style="width: 125px;">Contact Number</div></th>
															<th><div style="width: 125px;">Passport Number</div></th>
															<th><div style="width: 125px;">Civilid Number</div></th>
															<th>Nationality</th>
															<th><div style="width: 125px;">food Preference</div></th>
															<th>Flight</th>
															<th><div style="width: 125px;">Blood Group</div></th>
															<th><div style="width: 125px;">Sponsor Phone</div></th>
															<th><div style="width: 170px;">Emergency Con Num<div style="width: 75px;"></th>
															<th><div style="width: 225px;">Emergency Con Relationship</div></th>
															<th>Status</th>
															<th><div style="width: 125px;">Reserved Date</div></th>
															<th><div style="width: 145px;">Checked In Date</div></th>
															<th><div style="width: 140px;">Remaining Quarantine Days</div></th>
															<th><div style="width: 200px;">Scheduled Exit Date</div></th>
															<th><div style="width: 125px;">Isolation Status</div></th>
															<th><div style="width: 145px;">Checked Out Date</div></th>
															<th><div style="width: 125px;">Remark</div></th>
															<th>Action</th>
															
															
														</tr>
													</thead>
													<tbody>
													</tbody>
												</table>
											</div>
										</div>
									</div>
								</div>
						</div>
					
   </div>
</div>

  

 <!--------------------CheckIn popup end----------------------------->
<script type="text/javascript">
$(document).ready(function(){

  fill_datatable();
  
  function fill_datatable()
  {

  	var scheduled_from=$('#scheduled_from').val();
  	var scheduled_end=$('#scheduled_end').val();
    var start_from=$('#start_from').val();
    var end_form=$('#end_form').val();
    var start_to=$('#start_to').val();
    var end_to=$('#end_to').val();
    var arrival_from=$('#arrival_from').val();
    var arrival_to=$('#arrival_to').val();
    var food_type=$('#food_type').val();
    var gender=$('#gender').val();
    var Appartments=$('#Appartments').val();
    var building=$('#building').val();
    var status=$('#status').val();
    
   var dataTable = $('#data_list').DataTable({
    "destroy": false,
    "processing" : true,
    "serverSide" : false,
    "searching" : true,
    "order" : [],
    "dom": 'Bfrtip',
    "buttons": ['excelHtml5'],
    "ajax" : {
     url:"<?php echo base_url('Admin/Isolated/getBookingList');?>",
     type:"POST",
     data:{
       scheduled_from:scheduled_from,scheduled_end:scheduled_end,start_from:start_from, end_form:end_form,start_to:start_to,end_to:end_to,arrival_from,arrival_to,food_type,gender,Appartments,building,status
     }
    }
   });
   
  }
  
  $('.filter').on('change',function(){
    $('#data_list').DataTable().destroy();
    fill_datatable();
  });
});

	$(document).ready(function(){
        $('.buildings').click(function(){
        	let buildingsids='';

        	$( ".buildings" ).each(function( index ) {
    		 if($(this).prop("checked") == true){
       	    	if(index>0)
       	    	{
       	    		buildingsids +=',';
       	    	}
       	    	buildingsids += $( this ).val();
       		 }
			});

        	$.ajax({
		           type: "POST",
		           url: '<?php echo base_url();?>Admin/Dashoard_room/get_appartment',
		           data: {buildingsids:buildingsids}, // serializes the form's elements.
		           beforeSend:function()
					{
						
					},
					success:function(responce)
					{
						$('#Appartments').html(responce);
					},
					error:function()
					{
						alert('Error');
						
					},
					complete:function()
					{
						
					}
		        });	
        });
        //=============================
        //Atul
        $("#checkin_date").on('change', function(){

        });
    });

   

    function get_appartment(id)
    {
    	$.ajax({
		           type: "POST",
		           url: '<?php echo base_url();?>Admin/Add_room/get_appartment',
		           data: {id:id}, // serializes the form's elements.
		           beforeSend:function()
					{
						
					},
					success:function(responce)
					{
						$('#Appartments').html(responce);
					},
					error:function()
					{
						alert('Error');
						
					},
					complete:function()
					{
						
					}
		        });	
    }
	
	function check_in_user(id)
	{
		$('#room_id_popup').val(id);
		$('#checkinModal').modal('show');
	}

</script>
		