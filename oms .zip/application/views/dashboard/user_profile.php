
			<!-- start page content -->
			<div class="page-content-wrapper">
				<div class="page-content">
					<div class="page-bar">
						<div class="page-title-breadcrumb">
							<div class=" pull-left">
								<div class="page-title">User Profile</div>
							</div>
							<ol class="breadcrumb page-breadcrumb pull-right">
								<li><i class="fa fa-home"></i>&nbsp;<a class="parent-item"
										href="index.html">Home</a>&nbsp;<i class="fa fa-angle-right"></i>
								</li>
								<li><a class="parent-item" href="#">Profile</a>&nbsp;<i class="fa fa-angle-right"></i>
								</li>
								<li class="active">User Profile</li>
							</ol>
						</div>
					</div>
					<?php if ($this->session->flashdata('update')): ?>
                       <div class="offset-3 col-md-6 sub_category_id alert text-white bg-success alert-dismissible" role="alert">
                      <div class="iq-alert-text"><?php echo $this->session->flashdata('update'); ?></div>
                      <button type="button" class="close" data-dismiss="alert">&times;</button>
                      <i class="ri-close-line"></i>
                      </div>
                    <?php endif; ?>

					<div class="row">
						<div class="offset-3 col-md-6">
							                <?php 

							                foreach ($h as $key => $value) {
							                 	
							                 
                                             
                                             ?>
							<!-- BEGIN PROFILE SIDEBAR -->
							<div class="profile-sidebar">
								
							
							</div>

							<?php
					      	}
						     ?>
							<!-- END BEGIN PROFILE SIDEBAR -->
							<!-- BEGIN PROFILE CONTENT -->
							<div class="profile-content">
							
					       <?php  

					            foreach ($h as $key => $value) {  
                             
                           ?>
									<div class="card">
										<div class="card-body no-padding height-9">
												<div class="row">
													<div class="col-md-12 col-sm-12">
															<header>User Details</header>
														</div>
														<div class="card-body " id="bar-parent1">
															 <form action="<?php echo base_url('Admin/Admin/update_user_profile');?>" method="post"  role="form" enctype="multipart/form-data">
															     
															     
								         <div class="form-group">
                                            
                       
                       

										

																<div class="form-group">
																	<label for="simpleFormEmail">User Name</label>
																	<input type="text" name="username" class="form-control" 
                                                                     value="<?php echo $value['username']; ?>" >
                                                                     <input type="hidden" name="id" value="<?php echo $value['id']; ?>">
																</div>
																<div class="form-group">
																	<label for="simpleFormPassword">Email </label>
																	<input type="email" name="email" class="form-control"
																		id="simpleFormPassword"
																		value="<?php echo $value['email']; ?>" >
																</div>
															
																<button type="submit"
																	class="btn btn-primary">Update</button>
															</form>
														</div>
													</div>
												</div>
											</div>
								<?php
							     }
							    ?>
										</div>
									</div>
								</div>
							</div>
							<!-- END PROFILE CONTENT -->
						</div>
					</div>
				
				<!-- end page content -->
				