
      <!-- start page content -->
      <div class="page-content-wrapper">
        <div class="page-content">
          <div class="page-bar">
            <div class="page-title-breadcrumb">
              <div class=" pull-left">
                <div class="page-title">Terms & Conditions</div>
              </div>
              <ol class="breadcrumb page-breadcrumb pull-right">
                <li><i class="fa fa-home"></i>&nbsp;<a class="parent-item"
                    href="index.html">Home</a>&nbsp;<i class="fa fa-angle-right"></i>
                </li>
                <li><a class="parent-item" href="#">Index</a>&nbsp;<i class="fa fa-angle-right"></i>
                </li>
                <li class="active">Update Terms & Conditions</li>
              </ol>
            </div>
          </div>
          <div class="row">
                 <div class="offset-1 col-md-10 col-sm-10">          
                    <div class="card card-topline-yellow">
                       <?php if ($this->session->flashdata('update')): ?>
                       <div class="alert text-white bg-success alert-dismissible" role="alert">
                      <div class="iq-alert-text"><?php echo $this->session->flashdata('update'); ?></div>
                      <button type="button" class="close" data-dismiss="alert">&times;</button>
                      <i class="ri-close-line"></i>
                      </div>
                      <?php endif; ?>

                    <div class="card-head">
                      <header> Terms & Conditions </header>
                      <div class="tools">
                        <a class="fa fa-repeat btn-color box-refresh" href="javascript:;"></a>
                        <a class="t-collapse btn-color fa fa-chevron-down" href="javascript:;"></a>
                        <a class="t-close btn-color fa fa-times" href="javascript:;"></a>
                      </div>
                    </div>
                    <div class="card-body " style="">
                      <?php  
                        $i=1;
                        foreach ($h as $row)  
                        {  
                      ?>
                       <form action="<?php echo base_url('Admin/Add_terms_and_conditions/update_terms_and_conditions');?>" method="post"  role="form" enctype="multipart/form-data">
                        <div class="form-group">
                        <label for="Product Category">Terms & Conditions</label>
                         <textarea name="description" class="ckeditor" rows="3">  
                           <?php echo $row->description; ?>                    
                         </textarea>
                          <input type="hidden" name="id" value="<?=$row->id?>"> 
                         </div>
                         <button type="submit" class="btn btn-primary">Update</button>
                       </form>
                       <?php
                        }
                        ?>
                  </div>
                 </div>
               </div>
             </div>
          </div>
       </div>





