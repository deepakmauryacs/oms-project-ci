<!DOCTYPE html>
<html lang="en">
<!-- BEGIN HEAD -->
<head>
	<meta charset="utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta content="width=device-width, initial-scale=1" name="viewport" />
	<meta name="description" content="Responsive Admin Template" />
	<meta name="author" content="SmartUniversity" />
	<title>Occupancy Management System</title>
	<!-- icons -->
	<link href="<?php echo base_url() ?>assetes/dashboard/assets/plugins/simple-line-icons/simple-line-icons.min.css" rel="stylesheet" type="text/css" />
	<link href="<?php echo base_url() ?>assetes/dashboard/assets/plugins/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
	<!--bootstrap -->
	<link href="<?php echo base_url() ?>assetes/dashboard/assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
	<link href="<?php echo base_url() ?>assetes/dashboard/assets/plugins/summernote/summernote.css" rel="stylesheet">

    <script src="<?php echo base_url() ?>assetes/dashboard/assets/plugins/jquery/jquery.min.js"></script>


	<!-- morris chart -->
	<link href="<?php echo base_url() ?>assetes/dashboard/assets/plugins/morris/morris.css" rel="stylesheet" type="text/css" />
	<!-- Material Design Lite CSS -->
	<link rel="stylesheet" href="<?php echo base_url() ?>assetes/dashboard/assets/plugins/material/material.min.css">
	<link rel="stylesheet" href="<?php echo base_url() ?>assetes/dashboard/assets/css/material_style.css">
	<!-- animation -->
	<link href="<?php echo base_url() ?>assetes/dashboard/assets/css/pages/animate_page.css" rel="stylesheet">
	<!-- Template Styles -->
	<link href="<?php echo base_url() ?>assetes/dashboard/assets/css/plugins.min.css" rel="stylesheet" type="text/css" />
	<link href="<?php echo base_url() ?>assetes/dashboard/assets/css/style.css" rel="stylesheet" type="text/css" />
	<link href="<?php echo base_url() ?>assetes/dashboard/assets/css/responsive.css" rel="stylesheet" type="text/css" />
	<link href="<?php echo base_url() ?>assetes/dashboard/assets/css/theme-color.css" rel="stylesheet" type="text/css" />
	<!-- favicon -->



	 <!-- dropzone -->
    <link href="<?php echo base_url() ?>assetes/dashboard/assets/plugins/dropzone/dropzone.css" rel="stylesheet" media="screen">
    <!--tagsinput-->
    <link href="<?php echo base_url() ?>assetes/dashboard/assets/plugins/jquery-tags-input/jquery-tags-input.css" rel="stylesheet">
    <!--select2-->
    <link href="<?php echo base_url() ?>assetes/dashboard/assets/plugins/select2/css/select2.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo base_url() ?>assetes/dashboard/assets/plugins/select2/css/select2-bootstrap.min.css" rel="stylesheet" type="text/css" />
     
     
     <link href="https://cdn.datatables.net/1.10.22/css/jquery.dataTables.min.css" rel="stylesheet" type="text/css" />
    <link href="https://cdn.datatables.net/buttons/1.6.5/css/buttons.dataTables.min.css" rel="stylesheet" type="text/css" />
 	<link rel="shortcut icon" href="<?php echo base_url() ?>assetes/dashboard/assets/img/favicon.ico" />

	 <!-- <script src="https://cdn.ckeditor.com/4.14.0/standard/ckeditor.js"></script> -->
	 <script src="//cdn.ckeditor.com/4.15.0/full/ckeditor.js"></script>
	  <style type="text/css">
		 	.page-content-wrapper .page-content .cus-form label {
	         font-size: 12px;
	          }

			.page-content-wrapper .page-content .cus-form {
			    margin-bottom: 15px;
			    border: 1px solid #000;
			    padding: 2px 2px 2px 26px;
			}
	 </style>
	 	<!-- data tables -->
    <!--<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/bs4/dt-1.10.22/b-1.6.5/b-html5-1.6.5/b-print-1.6.5/datatables.min.css"/>-->
 
<!--<script type="text/javascript" src="https://cdn.datatables.net/v/bs4/dt-1.10.22/b-1.6.5/b-html5-1.6.5/b-print-1.6.5/datatables.min.js"></script>-->
</head>
<!-- END HEAD -->

<body
	class="page-header-fixed sidemenu-closed-hidelogo page-content-white page-md header-white dark-sidebar-color logo-dark">
	<div class="page-wrapper">
		<!-- start header -->
		<div class="page-header navbar navbar-fixed-top">
			<div class="page-header-inner ">
				<!-- logo start -->
				<div class="page-logo" style="background: #eaeef3;">
					<a href="<?php echo base_url() ?>/Admin/Admin">
						<img alt="" src="<?php echo base_url() ?>assetes/dashboard/login/img/login_logo.png" style="height: 48px;">
						<!-- <span class="logo-default">OMS</span> -->  </a>
				</div>
				<!-- logo end -->

				<ul class="nav navbar-nav navbar-left in">
					<li><a href="#" class="menu-toggler sidebar-toggler"><i class="icon-menu"></i></a></li>
				</ul>




				<!--<form class="search-form-opened" action="#" method="GET">-->
				<!--	<div class="input-group">-->
				<!--		<input type="text" class="form-control" placeholder="Search..." name="query">-->
				<!--		<span class="input-group-btn search-btn">-->
				<!--			<a href="javascript:;" class="btn submit">-->
				<!--				<i class="icon-magnifier"></i>-->
				<!--			</a>-->
				<!--		</span>-->
				<!--	</div>-->
				<!--</form>-->

                 

				<!-- start mobile menu -->
				<a href="javascript:;" class="menu-toggler responsive-toggler" data-toggle="collapse"
					data-target=".navbar-collapse">
					<span></span>
				</a>
				<!-- end mobile menu -->
				<!-- start header menu -->
				<div class="top-menu">

					
					<ul class="nav navbar-nav pull-right">
						<!-- start notification dropdown -->
						
						<!-- end message dropdown -->
						<!-- start manage user dropdown -->
						<li class="dropdown dropdown-user">
						      <?php 
                                     $data=$this->db->get_where('admin')->result_array();
                                       foreach ($data as $key => $value) {
                                      ?>
							<a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown"
								data-close-others="true">
								
								<span class="username username-hide-on-mobile"> <?php echo $value['username']; ?> </span>
								<i class="fa fa-angle-down"></i>
							</a>
							  <?php
                                       }
                                ?>
							<ul class="dropdown-menu dropdown-menu-default animated jello">
								<li>
									<a href="<?php echo base_url() ?>Admin/Admin/user_profile">
										<i class="icon-user"></i> Profile </a>
								</li>
								
							
								<li class="divider"> </li>
								<li>
									<a href="<?php echo base_url() ?>Admin/Admin/user_password">
										<i class="icon-lock"></i> Settings
									</a>
								</li>
								<li>
									<a href="<?php echo base_url() ?>/Admins/logout">
										<i class="icon-logout"></i> Log Out </a>
								</li>
							</ul>
						</li>
						<!-- end manage user dropdown -->
					</ul>
				</div>
			</div>
		</div>
		<!-- end header -->
		<!-- start page container -->
		<div class="page-container">
			<!-- start sidebar menu -->
			<div class="sidebar-container">
				<div class="sidemenu-container navbar-collapse collapse fixed-menu">
					<div id="remove-scroll">
						<ul class="sidemenu page-header-fixed p-t-20" data-keep-expanded="false" data-auto-scroll="true"
							data-slide-speed="200">
							<li class="sidebar-toggler-wrapper hide">
								<div class="sidebar-toggler">
									<span></span>
								</div>
							</li>
							<li class="sidebar-user-panel">
							    
								<div class="user-panel">
								    
								    <?php 
                                     $data=$this->db->get_where('admin')->result_array();
                                       foreach ($data as $key => $value) {
                                      ?>
			
									<div class="profile-usertitle">
										<div class="sidebar-userpic-name">  <?php echo $value['username']; ?> </div>
										<div class="profile-usertitle-job"> Administrator </div>
									</div>
									
									<?php
                                       }
                                    ?>
								</div>
							</li>
							<li class="menu-heading">
								<span> ----- Main -----</span>
							</li>
							<li class="nav-item start active">
								<a href="<?php echo base_url() ?>Admin/Admin" class="nav-link nav-toggle">
									<i class="material-icons">dashboard</i>
									<span class="title">Dashboard</span>
									<span class="selected"></span>
								</a>
							</li>
                           
							<?php
								if($this->session->userdata('usertype') == 'admin'){
							?> 
							 <li class="nav-item">
								<a href="#" class="nav-link nav-toggle">
									<i class="fa fa-home"></i>
									<span class="title">Building Managment</span>
									<span class="arrow"></span>
								</a>
								<ul class="sub-menu">
									


									<li class="nav-item">
										<a href="<?php echo base_url() ?>Admin/Add_building_name" class="nav-link ">
											<i class="fa fa-home"></i>
											<span class="title">Add  Building </span>
										</a>
									</li>

									<li class="nav-item">
										<a href="<?php echo base_url() ?>Admin/Add_sub_category" class="nav-link ">
											<i class="fa fa-home"></i>
											<span class="title">Add Floor</span>
										</a>
									</li>


									<li class="nav-item">
										<a href="<?php echo base_url() ?>Admin/Add_apartment" class="nav-link ">
											<i class="fa fa-home"></i>
											<span class="title">Add Apartment</span>
										</a>
									</li>

									<li class="nav-item">
										<a href="<?php echo base_url() ?>Admin/Add_room" class="nav-link ">
											<i class="fa fa-home"></i>
											<span class="title">Add Room</span>
										</a>
									</li>

									

									
								</ul>
							</li>


							<li class="nav-item">
								<a href="#" class="nav-link nav-toggle">
									<i class="fa fa-home"></i>
									<span class="title">Apartment Chart</span>
									<span class="arrow"></span>
								</a>
								<ul class="sub-menu">
									
                                   <?php 
                                   $data=$this->db->get_where('tbl_building')->result_array();
                                   foreach ($data as $key => $value) {
                                  ?>


									<li class="nav-item buildings">
										<a href="<?php echo base_url() ?>Admin/Dashoard_room/cardlist/<?php  echo $value['id']; ?>" class="nav-link ">
											<i class="fa fa-home"></i>
											<span class="title"> <?php  echo $value['building_name']; ?> </span>
										</a>
									</li>

									<?php
								      }
								   ?>
									
								</ul>
							</li>
                        


						    <li class="nav-item">
								<a href="<?php echo base_url() ?>Admin/Add_room/check_in" class="nav-link nav-toggle"> 
									<i class="fa fa-users"></i>
									<span class="title">CheckIn Form</span>
								</a>
							</li>
							
							<!---Guest Managment--->
							 <li class="nav-item">
								<a href="#" class="nav-link nav-toggle">
									<i class="fa fa-users"></i>
									<span class="title">Guest Managment</span>
									<span class="arrow"></span>
								</a>
								<ul class="sub-menu">
									
                                    	<li class="nav-item">
								<a href="<?php echo base_url() ?>Admin/Add_room/viewallguest" class="nav-link nav-toggle"> 
									<i class="fa fa-users"></i>
									<span class="title">All Guest</span>
								</a>
							</li>
							
							<li class="nav-item">
								<a href="<?php echo base_url() ?>Admin/Reserved" class="nav-link nav-toggle"> 
									<i class="fa fa-users"></i>
									<span class="title"> Reserved  Guests</span>
								</a>
							</li>

                           
			               <li class="nav-item">
								<a href="<?php echo base_url() ?>Admin/Cancelled" class="nav-link nav-toggle"> 
									<i class="fa fa-users"></i>
									<span class="title"> Cancelled  Guests</span>
								</a>
							</li>

							

						    <li class="nav-item">
								<a href="<?php echo base_url() ?>Admin/Check_in/view_checkin" class="nav-link nav-toggle"> 
									<i class="fa fa-users"></i>
									<span class="title"> Checked In Guests</span>
								</a>
							</li>

						    <li class="nav-item">
								<a href="<?php echo base_url() ?>Admin/Check_out" class="nav-link nav-toggle"> 
									<i class="fa fa-users"></i>
									<span class="title">Checked Out Guests</span>
								</a>
							 </li>
							 
							 
							<li class="nav-item">
								<a href="<?php echo base_url() ?>Admin/Isolated/view_isolated" class="nav-link nav-toggle"> 
									<i class="fa fa-users"></i>
									<span class="title">Isolated Guests</span>
								</a>
							</li>

							 
							 
							</ul>
						</li>

							
							<!---End -->
							
							
							
						

					    	<?php
							}else{
							?>
				
                            
							<li class="nav-item">
								<a href="#" class="nav-link nav-toggle">
									<i class="fa fa-home"></i>
									<span class="title">Appartment Chart</span>
									<span class="arrow"></span>
								</a>
								<ul class="sub-menu">
									
                                   <?php 
                                   $data=$this->db->get_where('tbl_building')->result_array();
                                   foreach ($data as $key => $value) {
                                  ?>


									<li class="nav-item buildings">
										<a href="<?php echo base_url() ?>Admin/Dashoard_room/cardlist/<?php  echo $value['id']; ?>" class="nav-link ">
											<i class="fa fa-home"></i>
											<span class="title"> <?php  echo $value['building_name']; ?> </span>
										</a>
									</li>

									<?php
								      }
								   ?>
									
								</ul>
							</li>
							 <li class="nav-item">
								<a href="<?php echo base_url() ?>Admin/Add_room/check_in" class="nav-link nav-toggle"> 
									<i class="fa fa-users"></i>
									<span class="title">CheckIn Form</span>
								</a>
							</li>
							
							 	<!---Guest Managment--->
							 <li class="nav-item">
								<a href="#" class="nav-link nav-toggle">
									<i class="fa fa-users"></i>
									<span class="title">Guest Managment</span>
									<span class="arrow"></span>
								</a>
								<ul class="sub-menu">
									
                                    	<li class="nav-item">
								<a href="<?php echo base_url() ?>Admin/Add_room/viewallguest" class="nav-link nav-toggle"> 
									<i class="fa fa-users"></i>
									<span class="title">All Guest</span>
								</a>
							</li>
							
							<li class="nav-item">
								<a href="<?php echo base_url() ?>Admin/Reserved" class="nav-link nav-toggle"> 
									<i class="fa fa-users"></i>
									<span class="title"> Reserved  Guests</span>
								</a>
							</li>

                           
			               <li class="nav-item">
								<a href="<?php echo base_url() ?>Admin/Cancelled" class="nav-link nav-toggle"> 
									<i class="fa fa-users"></i>
									<span class="title"> Cancelled  Guests</span>
								</a>
							</li>

							

						    <li class="nav-item">
								<a href="<?php echo base_url() ?>Admin/Check_in/view_checkin" class="nav-link nav-toggle"> 
									<i class="fa fa-users"></i>
									<span class="title"> Checked In Guests</span>
								</a>
							</li>

						    <li class="nav-item">
								<a href="<?php echo base_url() ?>Admin/Check_out" class="nav-link nav-toggle"> 
									<i class="fa fa-users"></i>
									<span class="title">Checked Out Guests</span>
								</a>
							</li>
							
							
							<li class="nav-item">
								<a href="<?php echo base_url() ?>Admin/Isolated/view_isolated" class="nav-link nav-toggle"> 
									<i class="fa fa-users"></i>
									<span class="title">Isolated Guests</span>
								</a>
							</li>

							 
							 
							</ul>
						</li>

							
							<!---End -->

							<?php
						}

						?>


						     





							<li class="nav-item">
								<a href="<?php echo base_url() ?>Admin/Add_privacy_policy" class="nav-link nav-toggle">
								<i class="fa fa-bank"></i>
									<span class="title">Privacy Policy</span>
								</a>
							</li>

							<li class="nav-item">
								<a href="<?php echo base_url() ?>Admin/Add_terms_and_conditions" class="nav-link nav-toggle"> 
									<i class="fa fa-legal"></i>
									<span class="title">Terms & Conditions</span>
								</a>
							</li>

						</ul>
					</div>
				</div>
			</div>
			<!-- end sidebar menu -->

