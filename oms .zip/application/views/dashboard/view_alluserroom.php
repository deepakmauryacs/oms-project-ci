
				<!-- start page content -->
				<div class="page-content-wrapper">
					<div class="page-content">
						<div class="page-bar">
							<div class="page-title-breadcrumb">
								<div class=" pull-left">
									<div class="page-title">Room List</div>
								</div>
								<ol class="breadcrumb page-breadcrumb pull-right">
									<li><i class="fa fa-home"></i>&nbsp;<a class="parent-item"
											href="#">Home</a>&nbsp;<i class="fa fa-angle-right"></i>
									</li>
									<li><a class="parent-item" href="#">Room</a>&nbsp;<i class="fa fa-angle-right"></i>
									</li>
									<li class="active">Add Room</li>
								</ol>
							</div>
						</div>
						
						


	  <div class="row">
       <div class="col-md-4 col-sm-4">
           <div class="row">
            <div class="col-md-12">
           	  <h3> Building </h3>
           	</div>
             
           	    <?php  
                    foreach ($building as $rowa)  
                      {  
                ?>
           	  
              <div class="col-md-3">
                 <!-- <p><?php echo $rowa->building_name; ?></p> -->
                 <div class="form-group form-check">
				    <input type="radio" class="form-check-input buildings" name="buildings" id="exampleCheck1<?php echo $rowa->id; ?>" value="<?php echo $rowa->id; ?>" >
				    <label class="form-check-label" for="exampleCheck1<?php echo $rowa->id; ?>"><?php echo $rowa->building_name; ?></label>
				  </div>
              </div>

              <?php
              }
              ?>
              
           </div>
       </div>

       <div class="col-md-4 col-sm-4">
       	    <div class="col-md-12">
             <h3> Floor  </h3>
            </div>
            <div class="row" id="Floors">
              <div class="col-md-12">
                Select atliest one building. 
              </div>
           
           </div>
       </div>

       <div class="col-md-4 col-sm-4">
           <div class="row" 
             >
           	  <div class="col-md-12">
           	    <h3> Apartments </h3>
           	 </div> 

           	 <div class="row" id="Apartments">
              <div class="col-md-12">
                Select atliest one floor.
              </div>
              </div>
           </div>
      
       </div>
     </div>
				
     <div class="row" id="get_rooms">
           <div class="col-lg-3 col-md-6 col-12 col-sm-6">
			 <h3>Available Rooms</h3>
		</div>
    </div>


		   	
					 	
	 </div>
</div>
<!---------------------CheckIn popup start----------------------------->
<div class="modal fade" id="checkinModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
<div class="modal-dialog  modal-lg">
         <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Checkin</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
          <div class="card-body " style="">
          <form action="<?php echo base_url('Admin/Add_user_room/Checkin');?>" method="post" role="form" enctype="multipart/form-data">

          	<div class="row">
	         

	           <div class="form-group col-md-6">
	            <label for="Product Category">Guest Id</label>
	            <input type="text" class="form-control" name="guest_id"  required>
	   
	          </div>

	           <div class="form-group col-md-6">
	            <label for="Product Category"> Name</label>
	            <input type="hidden" name="roomId" id="room_id_popup">
	            <input type="text" class="form-control" name="custmer_name"  required>
	           <input type="hidden" class="form-control" name="room_id" value="01" required>
	          </div>
              
               <div class="form-group col-md-6">
	            <label for="Product Category">Gender</label>
	            <select class="form-control" name="gender"  required>
	            	<option  value="Male"> Male</option>
	            	<option  value="Female"> Female</option>
	            </select>
	          </div>


	           <div class="form-group col-md-6">
	            <label for="Product Category">Contact Number</label>
	            <input type="text" class="form-control" name="contact_number"  required>
	          </div>

	          <div class="form-group col-md-6">
	            <label for="Product Category">Nationality</label>
	            <input type="text" class="form-control" name="nationality"  required>
	          </div>

	          <div class="form-group col-md-6">
	            <label for="Product Category">Passport Number</label>
	            <input type="text" class="form-control" name="passport_number"  required>
	          </div>

	           <div class="form-group col-md-6">
	            <label for="Product Category">Civil ID Number</label>
	            <input type="text" class="form-control" name="civilid_number"   required>
	          </div>

	           <div class="form-group col-md-6">
	            <label for="Product Category">Emergency Contact Number</label>
	            <input type="text" class="form-control" name="emergency_contact_number"   required>
	          </div>

	          <div class="form-group col-md-6">
	            <label for="Product Category">Emergency Contact Relationship</label>
	            <input type="text" class="form-control" name="emergency_contact_relationship"   required>
	          </div>

	           

	          <div class="form-group col-md-6">
	            <label for="Product Category">Enter Number of Bed </label>
	            <input type="Number" class="form-control" name="bed_count"  required>
	          </div>

	         </div>
	         <center>
               <button type="submit" class="btn btn-primary">Checkin</button>
            </center>
         </form>
            </div>
        </div>
    </div>
</div>
</div>


 <!--------------------CheckIn popup end----------------------------->
<script type="text/javascript">
	
	$(document).ready(function(){
        $('.buildings').click(function(){
        	let buildingsids='';

        	$( ".buildings" ).each(function( index ) {
    		 if($(this).prop("checked") == true){
       	    	if(index>0)
       	    	{
       	    		buildingsids +=',';
       	    	}
       	    	buildingsids += $( this ).val();
       		 }
			});

        	$.ajax({
		           type: "POST",
		           url: '<?php echo base_url();?>Admin/Add_user_room/get_floor',
		           data: {buildingsids:buildingsids}, // serializes the form's elements.
		           beforeSend:function()
					{
						
					},
					success:function(responce)
					{
						$('#Floors').html(responce);
					},
					error:function()
					{
						alert('Error');
						
					},
					complete:function()
					{
						
					}
		        });	
        	});
        //=============================

    });

    function get_apartments()
    {
    	let floorsids='';
    	$( ".floors" ).each(function( index ) {
    		 if($(this).prop("checked") == true){
       	    	if(index>0)
       	    	{
       	    		floorsids +=',';
       	    	}
       	    	floorsids += $( this ).val();
       		 }

			});
    	//alert (floorsids);
    	$.ajax({
		           type: "POST",
		           url: '<?php echo base_url();?>Admin/Add_user_room/get_apartments',
		           data: {floorsids:floorsids}, // serializes the form's elements.
		           beforeSend:function()
					{
						
					},
					success:function(responce)
					{
						$('#Apartments').html(responce);
					},
					error:function()
					{
						alert('Error');
						
					},
					complete:function()
					{
						
					}
		        });	
    }

    function get_rooms()
    {
    	 let floorsids='';
    	$( ".get_apartment" ).each(function( index ) {
    		 if($(this).prop("checked") == true){
       	    	if(index>0)
       	    	{
       	    		floorsids +=',';
       	    	}
       	    	floorsids += $( this ).val();
       		 }

			});
    	//alert (floorsids);
    	$.ajax({
		           type: "POST",
		           url: '<?php echo base_url();?>Admin/Add_user_room/get_rooms',
		           data: {appartmentid:floorsids}, // serializes the form's elements.
		           beforeSend:function()
					{
						
					},
					success:function(responce)
					{
						$('#get_rooms').html(responce);
					},
					error:function()
					{
						alert('Error');
						
					},
					complete:function()
					{
						
					}
		        });	
    }
	
	function check_in_user(id)
	{
		$('#room_id_popup').val(id);
		$('#checkinModal').modal('show');
	}

</script>