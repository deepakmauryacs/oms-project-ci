<div class="col-md-12">
		<!-- start widget -->
	<div class="state-overview">
		<div class="row">
			<?php 
			foreach ($building as $row)
			{
			 ?>
				
			<div class="col-xl-3 col-md-6 col-12">

				<a  href="<?php echo base_url() ?>Admin/Dashoard_room/cardlist/<?php  echo $row->id; ?>"  class="info-box" style="background-color:#e67d21e6;display: block;color: #fff;">

				<!-- <div class="info-box bg-blue" style="background-color:#e67d21e6;display: block;color: #fff;" > -->
					
					<div class="info-box-content" style="margin-left: 10px;">
						<span class="info-box-text" style="font-size: 14px;">Building &nbsp :&nbsp  <?php echo $row->building_name;  ?> </span>
					    <span class="info-box-number" style="font-size: 14px;">
						    Total Capacity:&nbsp<?php
									 $sql="SELECT SUM(`total_bed`) as total FROM `room` WHERE building_name = $row->id ";
                                     $capacity=$this->db->query($sql)->row_array();
								     echo $capacity['total']
                             ?>
					    </span>
						<div class="progress">
							<div class="progress-bar width-60"></div>
						</div>
					</div>
					<!-- /.info-box-content -->
				</a>
				<!-- /.info-box -->
			</div>
			<!-- /.col -->
			<?php
		    }
		    ?>
		</div>
	</div>
</div>