
			<!-- start page content -->
			<div class="page-content-wrapper">
				<div class="page-content">
					<div class="page-bar">
						<div class="page-title-breadcrumb">
							<div class=" pull-left">
								<div class="page-title">Update Password</div>
							</div>
							<ol class="breadcrumb page-breadcrumb pull-right">
								<li><i class="fa fa-home"></i>&nbsp;<a class="parent-item"
										href="#">Home</a>&nbsp;<i class="fa fa-angle-right"></i>
								</li>
								<li><a class="parent-item" href="#">Password</a>&nbsp;<i class="fa fa-angle-right"></i>
								</li>
								<li class="active">Update Password</li>
							</ol>
						</div>
					</div>
					<?php if ($this->session->flashdata('update')): ?>
                       <div class="alert text-white bg-success alert-dismissible" role="alert">
                      <div class="iq-alert-text"><?php echo $this->session->flashdata('update'); ?></div>
                      <button type="button" class="close" data-dismiss="alert">&times;</button>
                      <i class="ri-close-line"></i>
                      </div>
                    <?php endif; ?>

						<div class="profile-content">
				       <?php  
                        foreach ($h as $row)  
                        {  
                       ?>
							<div class="card-body no-padding">
								<div class="offset-3 col-md-6 col-sm-6">
									<div class="card">
										<header style="text-align: center; margin-top: 20px;">Password Change</header>
										<div class="card-body " id="bar-parent1">
										    <form action="<?php echo base_url('Admin/Admin/update_user_password');?>" method="post"  role="form" enctype="multipart/form-data">
												<div class="form-group">
													<label for="password">Current  Password</label>
													<input type="password" name="password" id="password" class="form-control">
											        <input type="hidden" name="id" value="<?=$row->id?>">
												</div>
												<div class="form-group">
													<label for="new_password">New  Password</label>
													<input type="password" name="new_password" id="new_password" class="form-control">
												</div>
												<div class="form-group">
													<label for="con_password">Confirm  Password</label>
													<input type="password" name="con_password" id="con_password" class="form-control">
												</div>
												<button type="submit" class="btn btn-primary">Update</button>
											</form>
										</div>
									</div>
								</div>
							</div>
						<?php
					     }
					    ?>
						</div>
					</div>
					</div>
					<!-- END PROFILE CONTENT -->
				</div>
			</div>
			<!-- end page content -->
				
