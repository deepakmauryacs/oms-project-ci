	        <!-- start page content -->
					<div class="page-content-wrapper">
						<div class="page-content">
							<div class="page-bar">
								<div class="page-title-breadcrumb">
									<div class=" pull-left">
										<div class="page-title">Checkin</div>
									</div>
									<ol class="breadcrumb page-breadcrumb pull-right">
										<li><i class="fa fa-home"></i>&nbsp;<a class="parent-item"
												href="#">Home</a>&nbsp;<i class="fa fa-angle-right"></i>
										</li>
										<li><a class="parent-item" href="#">Checkin</a>&nbsp;<i class="fa fa-angle-right"></i>
										</li>
										<li class="active">Add Checkin</li>
									</ol>
								</div>
							</div>
							<div class="row">
					           <div class="col-md-12 col-sm-12">
		                              
					         <div class="card card-topline-yellow">
					          <?php if ($this->session->flashdata('success')): ?>
		                       <div class="alert text-white bg-success alert-dismissible" role="alert">
		                         <div class="iq-alert-text">
		                            <?php echo $this->session->flashdata('success'); ?>
		                         </div>
		                         <button type="button" class="close" data-dismiss="alert">&times;</button>
		                         <i class="ri-close-line"></i>
		                       </div>
		                      <?php endif; ?>
							<div class="card-head">
								<header>Checkin</header>
								<div class="tools">
									<a class="fa fa-repeat btn-color box-refresh" href="javascript:;"></a>
									<a class="t-collapse btn-color fa fa-chevron-down" href="javascript:;"></a>
									<a class="t-close btn-color fa fa-times" href="javascript:;"></a>
								</div>
							</div>
							<div class="card-body " style="">

		     <!-- <?php  print_r($edit_data); ?> -->
	         <form action="<?php echo base_url('Admin/Add_room/update_guest');?>" method="post" role="form" enctype="multipart/form-data">
	           <div class="contener">
	           	<div class="row">


	               <div class="form-group col-md-6">
		            <label for="Product Category">Select Building</label>
		            <select class="form-control" name="building_id"  required onchange="get_floors(this.value);">
		            	<?php foreach($building as $buildings){ ?>
		            	<option  <?php if(!empty($edit_data)&&$edit_data->building_id==$buildings->id){ echo 'selected'; } ?> value="<?php echo $buildings->id; ?>"> <?php echo $buildings->building_name; ?> </option>
		            <?php } ?>
		            </select>
		           </div>

		            <div class="form-group col-md-6">
		            <label for="Product Category">Select Floor</label>
		            <select class="form-control" name="floor_id" id="get_floorss" required onchange="get_apartment(this.value);">
		            	<option  value="<?php echo $edit_data->floor_id; ?>">
		            	    <?php echo  get_field_value('tbl_floor','floor_name',['id'=>$edit_data->floor_id]); ?>
		            	</option>
		            </select>
		           </div>

		            <div class="form-group col-md-6">
		            <label for="Product Category">Select Apartment</label>
		            <select class="form-control" name="apartment_id"  id="get_apartments" onchange="get_rooms(this.value);" required>
		            	<option  value="<?php echo $edit_data->apartment_id; ?>">
                             <?php echo  get_field_value('apartment','apartment',['id'=>$edit_data->apartment_id]); ?>
		            	</option>
		            </select>
		           </div>

		            <div class="form-group col-md-6">
		            <label for="Product Category">Select Room</label>
		            <input type="hidden" name="edit_id" value="<?php if(!empty($edit_data)){ echo $edit_data->roomId; } ?>">
		            <input type="hidden" name="id" value="<?php if(!empty($edit_data)){ echo $edit_data->id; } ?>">
		            <select class="form-control" name="roomId" id="get_roomss"   required>
	                     
	            	<?php 
	                 $sql="SELECT * FROM `room` WHERE apartments = $edit_data->apartment_id";
	                 $sql_m=$this->db->query($sql)->result();
	            	 foreach($sql_m as $room){ ?>
	            	 <option <?php if(!empty($edit_data)&&$edit_data->roomId==$room->id){ echo 'selected'; } ?> value="<?php echo $room->id; ?>"> <?php echo $room->room_no; ?> </option>
		            <?php } ?>
		            </select>
		           </div>


		          <div class="form-group col-md-6">
		            <label for="Product Category">Guest Id</label>
		            <input type="text" class="form-control" name="guest_id"  value="<?php if(!empty($edit_data)){ echo $edit_data->guest_id; } ?>"  required>
		   
		          </div>

		           <div class="form-group col-md-6">
		            <label for="Product Category">Full Name</label>
		            
		            <input type="text" class="form-control" name="custmer_name" value="<?php if(!empty($edit_data)){ echo $edit_data->custmer_name; } ?>"   required>
		           </div>

		           <!--<div class="form-group col-md-6">-->
		           <!-- <label for="Product Category">Arrival Date</label>-->
		            
		           <!-- <input type="date" class="form-control" name="arrival_date" value="<?php if(!empty($edit_data)){ echo $edit_data->arrival_date; } ?>"   required>-->
		           <!--</div>-->

	              
	              
	              <div class="form-group col-md-6">
		            <label for="Product Category">Gender</label>
		            <select class="form-control" name="gender"  required>
		            	<option  <?php if(!empty($edit_data)&&$edit_data->gender=='Male'){ echo 'selected'; } ?> value="Male"> Male</option>
		            	<option  <?php if(!empty($edit_data)&&$edit_data->gender=='Female'){ echo 'selected'; } ?> value="Female"> Female</option>
		            </select>
		          </div>


		           <div class="form-group col-md-6">
		            <label for="Product Category">Contact Number</label>
		            <input type="number" class="form-control" name="contact_number" value="<?php if(!empty($edit_data)){ echo $edit_data->contact_number; } ?>"  required>
		          </div>
	              

		           <div class="form-group col-md-6">
		            <label for="Product Category">Flight</label>
		            <input type="text" class="form-control" name="flight" value="<?php if(!empty($edit_data)){ echo $edit_data->flight; } ?>"  required>
		           </div>

		           <div class="form-group col-md-6">
		            <label for="Product Category">Sponsor Phone</label>
		            <input type="text" class="form-control" name="sponsor_phone" value="<?php if(!empty($edit_data)){ echo $edit_data->sponsor_phone; } ?>"  required>
		           </div>
	                
	               <div class="form-group col-md-6">
		            <label for="Product Category">Food Preference</label>
		            <select class="form-control" name="food_preference"   required>
		            	<option <?php if(!empty($edit_data)&&$edit_data->food_preference=='Veg'){ echo 'selected'; } ?>  value="Veg"> Veg</option>
		            	<option <?php if(!empty($edit_data)&&$edit_data->food_preference=='Non-Veg'){ echo 'selected'; } ?> value="Non-Veg"> Non-Veg</option>
		            </select> 
		          </div>

	              <div class="form-group col-md-6">
		            <label for="Product Category">Blood Group</label>
		            <input type="text" class="form-control" name="blood_group" value="<?php if(!empty($edit_data)){ echo $edit_data->blood_group; } ?>"  required>
		          </div>

		          <div class="form-group col-md-6">
		            <label for="Product Category">Nationality</label>
		           
		            <select class="form-control" name="nationality"  required>
		            	<option <?php if(!empty($edit_data)&&$edit_data->nationality=='Indian'){ echo 'selected'; } ?> value="Indian"> Indian</option>
		            	<option <?php if(!empty($edit_data)&&$edit_data->nationality=='Philippines'){ echo 'selected'; } ?>  value="Philippines"> Philippines</option>
		            </select>
		          </div>

		          <div class="form-group col-md-6">
		            <label for="Product Category">Passport Number</label>
		            <input type="text" class="form-control" name="passport_number" value="<?php if(!empty($edit_data)){ echo $edit_data->passport_number; } ?>"   >
		          </div>

		           <div class="form-group col-md-6">
		            <label for="Product Category">Civil ID Number</label>
		            <input type="text" class="form-control" name="civilid_number" value="<?php if(!empty($edit_data)){ echo $edit_data->civilid_number; } ?>"   required>
		          </div>

		          <div class="form-group col-md-6">
		            <label for="Product Category">Emergency Contact Number</label>
		            <input type="number" class="form-control" name="emergency_contact_number" value="<?php if(!empty($edit_data)){ echo $edit_data->emergency_contact_number; } ?>"   required>
		          </div>

		           <div class="form-group col-md-6">
		            <label for="Product Category">Emergency Contact Relationship</label>
		            <input type="text" class="form-control" name="emergency_contact_relationship" value="<?php if(!empty($edit_data)){ echo $edit_data->emergency_contact_relationship; } ?>"   required>
		          </div>

		          <div class="form-group col-md-6">
		            <label for="Product Category">About Guest</label>
		            <textarea name="about_guest" class="form-control" rows="5" required="">	 
	                  <?php if(!empty($edit_data)){ echo $edit_data->about_guest; } ?>
		            </textarea>
		          </div>

		           <div class="form-group col-md-6">
		            <label for="Product Category">Enter Quarantine Days</label>
		            <input type="text" class="form-control" name="quarantine_days" value="<?php if(!empty($edit_data)){ echo $edit_data->quarantine_days; } ?>" required>
		            <input type="hidden" class="form-control" name="date" value="<?php if(!empty($edit_data)){ echo $edit_data->date; } ?>" required>
		            <input type="hidden" class="form-control" name="bed_count" value="<?php if(!empty($edit_data)){ echo $edit_data->bed_count; } ?>" required>
		           </div>


	              <?php
	              if ($edit_data->status== 1)
	               {
	              ?>
		          <div class="form-group col-md-6">
		            <label for="Product Category">Isolated</label><br>
		            <input type="radio" <?php if(!empty($edit_data)&&$edit_data->isolated=='Yes'){ echo 'checked'; } ?>  name="isolated" value="Yes">
					  <label for="vehicle1"> YES </label>&nbsp&nbsp
					  <input type="radio"  name="isolated" <?php if(!empty($edit_data)&&$edit_data->isolated=='No'){ echo 'checked'; } ?> value="No" >
					  <label for="vehicle2"> No </label>
		          </div>
		          <?php
		              }
		           ?>


		         </div>
		         <center>
	               <button type="submit" class="btn btn-primary">Update</button>
	            </center>
	         </form>      
	         
	     </div>
			
			</div>
		</div>
	</div>
	</div>
	</div>
	</div>
	</div>
	</div>

	<script type="text/javascript">

	  function get_floors(bilding_id)
	  {
	     $.ajax({
	               type: "POST",
	               url: '<?php echo base_url();?>Admin/Add_roomno/get_floors',
	               data: {bilding_id:bilding_id}, // serializes the form's elements.
	               beforeSend:function()
	              {
	                
	              },
	              success:function(responce)
	              {

	                $('#get_floorss').html(responce);
	              },
	              error:function()
	              {
	                alert('Error');
	                
	              },
	              complete:function()
	              {
	                
	              }
	            }); 

	  }

	  function get_apartment(floor_id)
	  {
	     $.ajax({
	               type: "POST",
	               url: '<?php echo base_url();?>Admin/Add_roomno/get_apartment',
	               data: {floor_id:floor_id}, // serializes the form's elements.
	               beforeSend:function()
	              {
	                
	              },
	              success:function(responce)
	              {

	                $('#get_apartments').html(responce);
	              },
	              error:function()
	              {
	                alert('Error');
	                
	              },
	              complete:function()
	              {
	                
	              }
	            }); 

	  }

	  function get_rooms(apartment_id)
	  {
	     $.ajax({
	               type: "POST",
	               url: '<?php echo base_url();?>Admin/Add_roomno/get_rooms',
	               data: {apartment_id:apartment_id}, // serializes the form's elements.
	               beforeSend:function()
	              {
	                
	              },
	              success:function(responce)
	              {

	                $('#get_roomss').html(responce);
	              },
	              error:function()
	              {
	                alert('Error');
	                
	              },
	              complete:function()
	              {
	                
	              }
	            }); 

	  }
	</script>

