<script src="https://cdn.ckeditor.com/4.14.0/standard/ckeditor.js"></script>
      <!-- start page content -->
      <div class="page-content-wrapper">
        <div class="page-content">
          <div class="page-bar">
            <div class="page-title-breadcrumb">
              <div class=" pull-left">
                <div class="page-title">About</div>
              </div>
              <ol class="breadcrumb page-breadcrumb pull-right">
                <li><i class="fa fa-home"></i>&nbsp;<a class="parent-item"
                    href="index.html">Home</a>&nbsp;<i class="fa fa-angle-right"></i>
                </li>
                <li><a class="parent-item" href="#">Index</a>&nbsp;<i class="fa fa-angle-right"></i>
                </li>
                <li class="active">Update About</li>
              </ol>
            </div>
          </div>
          <div class="row">
                 <div class="offset-2 col-md-8 col-sm-8">          
                    <div class="card card-topline-yellow">
                       <?php if ($this->session->flashdata('update')): ?>
                       <div class="alert text-white bg-success alert-dismissible" role="alert">
                      <div class="iq-alert-text"><?php echo $this->session->flashdata('update'); ?></div>
                      <button type="button" class="close" data-dismiss="alert">&times;</button>
                      <i class="ri-close-line"></i>
                      </div>
                      <?php endif; ?>

                    <div class="card-head">
                      <header> About </header>
                      <div class="tools">
                        <a class="fa fa-repeat btn-color box-refresh" href="javascript:;"></a>
                        <a class="t-collapse btn-color fa fa-chevron-down" href="javascript:;"></a>
                        <a class="t-close btn-color fa fa-times" href="javascript:;"></a>
                      </div>
                    </div>
                    <div class="card-body " style="">
                       
                         <?php  
                            $i=1;
                            foreach ($h as $row)  
                            {  
                          ?>



                       <form action="<?php echo base_url('Admin/About/update_about');?>" method="post"  role="form" enctype="multipart/form-data">

                        <div class="form-group">
                        <label for="Product Category">Old image1</label>
                        <input type="disable"  value="<?php echo $row->image1; ?>" name="oldImage1"  class="form-control" />
                        </div>
                               
                       <div class="form-group">
                        <label for="Product Category">Image One</label>
                        <input type="file" class="form-control" name="image1"  placeholder="Product Type" style="padding-top: 3px;">
                        <input type="hidden" name="id" value="<?=$row->id?>">
                       </div>

                       <div class="form-group">
                        <label for="Product Category">Heading One</label>
                        <input type="text" class="form-control" name="heading1" value="<?php echo $row->heading1; ?>">
                       
                       </div>

                        <div class="form-group">
                        <label for="Product Category">Description One</label>
                         <textarea name="description1" class="ckeditor" rows="3">  
                           <?php echo $row->description1; ?>                     
                         </textarea>
                        </div>

                       <div class="form-group">
                        <label for="Product Category">Old image2</label>
                        <input type="disable"  value="<?php echo $row->image2; ?>" name="oldImage2"  class="form-control" />
                       </div>


                      <div class="form-group">
                       <label for="Product Category">Image Two</label>
                       <input type="file" class="form-control" name="image2"  placeholder="Product Type" style="padding-top: 3px;" >
                      </div>

                        <div class="form-group">
                          <label for="Product Category">Heading Two</label>
                          <input type="text" class="form-control" value="<?php echo $row->heading2; ?>" name="heading2">                     
                       </div>

                        <div class="form-group">
                          <label for="Product Category">Description Two</label>
                             <textarea name="description2" class="ckeditor" rows="3">                   <?php echo $row->description2; ?>
                             </textarea>
                        </div>


                       <div class="form-group">
                        <label for="Product Category">Old image3</label>
                        <input type="disable"  value="<?php echo $row->image3; ?>" name="oldImage3"  class="form-control" />
                       </div>
                      <div class="form-group">
                       <label for="Product Category">Image Three</label>
                       <input type="file" class="form-control" name="image3"  placeholder="Product Type" style="padding-top: 3px;" >
                      </div>

                        <div class="form-group">
                          <label for="Product Category">Heading Three</label>
                          <input type="text" class="form-control" value="<?php echo $row->heading3; ?>" name="heading3">                     
                       </div>

                        <div class="form-group">
                          <label for="Product Category">Description Three</label>
                          <textarea name="description3" class="ckeditor" rows="3">                  <?php echo $row->description3; ?>
                          </textarea>
                        </div>


                      <button type="submit" class="btn btn-primary">Submit</button>
                     </form>

                    <?php
                      }
                    ?>
                  </div>
                 </div>
               </div>
             </div>
          </div>
       </div>
