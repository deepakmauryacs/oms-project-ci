<!-- start page content -->
		<div class="page-content-wrapper">
			<div class="page-content">
			<div class="page-bar">
			<div class="page-title-breadcrumb">
			<div class=" pull-left">
			<div class="page-title">Dashboard</div>
		</div>
		<ol class="breadcrumb page-breadcrumb pull-right">
		<li><i class="fa fa-home"></i>&nbsp;<a class="parent-item"
				href="#">Home</a>&nbsp;<i class="fa fa-angle-right"></i>
		</li>
		<li class="active">Dashboard</li>
		</ol>
		</div>
		</div>


		<?php if ($this->session->flashdata('success')): ?>
		<div class="alert text-white bg-success alert-dismissible" role="alert">
		<div class="iq-alert-text"><?php echo $this->session->flashdata('success'); ?></div>
		<button type="button" class="close" data-dismiss="alert">&times;</button>
		<i class="ri-close-line"></i>

		</div>
		<?php endif; ?>

		<?php if ($this->session->flashdata('update')): ?>
		<div class="alert text-white bg-success alert-dismissible" role="alert">
		<div class="iq-alert-text"><?php echo $this->session->flashdata('update'); ?></div>
		<button type="button" class="close" data-dismiss="alert">&times;</button>
		<i class="ri-close-line"></i>

		</div>
		<?php endif; ?>

		<?php if ($this->session->flashdata('delete')): ?>
		<div class="alert text-white bg-danger alert-dismissible" role="alert">
		<div class="iq-alert-text"> <?php echo $this->session->flashdata('delete'); ?></div>

		<button type="button" class="close" data-dismiss="alert">&times;</button>
		<i class="ri-close-line"></i>

		</div>
		<?php endif; ?>

		<!-- start widget -->
		<div class="state-overview">
		<div class="row">
		<div class="col-xl-3 col-md-6 col-12">
		<a href="javascript:void(0);" onclick="get_all_records('capacity');" class="info-box bg-blue" style="background-color:#0d5190;display: block;color: #fff;" >
			<span class="info-box-icon push-bottom"><i class="fa fa-bar-chart"></i></span>
			<div class="info-box-content">
				<span class="info-box-text" style="font-size: 11px;">Total Capacity </span>
				<span class="info-box-number">
				    
			     <?php
				 $sql="SELECT SUM(`total_bed`) as total FROM `room` ";
		         $capacity=$this->db->query($sql)->row_array();
			     echo $capacity['total']
		             ?></span>
				<div class="progress">
					<div class="progress-bar width-60"></div>
				</div>
				
			</div>
			<!-- /.info-box-content -->
		</a>
		<!-- /.info-box -->
		</div>
		<!-- /.col -->
		<div class="col-xl-3 col-md-6 col-12">
		<a  href="javascript:void(0);" onclick="get_all_records('occupied_bed_list');" class="info-box bg-orange" style="background-color:#1579d7;display: block;color: #fff;"  >
			<span class="info-box-icon push-bottom"><i class="fa fa-bed"></i></span>
			<div class="info-box-content">
				<span class="info-box-text" style="font-size: 11px;">Occupied Beds</span>
				<span class="info-box-number">
				 
				   
				<?php	$query = $this->db->query("SELECT SUM(`bed_count`) as total FROM `checkin_checkout` WHERE `status`='1'" )->row_array();
				
				 if (!empty( $query['total'])) {
				   echo $query['total'];
				   }else{
                  echo "0";
				 }
				 
		      //  echo $query['total'];
		             ?></span>
				<div class="progress">
					<div class="progress-bar width-40"></div>
				</div>
				
			</div>
			<!-- /.info-box-content -->
		</a>
		<!-- /.info-box -->
		</div>
			<!-- /.res col -->
		<div class="col-xl-3 col-md-6 col-12">
		<a href="javascript:void(0);" onclick="get_all_records('reserved_beds_list');" class="info-box bg-purple" style="background-color:#489be7;display: block;color: #fff;" >
			<span class="info-box-icon push-bottom"><i class="fa fa-bed"></i></span>
			<div class="info-box-content">
				<span class="info-box-text" style="font-size: 11px;">Reserved Beds </span>
				<span class="info-box-number">
				<?php	$query = $this->db->query("SELECT SUM(`bed_count`) as total FROM `checkin_checkout` WHERE `status`='4' " )->row_array();
				
		        echo !empty($query['total'])?$query['total']:0;
		             ?>
		         </span>
				<div class="progress">
					<div class="progress-bar width-80"></div>
				</div>
				
			</div>
			<!-- /.info-box-content -->
		</a>
		<!-- /.info-box -->
		</div>
		<!-- /.res col -->
		
		<!-- /.col -->
		<div class="col-xl-3 col-md-6 col-12">
		 <a href="javascript:void(0);" onclick="get_all_records('vacant_beds_list');" class="info-box bg-purple" style="background-color:#489be7;display: block;color: #fff;" >
			<span class="info-box-icon push-bottom"><i class="fa fa-bed"></i></span>
			<div class="info-box-content">
				<span class="info-box-text" style="font-size: 11px;">Vacant Beds </span>
				<span class="info-box-number">
				    <?php	$query1 = $this->db->query("SELECT SUM(`bed_count`) as total FROM `checkin_checkout` WHERE `status` ='4' OR `status` ='1'" )->row_array();
		                echo $capacity['total'] - $query1['total'];
		             ?>
		      </span>
				<div class="progress">
					<div class="progress-bar width-80"></div>
				</div>
				
			</div>
			<!-- /.info-box-content -->
		</a>
		<!-- /.info-box -->
		</div>
		<!-- /.col -->

		



		<div class="col-xl-3 col-md-6 col-12">
		<a href="javascript:void(0);" onclick="get_all_records('todays_checkin_lists');" class="info-box bg-purple" style="background-color:#a2cdf7;display: block;color: #fff;"  >
			<span class="info-box-icon push-bottom"><i class="fa fa-users"></i></span>
			<div class="info-box-content">
				<span class="info-box-text" style="    font-size: 11px;">Todays CheckIn</span>
				<span class="info-box-number"><?php	
				
				$todaydate    =date('Y-m-d');
				
				$query = $this->db->query("SELECT * FROM `checkin_checkout` WHERE `status`='1' AND DATE(date) = DATE(NOW())");
		        echo $query->num_rows();
		             ?></span>
				<div class="progress">
					<div class="progress-bar width-60"></div>
				</div>
				
			</div>
			<!-- /.info-box-content -->
		</a>
		<!-- /.info-box -->
		</div>

		<div class="col-xl-3 col-md-6 col-12">
		<a  href="javascript:void(0);" onclick="get_all_records('todays_checkout_lists');"  class="info-box bg-purple" style="background-color:#489be7;display: block;color: #fff;">
			<span class="info-box-icon push-bottom"><i class="fa fa-users"></i></span>
			<div class="info-box-content">
				<span class="info-box-text" style="    font-size: 11px;">Todays Checked Out</span>
				<span class="info-box-number"><?php	
				$todaydate    =date('Y-m-d');
				$query = $this->db->query("SELECT * FROM `checkin_checkout` WHERE `status`='2' AND DATE(date) = DATE(NOW())");
		        echo $query->num_rows();
		             ?></span>
				<div class="progress">
					<div class="progress-bar width-60"></div>
				</div>
				
			</div>
			<!-- /.info-box-content -->
		</a>
		<!-- /.info-box -->
		</div>
		<!-- /.col -->
		</div>	
		 
		     
			   <div class="card card-topline-yellow">
				  <div class="card-head">
					 <header>Building Details :</header>
				 </div>
	           </div>
          
		
	    <!--<div style="background-color:#000000; height:2px; width:100%; margin-bottom: 10px;"></div>-->
		<div class="row" id="results"> 
		</div>




   </div>
</div>
</div>

  
<script type="text/javascript">
 function get_all_records(functionname)
 {

 	$.ajax({
	           type: "POST",
	           url: '<?php echo base_url();?>Admin/Admin/'+functionname,
	           data: {appartmentid:''}, // serializes the form's elements.
	           beforeSend:function()
				{
					
				},
				success:function(responce)
				{
					$('#results').html(responce);
				},
				error:function()
				{
					alert('Error');
					
				},
				complete:function()
				{
					
				}
	        });	
 }
</script>
