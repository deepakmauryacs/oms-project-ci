
	<!-- start page content -->
			<div class="page-content-wrapper">
				<div class="page-content">
					<div class="page-bar">
						<div class="page-title-breadcrumb">
							<div class=" pull-left">
								<div class="page-title">Guest list</div>
							</div>
							<ol class="breadcrumb page-breadcrumb pull-right">
								<li><i class="fa fa-home"></i>&nbsp;<a class="parent-item"
										href="index.html">Home</a>&nbsp;<i class="fa fa-angle-right"></i>
								</li>
								<li><a class="parent-item" href="#">Guest </a>&nbsp;<i class="fa fa-angle-right"></i>
								</li>
								<li class="active">Guest list</li>
							</ol>
						</div>
					</div>
					<div class="row">
			         
                              
			         
			 <div class="col-md-12 col-sm-12">
			 <div class="card card-topline-yellow">
			 <?php if ($this->session->flashdata('update')): ?>
             <div class="alert text-white bg-success alert-dismissible" role="alert">
             <div class="iq-alert-text"><?php echo $this->session->flashdata('update'); ?></div>
             <button type="button" class="close" data-dismiss="alert">&times;</button>
             <i class="ri-close-line"></i>
             </button>
             </div>
             <?php endif; ?>

             <?php if ($this->session->flashdata('delete')): ?>
             <div class="alert text-white bg-danger alert-dismissible" role="alert">
             <div class="iq-alert-text"> <?php echo $this->session->flashdata('delete'); ?></div>

             <button type="button" class="close" data-dismiss="alert">&times;</button>
             <i class="ri-close-line"></i>
             </button>
             </div>
            <?php endif; ?>
										<div class="card-head">
											<header>Guest list</header>
											<div class="tools">
												<a class="fa fa-repeat btn-color box-refresh" href="javascript:;"></a>
												<a class="t-collapse btn-color fa fa-chevron-down" href="javascript:;"></a>
												<a class="t-close btn-color fa fa-times" href="javascript:;"></a>
											</div>
										</div>
										<div class="card-body " style="">
											<div class="table-scrollable">
												 <table class="table table-bordered display full-width" id="example">
													<thead>
														<tr>
															 <th>SL#</th>
															<th><div style="width: 66px;">Guest id</div></th>
															<th>Name</th>
															<th>Building</th>
															<th>Appartment</th>
															<th>Room</th>
															<th>Gender</th>
															<th><div style="width: 125px;">Contact Number</div></th>
															<th><div style="width: 125px;">Passport Number</div></th>
															<th><div style="width: 125px;">Civilid Number</div></th>
															<th>Nationality</th>
															<th><div style="width: 125px;">food Preference</div></th>
															<th>Flight</th>
															<th><div style="width: 125px;">Blood Group</div></th>
															<th><div style="width: 125px;">Sponsor Phone</div></th>
															<th><div style="width: 170px;">Emergency Con Num<div style="width: 75px;"></th>
															<th><div style="width: 225px;">Emergency Con Relationship</div></th>
															<th>Status</th>
															<th><div style="width: 125px;">Reserved Date</div></th>
															<th><div style="width: 145px;">Checked In Date</div></th>
															
															<th>Action</th>
															
															
														</tr>
													</thead>
													<tbody>

                                                <?php  
                                                   $i=1;
                                              

                                                    foreach ($list as $key => $value) {
                                                     
                                                     $buildingId = get_field_value('apartment','building_id',['id'=>$value['apartment_id']]);
                                                     $status=array('4'=>'Reserved','1'=>'Checked-In','2'=>'Checked-Out','3'=>'Cancelled');
                                                 ?>
                                                 

														<tr>
															<td><?php echo $i++;?></td>
															<td><?php echo $value['guest_id']; ?></td>
															<td><?php echo $value['custmer_name']; ?></td>
															<td><?php echo get_field_value('tbl_building','building_name',['id'=>$buildingId]) ?></td>
															<td><?php echo get_field_value('apartment','apartment',['id'=>$value['apartment_id']]); ?></td>
															<td><?php echo get_field_value('room','room_no',['id'=>$value['roomId']]) ; ?></td>
														    <td><?php echo $value['gender']; ?></td>
															<td><?php echo $value['contact_number']; ?></td>
															<td><?php echo $value['passport_number']; ?></td>
															<td><?php echo $value['civilid_number']; ?></td>
															<td><?php echo $value['nationality']; ?></td>
															<td><?php echo $value['food_preference']; ?></td>
														    <td><?php echo $value['flight']; ?></td>
															<td><?php echo $value['blood_group']; ?></td>
															<td><?php echo $value['sponsor_phone']; ?></td>
															<td><?php echo $value['emergency_contact_number']; ?></td>
															<td><?php echo $value['emergency_contact_relationship']; ?></td>
															<td><?php echo $status[$value['status']];  ; ?></td>
															<td><?php echo $value['reserved_date']; ?></td>
															<td><?php echo $value['date']; ?></td>
														
														
														
														
														    <td> 
														    <div style="width: 111px;display: flex;">
														    <a href="<?php echo base_url(); ?>Admin/Admin/update_status/<?php echo $value['id'] ?>" class="btn btn-tbl-edit btn-xs"  style="background-color: orange;"><i class="fa fa-undo"></i></a>
                                                            <a href="<?php echo base_url(); ?>Admin/Admin/edit_guest/<?php echo $value['id'] ?>" class="btn btn-tbl-edit btn-xs" style="    background-color: #1e1ebbb5;"><i class="fa fa-pencil-square-o"></i></a>
                                                            <a href="<?php echo base_url(); ?>Admin/Add_room/delete_geust/<?php echo $value['id'] ?>"  class="btn btn-tbl-delete btn-xs"  onclick="return confirm(`Are you sure to Delete ?`)"> <i class="fa fa-trash-o "></i></a>
														    </div>
														    
														    </td>
        
        <div class="modal fade" id="exampleModal<?php echo $value['id']; ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
		  <div class="modal-dialog">
		    <div class="modal-content">
		      <div class="modal-header">
		        <h5 class="modal-title" id="exampleModalLabel">View All CheckIn</h5>
		        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
		          <span aria-hidden="true">&times;</span>
		        </button>
		      </div>
		      <div class="modal-body">
		        <div class="card-body " style="">
					<form action="<?php echo base_url('Admin/Add_room/update_status');?>" id="form_sample_1" class="form-horizontal"  method="post"   novalidate="novalidate" enctype="multipart/form-data">
		                <div class="form-body">
		                      <div class="form-group row">
		                        <label class="control-label col-md-3">Status</label>
		                      <div class="col-md-9">
				                    <select class="form-control" name="status" id="status" required>
				                        <option value="2">Checkout</option>
				                        <option value="1">Checkin</option>
				                    </select>
				                    <input type="hidden" name="id" value="<?php echo $value['id']; ?>">
		                        </div>
		                      </div>     
		                              
		                  </div>
		                      <center>
								<button type="submit" class="btn btn-primary">Checkout</button>
							 </center>                         
		               </form>
				   </div>
		      </div>
		    </div>
		  </div>
		</div>
											
														</tr>

														<?php
												      	}
													   ?>
														
														
													</tbody>
												</table>
											</div>
										</div>
									</div>
								</div>
						</div>
					
					

		</div>
	</div>
