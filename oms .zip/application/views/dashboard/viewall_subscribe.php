			<!-- start page content -->
			<div class="page-content-wrapper">
				<div class="page-content">
					<div class="page-bar">
						<div class="page-title-breadcrumb">
							<div class=" pull-left">
								<div class="page-title">Subscription</div>
							</div>
							<ol class="breadcrumb page-breadcrumb pull-right">
								<li><i class="fa fa-home"></i>&nbsp;<a class="parent-item"
										href="index.html">Home</a>&nbsp;<i class="fa fa-angle-right"></i>
								</li>
								<li><a class="parent-item" href="#">Subscription</a>&nbsp;<i class="fa fa-angle-right"></i>
								</li>
								<li class="active">Subscription List</li>
								<li class="active"></li>
							</ol>
						</div>
					</div>
					<div class="row">
			           <div class="col-sm-12 col-md-8 col-lg-6">
							<div class="card card-box">
								<div class="card-head">
									<header>Subscription List</header>
									<div class="tools">
										<a class="fa fa-repeat btn-color box-refresh" href="javascript:;"></a>
										<a class="t-collapse btn-color fa fa-chevron-down" href="javascript:;"></a>
										<a class="t-close btn-color fa fa-times" href="javascript:;"></a>
									</div>
								</div>
								<div class="card-body ">
									<div class="table-scrollable">
										<table class="table table-hover table-checkable order-column full-width"
											id="example4">
											<thead>
												<tr>
													<th class="center">S No.</th>
													<th class="center"> Email </th>
													<th class="center"> Action </th>
												</tr>
											</thead>
											<tbody>
												<?php
												foreach ($h as $key => $value) {
													
												?>
												<tr class="odd gradeX">
													<td class="user-circle-img"><?php echo $key+1; ?></td>
													<td class="center"><?php echo $value->email; ?> </td>
													<td>
														<a class="btn btn-danger btn-xs" onclick="return confirm('Are you sure?')"  href="<?php echo base_url().'Admin/Subscribe/delete_contact/'.$value->id  ?>" >
		                                                  <i class="fa fa-trash-o "></i>
		                                                 </a>
													</td>
												</tr>
												<?php }
												?>
												
											</tbody>
										</table>
									</div>
								</div>
							</div>
						</div>
					 </div>

					
					
					

		</div>
	</div>



