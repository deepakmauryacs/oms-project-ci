	        <!-- start page content -->
					<div class="page-content-wrapper">
						<div class="page-content">
							<div class="page-bar">
								<div class="page-title-breadcrumb">
									<div class=" pull-left">
										<div class="page-title">Update Status</div>
									</div>
									<ol class="breadcrumb page-breadcrumb pull-right">
										<li><i class="fa fa-home"></i>&nbsp;<a class="parent-item"
												href="#">Home</a>&nbsp;<i class="fa fa-angle-right"></i>
										</li>
										<li><a class="parent-item" href="#">Status</a>&nbsp;<i class="fa fa-angle-right"></i>
										</li>
										<li class="active">Update Status</li>
									</ol>
								</div>
							</div>
							<div class="row">
					           <div class="offset-3 col-md-6">
		                              
					         <div class="card card-topline-yellow">
					          <?php if ($this->session->flashdata('success')): ?>
		                       <div class="alert text-white bg-success alert-dismissible" role="alert">
		                         <div class="iq-alert-text">
		                            <?php echo $this->session->flashdata('success'); ?>
		                         </div>
		                         <button type="button" class="close" data-dismiss="alert">&times;</button>
		                         <i class="ri-close-line"></i>
		                       </div>
		                      <?php endif; ?>

							<div class="card-head">
								<header>Status</header>
								<div class="tools">
									<a class="fa fa-repeat btn-color box-refresh" href="javascript:;"></a>
									<a class="t-collapse btn-color fa fa-chevron-down" href="javascript:;"></a>
									<a class="t-close btn-color fa fa-times" href="javascript:;"></a>
								</div>
							</div>
							<div class="card-body " style="">

		     <!-- <?php  print_r($edit_data); ?> -->
		     <!--  -->
	      
	           <div class="contener">
	              <?php
	               if( $edit_data->status== 4 )
	                 {
	               ?>

	          <form action="<?php  echo base_url()?>Admin/Add_room/update_status" method="post" role="form" enctype="multipart/form-data">
	            <div class="row">
	              <div class="form-group col-md-12">
		            <label for="Product Category">Status</label>
		            <select class="form-control" name="status"  id="status"  required>

		            	<option  value="" selected> ---Select Status--- </option>
		            	
		            	<option  <?php if(!empty($edit_data)&&$edit_data->status=='1'){ echo 'selected'; } ?> value="1">Checked In </option>
		            <option  <?php if(!empty($edit_data)&&$edit_data->status=='3'){ echo 'selected'; } ?> value="3"> Cancelled </option>
		            	<input type="hidden" name="id" value="<?php if(!empty($edit_data)){ echo $edit_data->id; } ?>">
		            	<input type="hidden" name="quarantine_days" value="<?php if(!empty($edit_data)){ echo $edit_data->quarantine_days; } ?>">

		            </select>
		          </div>

		          <div class="form-group col-md-12" id="checkins" style="display: none;">
		            <label for="Product Category">Checkin Date</label>
		            <input type="date" class="form-control" name="date" >
		            <input type="hidden" name="id" value="<?php if(!empty($edit_data)){ echo $edit_data->id; } ?>">
		          </div>
		        </div>
		             <center>
	                   <button type="submit" class="btn btn-primary">Update</button>
	                 </center>
		      </form>
		          <?php
		            }elseif ($edit_data->status== 1) {
		           ?>
	                  <form action="<?php  echo base_url()?>Admin/Add_room/update_cheakin_status" method="post" role="form" enctype="multipart/form-data" id="formCheckout">
	                  <div class="row">
			           <div class="form-group col-md-12">
			            <label for="Product Category">Status</label>
			            <select class="form-control" name="status" id="status1" required>
			            	<option  value="" selected> ---Select Status--- </option>
			            	<option  <?php if(!empty($edit_data)&&$edit_data->status=='2'){ echo 'selected'; } ?> value="2">Checked Out </option>

			            	<option value="1"> Isolated </option>
 
			            	<input type="hidden" name="id" value="<?php if(!empty($edit_data)){ echo $edit_data->id; } ?>">
			            </select>
			          </div>

			          <div class="form-group col-md-12" id="checkins1" style="display: none;">
			            <label for="Product Category">Checked Out Date</label>
			            <input type="date" id="checkout_date" class="form-control" name="cheakout_date" >
			            <input type="hidden" id="scheduled_date" name="scheduled_exit_date" value="<?php if(!empty($edit_data)){ echo $edit_data->scheduled_exit_date; } ?>">
		         	  </div>

				      <div class="form-group col-md-6" id="checkins2"  style="display: none;">
			            <label for="Product Category">Isolated</label><br>
			            <input type="radio"  name="isolated" value="yes">
						  <label for="Yes"> YES </label>&nbsp&nbsp
						  <input type="radio"  name="isolated" value="no">
						  <label for="No"> No </label>
			          </div>


		         	</div> 
		         	 <center>
	                   <button type="submit" class="btn btn-primary">Update</button>
	                 </center>
	             </form>
		           <?php
		             }else{
		            ?>
	                   <p>Cannot Modify Guest  Status</p>

		            <?php
		             }
		             ?>

		          </div>
	           </div>
			</div>
		</div>
	</div>
  </div>
</div>


 <script>
		$("#status").on("change", function(){
			var status = $(this).val();

			switch(status){
				case "3":
					$("#checkins").css("display", "none");
					break;
				case "1":
					$("#reserved").css("display", "none");
					$("#checkins").css("display", "block");
					break;
			}
		});

		$("#status1").on("change", function(){
			var status = $(this).val();

			switch(status){
				case "1":
					$("#checkins1").css("display", "none");
					$("#checkins2").css("display", "block");
					break;
				case "2":
					$("#checkins2").css("display", "none");
					$("#checkins1").css("display", "block");
					break;
			}
		});
		$(function(){
			$("#checkout_date").on('change', function(){
				var checkoutDate = $(this).val();
				var scheduledDate = $("#scheduled_date").val();
				var n = checkoutDate.localeCompare(scheduledDate);
				if(n < 0){
					alert("Checkout date cannot be before scheduled exit date");
					$(this).val("");
				}
			});
			$("#formCheckout").on('submit', function(e){
				// e.preventDefault();
				var $status = $("#status1").val();
				console.log($status);
				if($status == 2){
					if($("#checkout_date").val() == ""){
						alert("Please provide checkout date.");
						return false;
					}
				}else{
					return true;
				}

				return true;
			})
		})
	</script>
