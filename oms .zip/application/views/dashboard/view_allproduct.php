					<!-- start page content -->
					<div class="page-content-wrapper">
						<div class="page-content">
							<div class="page-bar">
								<div class="page-title-breadcrumb">
									<div class=" pull-left">
										<div class="page-title">Product </div>
									</div>
									<ol class="breadcrumb page-breadcrumb pull-right">
										<li><i class="fa fa-home"></i>&nbsp;<a class="parent-item"
												href="index.html">Home</a>&nbsp;<i class="fa fa-angle-right"></i>
										</li>
										<li><a class="parent-item" href="#">Product</a>&nbsp;<i class="fa fa-angle-right"></i>
										</li>
										<li class="active">All Product </li>
									</ol>
								</div>
							</div>
							<div class="row">
							<div class="col-md-12 col-sm-12">
								 <div class="card card-topline-yellow">
					 <?php if ($this->session->flashdata('update')): ?>
		             <div class="alert text-white bg-success alert-dismissible" role="alert">
		             <div class="iq-alert-text"><?php echo $this->session->flashdata('update'); ?></div>
		             <button type="button" class="close" data-dismiss="alert">&times;</button>
		             <i class="ri-close-line"></i>
		            
		             </div>
		             <?php endif; ?>

		             <?php if ($this->session->flashdata('delete')): ?>
		             <div class="alert text-white bg-danger alert-dismissible" role="alert">
		             <div class="iq-alert-text"> <?php echo $this->session->flashdata('delete'); ?></div>

		             <button type="button" class="close" data-dismiss="alert">&times;</button>
		             <i class="ri-close-line"></i>
		            
		             </div>
		            <?php endif; ?>
												<div class="card-head">
													<header>All Product </header>
													<div class="tools">
														<a class="fa fa-repeat btn-color box-refresh" href="javascript:;"></a>
														<a class="t-collapse btn-color fa fa-chevron-down" href="javascript:;"></a>
														<a class="t-close btn-color fa fa-times" href="javascript:;"></a>
													</div>
												</div>
												<div class="card-body " style="">
													<div class="table-scrollable">
														 <table class="table table-bordered display full-width" id="saveStage">
															<thead>
																<tr>
																	<th>#</th>
																	<th>#</th>
																	<th>Product ID</th>
																	<th>Product Name</th>
																	<th>Product Description</th>
																	<th>Product Quantity</th>
																	<th>Product Price</th>
																	<th>Action</th>
																	
																</tr>
															</thead>
															<tbody>

		                                                <?php  
		                                                   $i=1;
		                                                    foreach ($h as $row)  
		                                                   {  
		                                                 ?>

																<tr>
																	<td><?php echo $i++;?></td>
																	<td class="user-circle-img sorting_1"><img src="<?php echo base_url().'uploads/product/'.$row->image; ?>" style="width: 50px;height: 50px;" ></td>
																	<td><?php echo $row->product_name; ?></td>
																	<td><?php echo $row->sell_price; ?></td>
																	<td><?php echo $row->product_description; ?></td>
																	<td><?php echo $row->product_quantity; ?></td>
																	<td><?php echo $row->sell_price; ?></td>
																	<td>

				       <a class="btn btn-primary btn-xs" data-toggle="modal" data-target="#exampleModal<?php echo $row->id	 ; ?>"> <i class="fa fa-eye"></i> </a>
																
		              <a class="btn btn-primary btn-xs" data-toggle="modal" data-target="#exampleModal11<?php echo $row->id	 ; ?>"> <i class="fa fa-pencil-square-o"></i> </a>
		              
		              <a class="btn btn-danger btn-xs" onclick="return confirm('Are you sure?')"  href="<?php echo base_url().'Admin/Add_product/delete_product/'.$row->id  ?>" >
		                  <i class="fa fa-trash-o "></i>
		              </a>

																<!-- Modal -->
		<div class="modal fade" id="exampleModal<?php echo $row->id	 ; ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
		  <div class="modal-dialog modal-lg">
		    <div class="modal-content">
		      <div class="modal-header">
		        <h5 class="modal-title" id="exampleModalLabel">View All Product Details</h5>
		        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
		          <span aria-hidden="true">&times;</span>
		        </button>
		      </div>
		      <div class="modal-body">
		        <div class="card-body " style="">
					<form action="<?php echo base_url('Admin/Add_product/add_product');?>" id="form_sample_1" class="form-horizontal"  method="post"   novalidate="novalidate" enctype="multipart/form-data">
		                <div class="form-body">
		                      <div class="form-group row">
		                        <label class="control-label col-md-3">Category Name</label>
		                      <div class="col-md-9">
				                    <select class="form-control" name="category" id="category" required>
				                        <option value=""><?php echo $row->product_name; ?></option>
				                    </select>
		                        </div>
		                      </div>

		                                      

		                       <div class="form-group row">
		                         <label class="control-label col-md-3">Sub Category Name</label>
				                    <div class="col-md-9">     
				                     <select class="form-control" name="sub_category" id="sub_category" class="form-control" name="sub_category" required>
				                        <option value=""><?php echo $row->sub_category; ?></option>
				                     </select> 
				                    </div>
		                       </div>



		                       
		                      

		                      <div class="form-group row">
		                        <label class="control-label col-md-3">Product Name</label>
		                        <div class="col-md-9">
		                          <input type="text" name="product_name" data-required="1" value="<?php echo $row->product_name; ?>" class="form-control"> </div>
		                      </div>
		                      
		                      
		                      <div class="form-group row">
		                        <label class="control-label col-md-3">Sell Price </label>
		                        <div class="col-md-9">
		                          <input name="sell_price" type="text" value="<?php echo $row->sell_price; ?>" class="form-control">
		                        </div>
		                      </div>

		                      <div class="form-group row">
		                        <label class="control-label col-md-3">Offer Price
		                          <span class="required" aria-required="true"> * </span>
		                        </label>
		                        <div class="col-md-9">
		                          <input name="offer_price" type="text" value="<?php echo $row->offer_price; ?>" class="form-control">
		                        </div>
		                      </div>

		                      <div class="form-group row">
		                          <label class="col-lg-3 col-md-4 control-label">Product Size</label>
		                          <div class="col-md-9">   
		                              <select class="form-control" name="product_size[]">
		                                    <option value=""><?php echo $row->product_size; ?></option>       
		                             </select>
		                        </div>
		                      </div>

		                       

		                       <div class="form-group row">
		                          <label class="col-lg-3 col-md-4 control-label">Product  Colour</label>
		                          <div class="col-md-9">
		                                <select class="form-control" name="product_color[]">
		                                          <option value=""><?php echo $row->product_color; ?></option>
		                                </select>
		                        </div>
		                      </div>

		                                   
		                            

		                        <div class="form-group row">
		                           <label class="control-label col-md-3">Product  Description </label>  
		                              <div class="col-md-9">   
		                                 <textarea name="product_description" class="ckeditor" rows="3"> 
		                                    <?php echo $row->product_description; ?>
		                                 </textarea>
		                           </div>
		                        </div> 

		                        <div class="form-group row">
		                              <label class="control-label col-md-3">Product Quantity
		                              </label>
		                             <div class="col-md-9">
		                             <input name="product_quantity" type="text" value="  <?php echo $row->product_quantity; ?>" class="form-control">
		                          </div>
		                         </div>


		                                   <div class="form-group row">
		                                      <label class="control-label col-md-3">Product Type
		                                      </label>
		                                      <div class="col-md-9">
		                                        <select class="form-control" name="building_name[]">
		                                          <option value=""><?php echo $row->building_name; ?></option>
		                                        </select>
		                                      </div>
		                                    </div>

		                                     <div class="form-group row">
		                                      <label class="control-label col-md-3">Product Status
		                                      </label>
		                                      <div class="col-md-9">
		                                         <select class="form-control" name="product_status">
		                                          <option value=""><?php echo $row->product_status; ?></option>
		                                          
		                                        </select>
		                                      </div>
		                                   </div>


		                                    <div class="form-group row">
		                                      <label class="control-label col-md-3">Product Stock Stutus
		                                      </label>
		                                      <div class="col-md-9">
		                                        <select class="form-control" name="stock_status" required>
		                                          <option value=""><?php echo $row->product_status; ?></option>
		                                          
		                                        </select>
		                                      </div>
		                                    </div>
		                                    </div>                         
		                              </form>
								  </div>
		      </div>
		    </div>
		  </div>
		</div>


																<!-- Modal -->
		<div class="modal fade" id="exampleModal11<?php echo $row->id; ?>"   method="post"     aria-labelledby="exampleModalLabel" aria-hidden="true">
		  <div class="modal-dialog modal-lg">
		    <div class="modal-content">
		      <div class="modal-header">
		        <h5 class="modal-title" id="exampleModalLabel">Update</h5>
		        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
		          <span aria-hidden="true">&times;</span>
		        </button>
		      </div>
		      <div class="modal-body">
		        <div class="card-body " style="">
					 <form action="<?php echo base_url('Admin/Add_product_color/update_product_color');?>" method="post"  id="form_sample_1" class="form-horizontal" novalidate="novalidate"   role="form" enctype="multipart/form-data">
					  <div class="form-body">

		                      <div class="form-group row">
		                        <label class="control-label col-md-3">Category Name</label>
		                      <div class="col-md-9"> 
				                    <select class="form-control" name="category" id="category" required>
				                        <option value="">No Selected</option>


				                        <?php foreach($category as $rowss):?>
				                        <option value="<?php echo $row->id;?>" <?php echo $rowss->id == $row->category?"selected":""; ?>>
				                        	<?php echo $rowss->product_category_name;?>		
				                        </option>
				                        <?php endforeach;?>
				                     </select>
		                        </div>
		                      </div>

		                                      

		                    <div class="form-group row">
		                        <label class="control-label col-md-3">Sub Category Name </label>
		                    <div class="col-md-9">     
		                      <select class="form-control" name="sub_category" id="sub_category" class="form-control" name="sub_category" required>
	                              <option>No Selected</option>
	                              <?php foreach($sub_category as $rowss):?>
				                        <option value="<?php echo $row->id;?>" <?php echo $rowss->id == $row->sub_category?"selected":""; ?>>
				                        	<?php echo $rowss->floor_name;?>		
				                        </option>
			                        <?php endforeach;?>
	                          </select> 
		                      </div>
		                    </div>

		                      <div class="form-group row">
		                        <label class="control-label col-md-3">Product Name </label>
		                        <div class="col-md-9">
		                          <input type="text" name="product_name" data-required="1" value="<?php echo $row->product_name; ?>" class="form-control">
		                        </div>
		                      </div>
		                      
		                      
		                      <div class="form-group row">
		                        <label class="control-label col-md-3">Sell Price
		                          
		                        </label>
		                        <div class="col-md-9">
		                          <input name="sell_price" type="text" value="<?php echo $row->sell_price; ?>" class="form-control"> </div>
		                      </div>

		                      <div class="form-group row">
		                        <label class="control-label col-md-3">Offer Price
		                          <span class="required" aria-required="true"> * </span>
		                        </label>
		                        <div class="col-md-9">
		                          <input name="offer_price" type="text" value="<?php echo $row->offer_price; ?>" class="form-control"> </div>
		                      </div>
                              



					             <div class="form-group row">
			                        <label class="col-lg-3 col-md-4 control-label">Product Size</label>
			                          <div class="col-md-6">
			                          	<?php
			                          		$sizes = $row->product_size;
			                          		$sizes = explode(",", $sizes);
			                          	?>
			                          <select id="multiple" name="product_size[]" class="form-control select2-multiple" multiple>  
			                                <?php  
			                                  foreach ($size as $rowsa)  
			                                  {
			                                 ?>
			                                  <option value="<?php echo $rowsa->product_size; ?>" <?php echo in_array($rowsa->product_size, $sizes)?"selected":""; ?>>
			                                    <?php echo $rowsa->product_size; ?>
			                                  </option>
			                                 <?php
			                                  }
			                                 ?>
			                           
			                          </select>
			                        </div>
			                      </div>

		                    
                       <div class="form-group row">
                          <label class="col-lg-3 col-md-4 control-label">Product  Colour</label>
                          <div class="col-md-6">
                          	<?php
                          		$color = $row->product_color;
                          		$color = explode(",", $color);
                          	?>
                          <select id="multiple" name="product_color[]" class="form-control select2-multiple" multiple>   
                                <?php  
                                  foreach ($colors as $rowsab)  
                                  {  
                                 ?>
                                  <option value="<?php echo $rowsab->product_color_name; ?>" <?php echo in_array($rowsab->product_color_name, $color)?"selected":""; ?>>
                                    <?php echo $rowsab->product_color_name; ?>
                                  </option>
                                 <?php
                                  }
                                 ?>
                          </select>
                        </div>
                      </div>

		                                   
		                            

		                                <div class="form-group row">
		                                  <label class="control-label col-md-3">Product  Description
		                                  </label>
		                                  <div class="col-md-9">
		                                   <textarea name="product_description" class="ckeditor" rows="3"> 
		                                       <?php echo $row->product_description; ?>
		                                    </textarea>
		                                   </div>
		                                </div> 

		                              <div class="form-group row">
		                              <label class="control-label col-md-3">Product Quantity
		                              </label>
		                             <div class="col-md-9">
		                               <input name="product_quantity" type="text" value="  <?php echo $row->product_quantity; ?>" class="form-control"> </div>
		                             </div>


		                                   <div class="form-group row">
		                                      <label class="control-label col-md-3">Product Type
		                                      </label>
		                                      <div class="col-md-9">
				                                 <select class="form-control" name="building_name[]">
			                                        <option value="">Select...</option>
			                                           <?php  
			                                           foreach ($building_name as $rowsc)  
			                                            {  
			                                            ?>
			                                        <option <?php echo $rowsc->building_name == $row->building_name?"selected":""; ?> value="<?php echo $rowsc->building_name; ?>"><?php echo $rowsc->building_name; ?></option>
			                                          <?php
			                                           } 
			                                            ?>
			                                      </select>
		                                      </div>
		                                    </div>

		                                     <div class="form-group row">
		                                      <label class="control-label col-md-3">Product Status
		                                      </label>
		                                      <div class="col-md-9">
		                                         <select class="form-control" name="product_status">
		                                          <option value=""><?php echo $row->product_status; ?></option>
		                                          
		                                        </select>
		                                      </div>
		                                   </div>


		                                    <div class="form-group row">
		                                      <label class="control-label col-md-3">Product Stock Stutus
		                                      </label>
		                                      <div class="col-md-9">
		                                        <select class="form-control" name="stock_status" required>
		                                          <option value=""><?php echo $row->product_status; ?></option>
		                                          
		                                        </select>
		                                      </div>
		                                    </div>
		                                     <center>
												<button type="submit" class="btn btn-primary">Submit</button>
											 </center>
											 </form>
											</div>
		      </div>

		    </div>
		  </div>
		</div>
															</td>
																</tr>

																<?php
														      	}
															   ?>
																
																
															</tbody>
														</table>
													</div>
												</div>
											</div>
										</div>
								    </div>
				                </div>
			                </div>

	<script type="text/javascript">
	        $(document).ready(function(){
	            $('#category').change(function(){ 
	                var id=$(this).val();

	               alert(id);
	              
	                $.ajax({
	                    url : "<?php echo site_url('Admin/Add_product/get_sub_category');?>",
	                    method : "POST",
	                    data : {id: id},
	                    async : true,
	                    dataType : 'json',
	                    success: function(data){
	                         
	                        var html = '';
	                        var i;
	                        for(i=0; i<data.length; i++){
	                            html += '<option value='+data[i].id+'>'+data[i].floor_name+'</option>';
	                        }
	                        $('#sub_category').html(html);
	 
	                    }
	                });
	                return false;
	            }); 
	             
	        });
	    </script>
