            <!-- start page content -->
			<div class="page-content-wrapper">
				<div class="page-content">
					<div class="page-bar">
						<div class="page-title-breadcrumb">
							<div class=" pull-left">
								<div class="page-title">Setting</div>
							</div>
							<ol class="breadcrumb page-breadcrumb pull-right">
								<li><i class="fa fa-home"></i>&nbsp;<a class="parent-item"
										href="index.html">Home</a>&nbsp;<i class="fa fa-angle-right"></i>
								</li>
								<li><a class="parent-item" href="#">Setting</a>&nbsp;<i class="fa fa-angle-right"></i>
								</li>
								<li class="active">Setting</li>
							</ol>
						</div>
					</div>
					<?php if ($this->session->flashdata('update')): ?>
	                     <div class="alert text-white bg-success alert-dismissible" role="alert">
	                        <div class="iq-alert-text">
	                            <?php echo $this->session->flashdata('update'); ?>
	                        </div>
	                        <button type="button" class="close" data-dismiss="alert">&times;</button>
	                        <i class="ri-close-line"></i>
	                    </div>
                    <?php endif; ?>
					<div class="row">

			         <div class="col-md-6 col-sm-6">         
			         <div class="card card-topline-yellow">
			         
										<div class="card-head">
											<header>Footer Setting</header>
											<div class="tools">
												<a class="fa fa-repeat btn-color box-refresh" href="javascript:;"></a>
												<a class="t-collapse btn-color fa fa-chevron-down" href="javascript:;"></a>
												<a class="t-close btn-color fa fa-times" href="javascript:;"></a>
											</div>
										</div>
										<div class="card-body " style="">
										    <?php  
                                                   $i=1;
                                                    foreach ($h as $row)  
                                                   {  
                                                 ?>
										 <form action="<?php echo base_url('Admin/Setting/update_footer');?>" method="post"  role="form" enctype="multipart/form-data">
										 <div class="form-group">
				                           <label for="Image"> Old Footer logo </label>     
				                           <input type="disable" value="<?php echo $row->image; ?>" name="oldImage"  class="form-control" >
				                         </div>

				                        <div class="form-group">
				                           <label for="Image">Footer Logo </label>     
				                           <input type="file"  name="image"  class="form-control" style="padding-top: 3px;" >
				                           <input type="hidden" name="id" value="<?=$row->id?>">
				                        </div>

										 <div class="form-group">
										    <label for="Product Category">Footer description</label>
											 <textarea class="form-control" name="description" rows="3">
											 	 <?php echo $row->description ?>
											 </textarea>
										  </div>

                                          <div class="form-group">
										    <label for="Product Category">Address: </label>
										     <textarea class="form-control" name="address" rows="3">
											 	 <?php echo $row->address ?>
											 </textarea>
										  </div>

										   <div class="form-group">
										    <label for="Product Category">Mobile: </label>
											<input type="text" class="form-control"  value="<?php echo $row->contact ?>" name="contact">
										  </div>

                                           <div class="form-group">
										    <label for="Product Category">Support Link: </label>
											<input type="text" class="form-control" value="<?php echo $row->support_link ?>" name="support_link"  >
										   </div>

									      <button type="submit" class="btn btn-primary">Update</button>
									 </form>
									  <?php
									     }
									   ?>
									</div>
						</div>
					 </div>

					 <div class="col-md-6 col-sm-6">         
			         <div class="card card-topline-yellow">
			        
										<div class="card-head">
											<header>Social Media Links</header>
											<div class="tools">
												<a class="fa fa-repeat btn-color box-refresh" href="javascript:;"></a>
												<a class="t-collapse btn-color fa fa-chevron-down" href="javascript:;"></a>
												<a class="t-close btn-color fa fa-times" href="javascript:;"></a>
											</div>
										</div>
										<div class="card-body " style="">
										    <?php  
                                                   $i=1;
                                                    foreach ($s as $row)  
                                                   {  
                                                 ?>
										 <form action="<?php echo base_url('Admin/Setting/update_social_media');?>" method="post"  role="form" enctype="multipart/form-data">


                                          <div class="form-group">
										    <label for="Product Category">Facebook Link: </label>
											<input type="text" class="form-control" value="	<?php echo $row->facebook ?>" name="facebook">
											<input type="hidden" name="id" value="<?=$row->id?>">
										  </div>
										
                                          <div class="form-group">
										    <label for="Product Category">Instagram Link: </label>
											<input type="text" class="form-control" value="	<?php echo $row->instagram ?>" name="instagram">
										  </div>

										   <div class="form-group">
										    <label for="Product Category">Twitter Link: </label>
											<input type="text" class="form-control"  value="<?php echo $row->twitter ?>" name="twitter">
										  </div>

                                           <div class="form-group">
										    <label for="Product Category">linkedin Link: </label>
											<input type="text" class="form-control" value="<?php echo $row->linkedin ?>" name="linkedin"  >
										   </div>

									      <button type="submit" class="btn btn-primary"> Update </button>
									 </form>
									  <?php
									     }
									   ?>
									</div>
						</div>
					 </div>
				</div>
		  </div>
	  </div>
