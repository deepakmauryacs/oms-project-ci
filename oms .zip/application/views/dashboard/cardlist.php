        <!-- start page content -->
	<div class="page-content-wrapper">
		<div class="page-content">
			<div class="page-bar">
				<div class="page-title-breadcrumb">
					<div class=" pull-left">
						<div class="page-title"><?php echo $name; ?></div>
					</div>
					<ol class="breadcrumb page-breadcrumb pull-right">
						<li><i class="fa fa-home"></i>&nbsp;<a class="parent-item"
								href="#">Home</a>&nbsp;<i class="fa fa-angle-right"></i>
						</li>
						<li><a class="parent-item" href="#"><?php echo $name; ?></a>&nbsp;<i class="fa fa-angle-right"></i>
						</li>
						<li class="active">Apartments</li>
					</ol>
				</div>
			</div>
			<div class="row">
			        <div class="col-md-12 center">
			      		<h3>Apartments List</h3>
			        </div>
			       <div class="col-md-12" id="Appartments">
			          

			<?php
			$cards = "";
			$grandTotalCapacity = 0;
			$grandTotalOccupied = 0;
			$grandTotalReserved =0; 
			$grandTotalVacant = 0;
			      if(!empty($floors))
		          {
		              

		          	 //print_r($floors);
		              foreach ($floors as $key => $value) {
		                  
		              $floorName = get_field_value(' tbl_floor','floor_name',['id'=>$value->floor_id]);

		               $sql="SELECT SUM(`bed_count`) as total FROM `checkin_checkout` WHERE `status`='1' AND `apartment_id`='".$value->id."'";
		               $occupancy=$this->db->query($sql)->row_array();

		               $sql="SELECT SUM(`bed_count`) as total FROM `checkin_checkout` WHERE `status`='4' AND `apartment_id`='".$value->id."'";
		               $reserved=$this->db->query($sql)->row_array();


		              $sql="SELECT SUM(`total_bed`) as total FROM `room` WHERE `apartments`='".$value->id."'";
		              $capacity=$this->db->query($sql)->row_array();
		              
		               $check_now=$capacity['total']-($occupancy['total']+ $reserved['total']);
                        //echo $occupancy['total']+$reserved['total'].'=====';
		               $cards .=' <div class="col-xl-3 col-md-3 col-sm-6 " style="margin-top: 10px;">
		                          <div class="white-box">
		                              <div style="background: #89cff0;">
		                                <p style="text-align: center;font-weight: 600;line-height: 60px;"> '.$floorName."&nbsp;/&nbsp;".$value->apartment.'<span></span></p>
		                              </div>
		                              <div>
		                                  <p class="info-box-text" style="color: #08417a;font-weight: 600;text-align: center;font-size: 14px;"> Total Capacity :  '.(!empty($capacity['total'])?$capacity['total']:'0').'</p>
    		                              <p class="info-box-text" style="color: #b60b0b;text-align: center;font-size: 14px;"> Occupied Beds : <span>'.(!empty($occupancy['total'])?$occupancy['total']:'0').'</span></p>
    		                              <p class="info-box-text" style="color: #eda061;text-align: center;font-size: 14px;"> Reserved Beds : <span>'.(!empty($reserved['total'])?$reserved['total']:'0').'</span></p>
    		                              <p class="info-box-text" style="color: #064b1a;text-align: center;font-size: 14px;"> Vacant Beds : <span>'.($capacity['total']-($occupancy['total']+$reserved['total'])).'</span></p>';
    		          if($check_now>0): 
    		          $cards .= '<div class="text-center"><a class="btn btn-info" href="'.base_url().'Admin/Admin/checkIn/'.$value->id.'" style="margin:5px;font-size:10px">Check In</a>';
    		          else:
    		          $cards .= '<div class="text-center"><a class="btn btn-info" href="javascript: void(0);" style="margin:5px; font-size:10px" >Fully Occupied</a>';
    		          endif;
    		          $cards .= '<a class="btn" style="background-color:#ee8a0a;color:#ffff;font-size:10px" href="'.base_url().'Admin/View/checkIn/'.$value->id.'">View</a>
		                              </div>
		                          </div>
		                          </div>
		                        </div>';
		                $grandTotalCapacity += !empty($capacity['total'])?$capacity['total']:0;
		                $grandTotalOccupied += !empty($occupancy['total'])?$occupancy['total']:0;
		                $grandTotalReserved += !empty($reserved['total'])?$reserved['total']:0;
		                $grandTotalVacant += ($capacity['total']-($occupancy['total']+$reserved['total']));
		                
		            }
		          }

          ?>
          <div class="row">
							<div class="col-xl-3 col-md-3 col-12">
								<div class="info-box"  style="background-color: #0d5190;display: block;color: #fff;">
									<span class="info-box-icon push-bottom"><i class="fa fa-bar-chart"></i></span>
									<div class="info-box-content">
										<span class="info-box-text" style="font-size: 14px;">Total Capacity </span>
										<span class="info-box-number">
										    <?php echo $grandTotalCapacity; ?>
										 </span>
										<div class="progress">
											<div class="progress-bar width-60"></div>
										</div>
										
									</div>
									<!-- /.info-box-content -->
								</div>
								<!-- /.info-box -->
							</div>
							<!-- /.col -->
							<div class="col-xl-3 col-md-3 col-12">
								<div class="info-box" style="background-color: #1579d7;display: block;color: #fff;">
									<span class="info-box-icon push-bottom"><i
											class="fa fa-bed"></i></span>
									<div class="info-box-content">
										<span class="info-box-text" style="font-size: 14px;">Occupied Beds</span>
										<span class="info-box-number">
										 <?php echo $grandTotalOccupied; ?>
										 </span>
										<div class="progress">
											<div class="progress-bar width-40"></div>
										</div>
										
									</div>
									<!-- /.info-box-content -->
								</div>
								<!-- /.info-box -->
							</div>
							<!-- /.col -->
							<div class="col-xl-3 col-md-3 col-12">
								<div class="info-box" style="background-color: #489be7;display: block;color: #fff;">
									<span class="info-box-icon push-bottom"><i class="fa fa-bed"></i></span>
									<div class="info-box-content">
										<span class="info-box-text" style="font-size: 14px;">Reserved Beds </span>
										<span class="info-box-number">
										<?php echo $grandTotalReserved; ?>
										</span>
										<div class="progress">
											<div class="progress-bar width-80"></div>
										</div>
										
									</div>
									<!-- /.info-box-content -->
								</div>
								<!-- /.info-box -->
							</div>
							<!-- /.col -->

														<!-- /.col -->
							<div class="col-xl-3 col-md-3 col-12">
								<div class="info-box" style="background-color: #489be7;display: block;color: #fff;">
									<span class="info-box-icon push-bottom"><i class="fa fa-bed"></i></span>
									<div class="info-box-content">
										<span class="info-box-text" style="font-size: 14px;">Vacant Beds </span>
										<span class="info-box-number">
										<?php echo $grandTotalVacant; ?>
										</span>
										<div class="progress">
											<div class="progress-bar width-80"></div>
										</div>
										
									</div>
									<!-- /.info-box-content -->
								</div>
								<!-- /.info-box -->
							</div>
							<!-- /.col -->
						</div>
   
                    <div class="row">
                        <?php echo $cards; ?>
                    </div>
			     </div>
			    </div>

            </div>
        </div>
     </div>
   </div>
   