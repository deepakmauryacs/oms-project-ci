        <!-- start page content -->
				<div class="page-content-wrapper">
					<div class="page-content">
						<div class="page-bar">
							<div class="page-title-breadcrumb">
								<div class=" pull-left">
									<div class="page-title">Checkin</div>
								</div>
								<ol class="breadcrumb page-breadcrumb pull-right">
									<li><i class="fa fa-home"></i>&nbsp;<a class="parent-item"
											href="#">Home</a>&nbsp;<i class="fa fa-angle-right"></i>
									</li>
									<li><a class="parent-item" href="#">Checkin</a>&nbsp;<i class="fa fa-angle-right"></i>
									</li>
									<li class="active">Add Checkin</li>
								</ol>
							</div>
						</div>
						<div class="row">
				           <div class="col-md-12 col-sm-12">
	                              
				         <div class="card card-topline-yellow">
				          <?php if ($this->session->flashdata('success')): ?>
	                       <div class="alert text-white bg-success alert-dismissible" role="alert">
	                         <div class="iq-alert-text">
	                            <?php echo $this->session->flashdata('success'); ?>
	                         </div>
	                         <button type="button" class="close" data-dismiss="alert">&times;</button>
	                         <i class="ri-close-line"></i>
	                       </div>
	                      <?php endif; ?>
						<div class="card-head">
							<header>Checkin</header>
							<div class="tools">
								<a class="fa fa-repeat btn-color box-refresh" href="javascript:;"></a>
								<a class="t-collapse btn-color fa fa-chevron-down" href="javascript:;"></a>
								<a class="t-close btn-color fa fa-times" href="javascript:;"></a>
							</div>
						</div>
		<div class="card-body " style="">
		 
         <form action="<?php echo base_url('Admin/Add_room/Checkin');?>" method="post" role="form" enctype="multipart/form-data">
           <div class="contener">
           	<div class="row">
               <div class="form-group col-md-6">
               	<input type="hidden" name="apartmentid" value="<?php echo $apartmentid; ?>">
    
	            <label for="Product Category">Select Room</label>
	            <select class="form-control" name="roomId"  required>
	            	<?php foreach($rooms as $room){ ?>
	            	<option  value="<?php echo $room->id; ?>"> <?php echo $room->room_no; ?> </option>
	            <?php } ?>
	            
	            </select>
	          </div>


	          <div class="form-group col-md-6">
	            <label for="Product Category">Guest Id</label>
	            <input type="text" class="form-control" name="guest_id"  required>
	            
	            <?php  
	             if (!empty($rooms)){
	            ?>
	            <input type="hidden" name="building_id" value="<?php echo $rooms[0]->building_name; ?>">
	            <input type="hidden" name="floor_id" value="<?php echo $rooms[0]->floor_name; ?>"> 
	            <?php
	            }
	            ?>
	          </div>

	           <div class="form-group col-md-6">
	            <label for="Product Category">Full Name</label>
	            
	            <input type="text" class="form-control" name="custmer_name"  required>
	           </div>

	           <!--<div class="form-group col-md-6">-->
	           <!-- <label for="Product Category">Arrival Date</label>-->
	           <!-- <input type="date" class="form-control" name="arrival_date"  required>-->
	           <!--</div>-->

              
              
              <div class="form-group col-md-6">
	            <label for="Product Category">Gender</label>
	            <select class="form-control" name="gender"  required>
	            	<option  value="Male"> Male</option>
	            	<option  value="Female"> Female</option>
	            </select>
	          </div>


	           <div class="form-group col-md-6">
	            <label for="Product Category">Contact Number</label>
	            <input type="number" class="form-control" name="contact_number"  required>
	          </div>
              

	           <div class="form-group col-md-6">
	            <label for="Product Category">Flight</label>
	            <input type="text" class="form-control" name="flight"  required>
	           </div>

	           <div class="form-group col-md-6">
	            <label for="Product Category">Sponsor Phone</label>
	            <input type="text" class="form-control" name="sponsor_phone"  required>
	           </div>
                
               <div class="form-group col-md-6">
	            <label for="Product Category">Food Preference</label>
	            <select class="form-control" name="food_preference"  required>
	            	<option  value="Veg"> Veg</option>
	            	<option  value="Non-Veg"> Non-Veg</option>
	            </select>
	          </div>

              <div class="form-group col-md-6">
	            <label for="Product Category">Blood Group</label>
	            <input type="text" class="form-control" name="blood_group"  required>
	          </div>

	          <div class="form-group col-md-6">
	            <label for="Product Category">Nationality</label>
	           
	            <select class="form-control" name="nationality"  required>
	            	<option  value="Indian"> Indian</option>
	            	<option  value="Philippines"> Philippines</option>
	            </select>
	          </div>

	          <div class="form-group col-md-6">
	            <label for="Product Category">Passport Number</label>
	            <input type="text" class="form-control" name="passport_number"  required>
	          </div>

	           <div class="form-group col-md-6">
	            <label for="Product Category">Civil ID Number</label>
	            <input type="text" class="form-control" name="civilid_number"   required>
	          </div>

	           <div class="form-group col-md-6">
	            <label for="Product Category">Emergency Contact Number</label>
	            <input type="number" class="form-control" name="emergency_contact_number"   required>
	          </div>

	          <div class="form-group col-md-6">
	            <label for="Product Category">Emergency Contact Relationship</label>
	            <input type="text" class="form-control" name="emergency_contact_relationship"   required>
	             <input type="hidden" class="form-control" value="1" name="bed_count" >
	          </div>


	          <div class="form-group col-md-6">
	            <label for="Product Category">Enter Quarantine Days</label>
	            <input type="text" class="form-control" name="quarantine_days" value="14" required>
	          </div>
	          
	          <div class="form-group col-md-12">
	            <label for="">About Guest</label>
	            <textarea name="about_guest" class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
	              <!--<textarea name="about_guest" class="form-control" rows="5" required>-->
	            	
	             </textarea>
	          </div>
             
              <div class="form-group col-md-6">
	            <label for="Product Category">Status</label>
	           
	            <select class="form-control" name="status" id="status"  required>
	            	<option  value="" selected> Select Status </option>
	            	<option  value="4"> Reserved </option>
	            	<option  value="1"> Checkin  </option>
	            </select>
	          </div>

	          <div class="form-group col-md-12" id="reserved" style="display: none;">
	            <label for="Product Category">Reserved Date</label>
	            <input type="date" class="form-control" name="reserved_date" > 
	          </div>


	          <div class="form-group col-md-12" id="checkins" style="display: none;">
	            <label for="Product Category">Checkin Date</label>
	            <input type="date" class="form-control" name="date" >
	          </div>

	         </div>
	         <center>
               <button type="submit" class="btn btn-primary">Checkin</button>
            </center>
         </form>      
         
     </div>
		
		</div>
	</div>
</div>
</div>
</div>
</div>
</div>
</div>
<script>
	$("#status").on("change", function(){
		var status = $(this).val();

		switch(status){
			case "4":
				$("#checkins").css("display", "none");
				$("#reserved").css("display", "block");
				break;
			case "1":
				$("#reserved").css("display", "none");
				$("#checkins").css("display", "block");
				break;
		}
	});
</script>