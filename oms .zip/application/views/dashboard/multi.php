<!doctype html>
<html>
  <head>
   <title>How to upload Multiple Files and Images in CodeIgniter</title>
  </head>
  <body>
    <!-- Display Message -->
    <b><?php if(isset($filenames)) echo "Successfully uploaded ".count($filenames)." files"; ?></b>
    
    <!-- Form -->
    <form method='post' action='<?php echo base_url(); ?>Admin/Multi/add_multi' enctype='multipart/form-data'>
      <input type='file' name='files[]' multiple > <br/><br/>
      <input type='submit' value='Upload' name='upload' />
    </form>
 
  </body>
</html>
