<!-- start page content -->
<div class="page-content-wrapper">
 <div class="page-content">
   <div class="page-bar">
     <div class="page-title-breadcrumb">
       <div class=" pull-left">
         <div class="page-title">Add Apartment</div>
       </div>
        <ol class="breadcrumb page-breadcrumb pull-right">
          <li><i class="fa fa-home"></i>&nbsp;<a class="parent-item" href="index.html">Home</a>&nbsp;<i class="fa fa-angle-right"></i>
          </li>
          <li><a class="parent-item" href="#">Apartment</a>&nbsp;<i class="fa fa-angle-right"></i>
          </li>
          <li class="active">Apartment</li>
        </ol>
     </div>
   </div>

   <div class="row">
     <div class="col-md-6 col-sm-6">
       <div class="card card-topline-yellow">
         <?php if ($this->session->flashdata('success')): ?>
          <div class="alert text-white bg-success alert-dismissible" role="alert">
            <div class="iq-alert-text">
             <?php echo $this->session->flashdata('success'); ?>
            </div>
            <button type="button" class="close" data-dismiss="alert">&times;</button>
            <i class="ri-close-line"></i>
          </div>
        <?php endif; ?>
        <div class="card-head">
         <header>Add Apartment</header>
          <div class="tools">
            <a class="fa fa-repeat btn-color box-refresh" href="javascript:;"></a>
            <a class="t-collapse btn-color fa fa-chevron-down" href="javascript:;"></a>
            <a class="t-close btn-color fa fa-times" href="javascript:;"></a>
         </div>
        </div>
        <div class="card-body">
         <form action="<?php echo base_url('Admin/Add_apartment/add_apartment');?>" method="post" role="form" enctype="multipart/form-data">
           <div class="form-group">
                                        <label class="control-label">Building Name
                                          <span class="required" aria-required="true"> * </span>
                                        </label>
                                         <!--  <?php print_r ($building_name);  ?> -->
                                          <select class="form-control" name="building_name" required onchange="get_floors(this.value);">
                                            <option value="">Select...</option>
                                              <?php  
                                                foreach ($building_name as $rowap) {
                                              ?>
                                            <option   value="<?php echo $rowap->id; ?>"><?php echo $rowap->building_name; ?></option>
                              
                                            <?php
                                             } 
                                              ?>
                                          </select>
                                         
                                    
                                      </div> 

        
                                      <div class="form-group">
                                        <label>Floor Name
                                          <span class="required" aria-required="true"> * </span>
                                        </label>
                                        
                                          <select class="form-control" name="floor_name" required id="get_floorss" onchange="get_apartment(this.value);">
                                            <option value="">Select...</option>
                                              <?php  
                                             foreach ($floor_name as $rowfl)  
                                              {  
                                              ?>
                                            <option   value="<?php echo $rowfl->id; ?>"><?php echo $rowfl->floor_name; ?></option>
                                            <?php
                                             } 
                                              ?>
                                          </select>
                                         
                                       
                                      </div> 





          <div class="form-group">
            <label for="Product Category">Apartment</label>
            <input type="text" class="form-control" name="apartment" placeholder="Enter Apartment Name" required>
          </div>

          <button type="submit" class="btn btn-primary">Submit</button>
         </form>
        </div>
      </div>
    </div>

    <div class="col-md-6 col-sm-6">
     <div class="card card-topline-yellow">
      <?php if ($this->session->flashdata('update')): ?>
      <div class="alert text-white bg-success alert-dismissible" role="alert">
        <div class="iq-alert-text">
          <?php echo $this->session->flashdata('update'); ?>
        </div>
        <button type="button" class="close" data-dismiss="alert">&times;</button>
        <i class="ri-close-line"></i>
        </div>
     <?php endif; ?>

    <?php if ($this->session->flashdata('delete')): ?>
     <div class="alert text-white bg-danger alert-dismissible" role="alert">
     <div class="iq-alert-text">
     <?php echo $this->session->flashdata('delete'); ?>
     </div>
    <button type="button" class="close" data-dismiss="alert">&times;</button>
     <i class="ri-close-line"></i>
    </div>
    <?php endif; ?>
    <div class="card-head">
     <header>All Apartment</header>
      <div class="tools">
        <a class="fa fa-repeat btn-color box-refresh" href="javascript:;"></a>
        <a class="t-collapse btn-color fa fa-chevron-down" href="javascript:;"></a>
        <a class="t-close btn-color fa fa-times" href="javascript:;"></a>
      </div>
    </div>
     <div class="card-body">
       <div class="table-scrollable">
         <table class="table table-bordered display full-width" id="example">
            <thead>
               <tr>
                 <th>#</th>
                 <th>Building</th>
                 <th>Floor</th>
                 <th>Apartment</th>
                 <th>Action</th>
                </tr>
            </thead>
            <tbody>
            <?php  
             $i=1;
             foreach ($add_apartments as $row)  
                {  
            ?>
                                    
               <tr>
                 <td><?php echo $i;?></td>
                 

                 <td>
                 <?php echo get_field_value('tbl_building','building_name',['id'=>$row->building_id])      ; ?>
                 </td>


                 <td>
                 <?php echo get_field_value('tbl_floor','floor_name',['id'=>$row->floor_id])      ; ?>
                 </td>
                 
                 <td>
                 <?php echo $row->apartment  ; ?>
                 </td>
                 <td>
                 <a class="btn btn-primary btn-xs" data-toggle="modal" data-target="#exampleModal<?php echo $row->id  ; ?>"> <i class="fa fa-pencil-square-o"></i> </a>

                 <a class="btn btn-danger btn-xs" onclick="return confirm('Are you sure?')" href="<?php echo base_url().'Admin/Add_apartment/delete_add_sub_category/'.$row->id  ?>">
                 <i class="fa fa-trash-o "></i>
                 </a>


                                            <!-- Modal -->
              <div class="modal fade" id="exampleModal<?php echo $row->id  ; ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                 <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Update</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                  </div>
                  <div class="modal-body">
                  <div class="card-body">
                  <form action="<?php echo base_url('Admin/Add_sub_category/update_add_sub_category');?>" method="post" role="form" enctype="multipart/form-data">



         <div class="form-group">
            <label for="Product Category">Building</label>
             <select class="form-control" name="building_name" required onchange="get_floors(this.value);">
                <option value="">Select...</option>
                  <?php  
                    foreach ($building_name as $rowap) {
                  ?>
                <option   value="<?php echo $rowap->id; ?>"><?php echo $rowap->building_name; ?></option>

                <?php
                 } 
                  ?>
              </select>
         </div>

         <div class="form-group">
            <label for="Product Category"> Floor</label>
           <select class="form-control" name="floor_name" required id="get_floorss" onchange="get_apartment(this.value);">
                <option value="">Select...</option>
                  <?php  
                 foreach ($floor_name as $rowfl)  
                  {  
                  ?>
                <option   value="<?php echo $rowfl->id; ?>"><?php echo $rowfl->floor_name; ?></option>
                <?php
                 } 
                  ?>
              </select>
         </div>





          <div class="form-group">
            <label for="Product Category">Apartment</label>
            <input type="text" class="form-control" name="apartment" value="<?php echo $row->apartment  ; ?>" required>
            <input type="hidden" name="id" value="<?=$row->id?>">
          </div>





              




                <button type="submit" class="btn btn-primary">Submit</button>
                 </form>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php $i++;
                                      }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

 <!--------------------check in popup end----------------------------->
<script type="text/javascript">

  function get_floors(bilding_id)
  {
     $.ajax({
               type: "POST",
               url: '<?php echo base_url();?>Admin/Add_roomno/get_floors',
               data: {bilding_id:bilding_id}, // serializes the form's elements.
               beforeSend:function()
              {
                
              },
              success:function(responce)
              {

                $('#get_floorss').html(responce);
              },
              error:function()
              {
                alert('Error');
                
              },
              complete:function()
              {
                
              }
            }); 

  }

  function get_apartment(floor_id)
  {
     $.ajax({
               type: "POST",
               url: '<?php echo base_url();?>Admin/Add_roomno/get_apartment',
               data: {floor_id:floor_id}, // serializes the form's elements.
               beforeSend:function()
              {
                
              },
              success:function(responce)
              {

                $('#get_apartments').html(responce);
              },
              error:function()
              {
                alert('Error');
                
              },
              complete:function()
              {
                
              }
            }); 

  }
</script>