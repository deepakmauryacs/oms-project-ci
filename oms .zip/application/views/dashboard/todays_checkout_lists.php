<!-- start page content -->
	<div class="col-md-12">
		
		<!-- start widget -->
		<div class="state-overview">
			<div class="row">
				<?php 
				foreach ($building as $row)
				 {
				?>
					
				<div class="col-xl-3 col-md-6 col-12">
					
					<a  href="<?php echo base_url() ?>Admin/Dashoard_room/cardlist/<?php  echo $row->id; ?>"  class="info-box" style="background-color:#e67d21e6;display: block;color: #fff;">
					
						
						<div class="info-box-content" style="margin-left:10px;">
							<span class="info-box-text" style="font-size: 14px;">Building &nbsp:&nbsp<?php echo $row->building_name;  ?> </span>
							
						   
						    <span class="info-box-number" style="font-size: 14px;">
							  Today's Checked Out :&nbsp<?php
										 $sql="SELECT SUM(`total_bed`) as total FROM `room` WHERE building_name = $row->id ";

										 $sql_m="SELECT COUNT(*) as total FROM `checkin_checkout`,`apartment` WHERE `checkin_checkout`.apartment_id=`apartment`.id AND `apartment`.building_id='$row->id' AND `checkin_checkout`.status ='2' AND  DATE(date) = DATE(NOW())";
										 $sql_m=$this->db->query($sql_m)->row_array();
										 print_r($sql_m['total']);
										 
                                ?>
						    </span>
							<div class="progress">
								<div class="progress-bar width-60"></div>
							</div>
							
						</div>
						<!-- /.info-box-content -->
					
					</a>
					<!-- /.info-box -->
				</div>
				<!-- /.col -->

				<?php
			     }
			    ?>
				
			</div>
	     </div>
     </div>
  


  

