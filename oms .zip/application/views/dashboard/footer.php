		<!-- start footer -->
		<div class="page-footer">
			<div class="page-footer-inner"> 2020 &copy;  OMS Developed By
				<a href="javascript:void(0);" target="_top" class="makerCss">KRH</a>
			</div>
			<div class="scroll-to-top">
				<i class="icon-arrow-up"></i>
			</div>
		</div>
		<!-- end footer -->
	</div>
	
	
	<!-- start js include path -->
	<script src="<?php echo base_url() ?>assetes/dashboard/assets/plugins/popper/popper.min.js"></script>
	<script src="<?php echo base_url() ?>assetes/dashboard/assets/plugins/jquery-blockui/jquery.blockui.min.js"></script>
	<script src="<?php echo base_url() ?>assetes/dashboard/assets/plugins/jquery-slimscroll/jquery.slimscroll.min.js"></script>
	<!-- bootstrap -->
	<script src="<?php echo base_url() ?>assetes/dashboard/assets/plugins/bootstrap/js/bootstrap.min.js"></script>
	<script src="<?php echo base_url() ?>assetes/dashboard/assets/plugins/sparkline/jquery.sparkline.min.js"></script>
	<script src="<?php echo base_url() ?>assetes/dashboard/assets/js/pages/sparkline/sparkline-data.js"></script>
	<!-- Common js-->
	<script src="<?php echo base_url() ?>assetes/dashboard/assets/js/app.js"></script>
	<script src="<?php echo base_url() ?>assetes/dashboard/assets/js/layout.js"></script>
	<script src="<?php echo base_url() ?>assetes/dashboard/assets/js/theme-color.js"></script>
	<!-- material -->
	<script src="<?php echo base_url() ?>assetes/dashboard/assets/plugins/material/material.min.js"></script>
	<!-- animation -->
	<script src="<?php echo base_url() ?>assetes/dashboard/assets/js/pages/ui/animations.js"></script>
	<!-- morris chart -->
	<script src="<?php echo base_url() ?>assetes/dashboard/assets/plugins/morris/morris.min.js"></script>
	<script src="<?php echo base_url() ?>assetes/dashboard/assets/plugins/morris/raphael-min.js"></script>
	<script src="<?php echo base_url() ?>assetes/dashboard/assets/js/pages/chart/morris/morris_home_data.js"></script>
	<!-- end js include path -->

	 <script src="<?php echo base_url() ?>assetes/dashboard/assets/plugins/dropzone/dropzone.js"></script>
    <!--tags input-->
    <script src="<?php echo base_url() ?>assetes/dashboard/assets/plugins/jquery-tags-input/jquery-tags-input.js"></script>
    <script src="<?php echo base_url() ?>assetes/dashboard/assets/plugins/jquery-tags-input/jquery-tags-input-init.js"></script>

	<!--select2-->
    <script src="<?php echo base_url() ?>assetes/dashboard/assets/plugins/select2/js/select2.js"></script>
    <script src="<?php echo base_url() ?>assetes/dashboard/assets/js/pages/select2/select2-init.js"></script>

     <!-- data tables -->
     
<script src="https://cdn.datatables.net/1.10.22/js/jquery.dataTables.min.js"></script>
 <script src="https://cdn.datatables.net/buttons/1.6.5/js/dataTables.buttons.min.js"></script>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
 <script src="https://cdn.datatables.net/buttons/1.6.5/js/buttons.html5.min.js"></script>
 
 <style type="text/css">
 	.dataTables_wrapper .dt-buttons{ float: left !important ; }
 </style>
<script type="text/javascript">
	$('#example').DataTable({"dom": 'Bfrtip',
    "buttons": [
            // 'copyHtml5',
            'excelHtml5'
            // 'csvHtml5',
            // 'pdfHtml5'
        ]});
        
        

</script>
</body>
</html>