			<!-- start page content -->
			<div class="page-content-wrapper">
				<div class="page-content">
					<div class="page-bar">
						<div class="page-title-breadcrumb">
							<div class=" pull-left">
								<div class="page-title">Contacts</div>
							</div>
							<ol class="breadcrumb page-breadcrumb pull-right">
								<li><i class="fa fa-home"></i>&nbsp;<a class="parent-item"
										href="index.html">Home</a>&nbsp;<i class="fa fa-angle-right"></i>
								</li>
								<li><a class="parent-item" href="#">Contacts</a>&nbsp;<i class="fa fa-angle-right"></i>
								</li>
								<li class="active">Contacts List</li>
							</ol>
						</div>
					</div>
					 <?php if ($this->session->flashdata('delete')): ?>
		             <div class="alert text-white bg-danger alert-dismissible" role="alert">
		             <div class="iq-alert-text"> <?php echo $this->session->flashdata('delete'); ?></div>

		             <button type="button" class="close" data-dismiss="alert">&times;</button>
		             <i class="ri-close-line"></i>
		            
		             </div>
		            <?php endif; ?>
					<div class="row">
			           <div class="col-sm-12 col-md-12 col-lg-12">
							<div class="card card-box">
								<div class="card-head">
									<header>Contacts List</header>
									<div class="tools">
										<a class="fa fa-repeat btn-color box-refresh" href="javascript:;"></a>
										<a class="t-collapse btn-color fa fa-chevron-down" href="javascript:;"></a>
										<a class="t-close btn-color fa fa-times" href="javascript:;"></a>
									</div>
								</div>
								<div class="card-body ">
									<div class="table-scrollable">
										<table class="table table-hover table-checkable order-column full-width"
											id="example4">
											<thead>
												<tr>
													<th class="center">S No.</th>
													<th class="center"> Name </th>
													<th class="center"> Mobile </th>
													<th class="center"> Email </th>
													<th class="center"> Message </th>
													<th class="center"> Action </th>
												</tr>
											</thead>
											<tbody>
												<?php
												foreach ($h as $key => $value) {
													
												?>
												<tr class="odd gradeX">
													<td class="user-circle-img"><?php echo $key+1; ?></td>
													<td class="center"><?php echo $value->name; ?></td>
													<td class="center"><?php echo $value->contact; ?></td>
													<td class="center"><?php echo $value->email; ?> </td>
													<td class="center"><?php echo $value->message; ?></td>
													<td>
														 <a class="btn btn-danger btn-xs" onclick="return confirm('Are you sure?')"  href="<?php echo base_url().'Admin/Contact/delete_contact/'.$value->id  ?>" >
		                                                  <i class="fa fa-trash-o "></i>
		                                                 </a>
													</td>
												</tr>
												<?php }
												?>
												
											</tbody>
										</table>
									</div>
								</div>
							</div>
						</div>
					 </div>

					
					
					

		</div>
	</div>



