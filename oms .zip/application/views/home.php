<!DOCTYPE html>
<html lang="en">
<head>
	<title>Occupancy Management System</title>
	<!-- META TAGS -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- FAV ICON(BROWSER TAB ICON) -->
	<link rel="shortcut icon" href="images/fav.ico" type="image/x-icon">
	<!-- GOOGLE FONT -->
	<link href="https://fonts.googleapis.com/css?family=Poppins%7CQuicksand:500,700" rel="stylesheet">
	<!-- FONTAWESOME ICONS -->
	<link rel="stylesheet" href="<?php echo base_url() ?>assetes/web/css/font-awesome.min.css">
	<!-- ALL CSS FILES -->
	<link href="<?php echo base_url() ?>assetes/web/css/materialize.css" rel="stylesheet">
	<link href="<?php echo base_url() ?>assetes/web/css/style.css" rel="stylesheet">
	<link href="<?php echo base_url() ?>assetes/web/css/bootstrap.css" rel="stylesheet" type="text/css" />
	<!-- RESPONSIVE.CSS ONLY FOR MOBILE AND TABLET VIEWS -->
	<link href="css/responsive.css" rel="stylesheet">
	<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
	<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	<!--[if lt IE 9]>
	<script src="js/html5shiv.js"></script>
	<script src="js/respond.min.js"></script>
	<![endif]-->
	<style type="text/css">
		
	.form {
    width: 35%;
    display: inline-block;
    overflow: hidden;
    float: right;
    padding: 50px;
    margin-top: 40px;
    background: #f4364fc4;
    z-index: 999999999;
    position: relative;
}
label {
    font-size: 14px;
    color: #ffffff;
    font-weight: 100 !important;
}
.form-control {
    font-weight: 300;
    color: #fff !important;
}
.form .form-control::placeholder {
    color: #fff !important;
    font-weight: 200;
}
.btm-login {
    background: #ffffff;
    padding: 7px 25px;
    color: #f4364f;
    text-transform: uppercase;
    font-weight: 600;
    font-family: 'Quicksand', sans-serif;
    border-radius: 2px;
    font-size: 14px;
    border: 0px;
    font-weight: 200;
}
.btm-login:focus {
    background: #0f145e;
    color: #fff;
}
	</style>
</head>

<body data-ng-app="">
	<!--MOBILE MENU-->
	<section>
		<div class="mm">
			<div class="mm-inn">
				<div class="mm-logo">
					<a href="main.html"><img src="<?php echo base_url() ?>assetes/web/images/logo.png" alt="">
					</a>
				</div>
				<div class="mm-icon"><span><i class="fa fa-bars show-menu" aria-hidden="true"></i></span>
				</div>
				<div class="mm-menu">
					<div class="mm-close"><span><i class="fa fa-times hide-menu" aria-hidden="true"></i></span>
					</div>
					
				</div>
			</div>
		</div>
	</section>
	<!--HEADER SECTION-->
	<section class="main">
		<!--TOP SECTION-->
		<div class="menu-section">
			<div class="container">
				<div class="row">
					
					<div class="all-drop-down">
	
						
						
					
					</div>
				</div>
				<div class="row">
					<div class="logo" style="background: white;
    width: 110px;">
						<a href="main.html"><img src="<?php echo base_url() ?>assetes/dashboard/login/img/login_logo.png" alt="" style="height: 40px;">
						</a>
					</div>
					<div class="menu-bar">
						<ul>
							
							<li><a href="#">Home</a>
							</li>
							<li><a href="#" id="digital-clock"></a>
							</li>
							
					
							</li>
						</ul>
					</div>
				</div>
			</div>
		</div>

		110
<script type="text/javascript">
function getDateTime() {
        var now     = new Date(); 
        var year    = now.getFullYear();
        var month   = now.getMonth()+1; 
        var day     = now.getDate();
        var hour    = now.getHours();
        var minute  = now.getMinutes();
        var second  = now.getSeconds(); 
        if(month.toString().length == 1) {
             month = '0'+month;
        }
        if(day.toString().length == 1) {
             day = '0'+day;
        }   
        if(hour.toString().length == 1) {
             hour = '0'+hour;
        }
        if(minute.toString().length == 1) {
             minute = '0'+minute;
        }
        if(second.toString().length == 1) {
             second = '0'+second;
        }   
        var dateTime = year+'/'+month+'/'+day+' '+hour+':'+minute+':'+second;   
         return dateTime;
    }

    // example usage: realtime clock
    setInterval(function(){
        currentTime = getDateTime();
        document.getElementById("digital-clock").innerHTML = currentTime;
    }, 1000);
</script>


		<!--TOP SECTION-->
		<!--TOP SECTION-->
		<div class="hom-body-section">
			<div class="container">
				<div class="row">
					<div class="form">
						<form id="loginForm" action="<?php echo base_url() ?>Userlogin/adminlogin" class="form-dark" method="post">

							<div class="form-group">
								<label for="name">Email</label>
								<input type="email" name="email"  class="form-control" placeholder="Email" required>
							</div>
							<div class="form-group">
								<label for="name">password</label>
								<input type="password" name="password"  class="form-control" placeholder="password" required>
							</div>
							<div class="form-group">
								<button type="submit" class="btm-login">Login</button>
							</div>
							
						</form>
					</div>
					<div class="home-bod">
						<div class="home-bod-1">
							<!-- <h4>Today up to <span>70%</span> offer</h4> -->
							<h2>Occupancy Management System</h2>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!--TOP SECTION-->
	</section>
	<!--END HEADER SECTION-->
	<section>
	</section>
	<!--FOOTER FIXED SECTION-->
	<div class="hom-footer-section">
		<div class="container">
			<div class="row">
				<div class="foot-com foot-1">
					<ul>
						<li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a>
						</li>
						<li><a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a>
						</li>
						<li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a>
						</li>
					</ul>
				</div>
				<div class="foot-com foot-2">
					<h5>Designed and Developed by KRH. All rights reserved © 2020</h5> </div>
				<div class="foot-com foot-3">
					<!--<a class="waves-effect waves-light" href="#">online room booking</a>--><a class="waves-effect waves-light" href="#">OMS</a> </div>
				<div class="foot-com foot-4">
					<a href="#"><img src="images/card.png" alt="" />
					</a>
				</div>
			</div>
		</div>
	</div>
	<!--ALL SCRIPT FILES-->
	<script src="<?php echo base_url() ?>assetes/web/js/jquery.min.js"></script>
	<script src="<?php echo base_url() ?>assetes/web/js/jquery-ui.js"></script>
	<script src="<?php echo base_url() ?>assetes/web/js/angular.min.js"></script>
	<script src="<?php echo base_url() ?>assetes/web/js/bootstrap.js" type="text/javascript"></script>
	<script src="<?php echo base_url() ?>assetes/web/js/materialize.min.js" type="text/javascript"></script>
	<script src="<?php echo base_url() ?>assetes/web/js/jquery.mixitup.min.js" type="text/javascript"></script>
	<script src="<?php echo base_url() ?>assetes/web/js/custom.js"></script>
</body>
</html>