<?php defined('BASEPATH') OR exit('No direct script access allowed');
 


    class Web  extends CI_Controller {
        public function __construct(){
            parent::__construct();
            $this->load->model('Adminuser'); 
            $this->load->library('pagination');
        }


  
    public function index(){
        
        // $data['slider']=$this->Adminuser ->select_Record('tbl_slider');
        // $data['banner']=$this->Adminuser ->select_Record('tbl_banner_one');
        // $data['banner_one']=$this->Adminuser ->select_Record('tbl_banner_two');
        // $data['banner_two']=$this->Adminuser ->select_Record('tbl_banner_three'); 
        // $data['hot_deals']=$this->Adminuser ->selectRecords('tbl_product',['building_name'=>'Hot_Deals']);
        // $data['featured']=$this->Adminuser ->selectRecords('tbl_product',['building_name'=>'Featured']);
        // $data['kurtas_kurti']=$this->Adminuser ->selectRecords('tbl_product',['building_name'=>'Kurtas_Kurtis']);
        // $data['product']=$this->Adminuser ->select_desc_limit_Record('tbl_product','0','5');
        // $data['client_feedback']=$this->Adminuser ->select_Record('tbl_client_feedback');


        $this->load->view('index');
       
    }

    public function about(){
         
        $data['about']=$this->Adminuser ->select_Record('tbl_about');
        $this->load->view('header');
        $this->load->view('about',$data);
        $this->load->view('footer');

    } 
   
   // public function  shop_list(){
        

   //      $data['product']=$this->Adminuser ->select_Record('tbl_product');
   //      $data['product_category']=$this->Adminuser ->select_Record('tbl_product_category_name');
   //      $this->load->view('header');
   //      $this->load->view('shop_list',$data);
   //      $this->load->view('footer');

   //  }

    /*Blog Speak page Call Here*/
    public function shop_list(){
        

         $data['product_category']=$this->Adminuser ->select_Record('tbl_product_category_name');

        $config = array();
        $config["base_url"] = base_url() . "Web/shop_list";
        $config["total_rows"] = $this->Adminuser->get_count();
        $config["per_page"] = 6;
        $config["uri_segment"] = 3;
            
        $config['full_tag_open'] = " <div  class='pagination' aria-label='Page navigation example'>   <ul class='pagination justify-content-center'>";
        $config['full_tag_close'] = '</ul> </div>';
        $config['num_tag_open'] = '<li class="page-item">';
        $config['num_tag_close'] = '</li>';
        $config['cur_tag_open'] = '<li class="page-item current"><a href="#">';
        $config['cur_tag_close'] = '</a></li>';
        $config['prev_tag_open'] = '<li class="page-item">';
        $config['prev_tag_close'] = '</li>';
        $config['first_tag_open'] = '<li class="page-item">';
        $config['first_tag_close'] = '</li>';
        $config['last_tag_open'] = '<li class="page-item">';
        $config['last_tag_close'] = '</li>';



    $config['prev_link'] = '<i class="fa fa-long-arrow-left"></i>';
    $config['prev_tag_open'] = '<li>';
    $config['prev_tag_close'] = '</li>';


    $config['next_link'] = '<i class="fa fa-long-arrow-right"></i>';
    $config['next_tag_open'] = '<li>';
    $config['next_tag_close'] = '</li>';



   $this->pagination->initialize($config);
   $page = ($this->uri->segment(3))? $this->uri->segment(3) : 0;
        
   $data["links"] = $this->pagination->create_links();
   $data['product'] = $this->Adminuser->get_product($config["per_page"], $page);
        
        
        
        
        
       // $data['blog']=$this->Adminsmodel ->select_Record('blog');
         $this->load->view('header');
         $this->load->view('shop_list',$data);
         $this->load->view('footer');
        
        
        
        
        
    }

   
  
   
     public function   privacy_policy(){
         
        $data['h']=$this->Adminuser ->select_Record('tbl_privacy_policy');
        $this->load->view('header');
        $this->load->view('privacy-policy',$data);
        $this->load->view('footer');

    }  

    public function   terms_and_conditions(){
         
        $data['h']=$this->Adminuser ->select_Record('tbl_terms_and_conditions');
        $this->load->view('header');
        $this->load->view('terms_and_conditions',$data);
        $this->load->view('footer');

    }  
   
 
     public function blog(){
        
        $this->load->view('header');
        $this->load->view('blog');
        $this->load->view('footer');

    }  
    
     
    public function blog_category(){
        
        $this->load->view('header');
        $this->load->view('blog_category.php');
        $this->load->view('footer');

    }



  
    
    public function blog_details(){
        
        $this->load->view('header');
        $this->load->view('blog_details');
        $this->load->view('footer');

    }

     public function contact(){
        
        $this->load->view('header');
        $this->load->view('contact');
        $this->load->view('footer');

    } 
   
  

   public function gallery(){

         $this->load->view('header');
         $this->load->view('gallery');
         $this->load->view('footer');
       

    } 


   public function videogallery(){
        
        $this->load->view('header');
        $this->load->view('videogallery');
        $this->load->view('footer');

    } 


    public function get_product_details(){
      $id = $this->uri->segment(3);
      $result = $this->Adminuser->selectRecord('tbl_product',['id'=>$id]);
      // print_r($result);
      echo json_encode($result[0]);
    }
    

  
    }
?>