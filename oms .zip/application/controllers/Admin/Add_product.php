<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * 
 */

class Add_product  extends CI_Controller 
{  
     function __construct()
  {
    parent::__construct();
    $this->load->model('Adminuser');
  }
   
    public function index(){

        $data['category'] = $this->Adminuser->get_category()->result();
        $data['color']=$this->Adminuser ->select_Record('tbl_product_color');
        $data['size']=$this->Adminuser ->select_Record('tbl_product_size');
        $data['building_name']=$this->Adminuser ->select_Record('tbl_building');
        $this->load->view('dashboard/header');
        $this->load->view('dashboard/add_product',$data);
        $this->load->view('dashboard/footer');

    }

    function get_sub_category(){
        $id = $this->input->post('id',TRUE);
        $data = $this->Adminuser->get_sub_category($id)->result();
        echo json_encode($data);
    }

     public function viewallproduct(){
        
        $data['h']=$this->Adminuser->select_Record('tbl_product');

        $data['category'] = $this->Adminuser->get_category()->result();
        $data['sub_category'] = $this->Adminuser->select_Record("tbl_floor");

        $data['colors']=$this->Adminuser ->select_Record('tbl_product_color');
        $data['size']=$this->Adminuser ->select_Record('tbl_product_size');
        $data['building_name']=$this->Adminuser ->select_Record('tbl_building');
        $this->load->view('dashboard/header');
        $this->load->view('dashboard/view_allproduct',$data);
        $this->load->view('dashboard/footer'); 

       }



    public function add_product() {

     $this->form_validation->set_rules('product_name','Product_name','required');
     $this->form_validation->set_rules('building_name', 'building_name', 'trim|required');
    if ($this->form_validation->run() == FALSE) {
        // $this->session->set_flashdata('error', 'Something went Wroung !');
        // $data['category'] = $this->Adminuser->get_category()->result();
        // $data['color']=$this->Adminuser ->select_Record('tbl_product_color');
        // $data['size']=$this->Adminuser ->select_Record('tbl_product_size');
        // $data['building_name']=$this->Adminuser ->select_Record('tbl_building');
        // $this->load->view('dashboard/header');
        // $this->load->view('dashboard/add_product_sub_category',$data);
        // $this->load->view('dashboard/footer');

      echo("hello");
    }else{
        $config = array(
                'upload_path'=>'uploads/product',
                'allowed_types'=>'jpg|jpeg|gif|png',
                );
        $this->load->library('upload',$config);
        $formArray= array();

        $files = $_FILES;
        $cpt = count($_FILES ['image1'] ['name']);
        $formArray['image1'] = "";
        for ($i = 0; $i < $cpt; $i ++) {

            $name = time().$files ['image1'] ['name'] [$i];
            $_FILES ['image1'] ['name'] = $name;
            $_FILES ['image1'] ['type'] = $files ['image1'] ['type'] [$i];
            $_FILES ['image1'] ['tmp_name'] = $files ['image1'] ['tmp_name'] [$i];
            $_FILES ['image1'] ['error'] = $files ['image1'] ['error'] [$i];
            $_FILES ['image1'] ['size'] = $files ['image1'] ['size'] [$i];

            $formArray['image1'] .= $name."##";

            if(!($this->upload->do_upload('image1')) || $files ['image1'] ['error'] [$i] !=0)
            {
                print_r($this->upload->display_errors());
            }
        }

        // print_r($formArray);
        // exit();

       if($_FILES['image']['name'])
        {
            $config = array(
                'upload_path'=>'uploads/product',
                'allowed_types'=>'jpg|jpeg|gif|png',
                );
            
            $this->upload->do_upload('image');
            $img=$this->upload->data();
            $formArray['image'] = $img['file_name'];
        }
        
       
        $formArray['category']=$this->input->post('category');
        $formArray['sub_category']=$this->input->post('sub_category');
        $formArray['product_name']=$this->input->post('product_name');
        $formArray['product_name']=$this->input->post('product_name');
        $formArray['sell_price']=$this->input->post('sell_price');
        $formArray['offer_price']=$this->input->post('offer_price');
        $formArray['product_size']=implode(',', $this->input->post('product_size'));
        $formArray['product_color']=implode(',', $this->input->post('product_color'));
        $formArray['product_description']=$this->input->post('product_description');
        $formArray['product_quantity']=$this->input->post('product_quantity');
        $formArray['building_name']=$this->input->post('building_name');
        $formArray['product_status']=$this->input->post('product_status');
        $formArray['stock_status']=$this->input->post('stock_status');


    
       
        $this->Adminuser->insert_Record('tbl_product',$formArray);
        $this->session->set_flashdata('success', 'Product Add Succcessfully !');
        redirect(base_url().'Admin/Add_product');
    }
  }
 

   public function update_product()
        {

          $id = $this->input->post('id');
          $this->form_validation->set_rules('product_category_name', 'Product_category_name', 'required');
          if($this->form_validation->run())
          {

            $image = $this->input->post('oldImage');
             if($_FILES['image']['name']){
                unlink("uploads/category".$image);
                $config = array(
                    'upload_path'=>'uploads/category',
                    'allowed_types'=>'jpg|jpeg|gif|png',
                    );
                $this->load->library('upload',$config);
                $this->upload->do_upload('image');
                $img=$this->upload->data();
                $image = $img['file_name'];
            }
            
             $category= $this->input->post('category');
             $sub_category= $this->input->post('sub_category');
             $product_name= $this->input->post('product_name');
             $sell_price= $this->input->post('sell_price');
             $offer_price= $this->input->post('offer_price');
             $product_size= implode(',', $this->input->post('product_size'));
             $product_color= implode(',', $this->input->post('product_color'));
             $product_description= $this->input->post('product_description');
             $product_quantity= $this->input->post('product_quantity');
             $building_name= $this->input->post('building_name');
             $product_status= $this->input->post('product_status');
             $stock_status= $this->input->post('stock_status');
           





            $updateArray = array(
            'category'=>$category, 
            'sub_category'=> $sub_category,
            'product_name'=> $sub_category,
            'sell_price'=> $sub_category,
            'offer_price'=> $sub_category,
            'product_size'=> $sub_category,
            'product_color'=> $sub_category,
            'product_description'=> $sub_category,
            'product_quantity'=> $sub_category,
            'building_name'=> $sub_category,
            'product_status'=> $sub_category,
            'stock_status'=> $sub_category,
             'image' => $image
            );

            $this->Adminuser->update_global_Record('tbl_product',$id,$updateArray);
            $this->session->set_flashdata('update','Your details has been updated');
            redirect(base_url().'Admin/Add_product/viewallproduct');


          }
          else
          {
              echo "hello";
          }
        }

        public function delete_product($id)
         {
          
         $this->Adminuser->delete_Record('tbl_product',$id);
         $this->session->set_flashdata('delete','Your details has been deleted');
         redirect(base_url().'Admin/Add_product/viewallproduct');

         }




}
 ?>