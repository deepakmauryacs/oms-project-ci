<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * 
 */

class Multi  extends CI_Controller 
{  
     function __construct()
  {
    parent::__construct();
    $this->load->model('Adminuser');
  }
   
    public function index(){
        
        
        $this->load->view('dashboard/header');
        $this->load->view('dashboard/multi');
        $this->load->view('dashboard/footer');

    }




    public function add_multi() {

      $formArray = array();
      // Count total files
      $countfiles = count($_FILES['files']['name']);
 
      // Looping all files
      for($i=0;$i<$countfiles;$i++){
 
        if(!empty($_FILES['files']['name'][$i])){
 
          // Define new $_FILES array - $_FILES['file']
          $_FILES['file']['name'] = $_FILES['files']['name'][$i];
          $_FILES['file']['type'] = $_FILES['files']['type'][$i];
          $_FILES['file']['tmp_name'] = $_FILES['files']['tmp_name'][$i];
          $_FILES['file']['error'] = $_FILES['files']['error'][$i];
          $_FILES['file']['size'] = $_FILES['files']['size'][$i];

          // Set preference
          $config['upload_path'] = 'uploads/'; 
          $config['allowed_types'] = 'jpg|jpeg|png|gif';
          $config['max_size'] = '5000'; // max_size in kb
          $config['file_name'] = $_FILES['files']['name'][$i];
 
          //Load upload library
          $this->load->library('upload',$config); 
 
          // File upload
          if($this->upload->do_upload('file')){
            // Get data about the file
            $uploadData = $this->upload->data();
            $filename = $uploadData['file_name'];

            // Initialize array
            $data['filenames'][] = $filename;
          }
        }



        $formArray= array();
        $formArray['product_category_name']=$this->input->post('product_category_name');
        
        $this->Adminuser->insert_Record('tbl_product_category_name',$formArray);
        $this->session->set_flashdata('success', 'Product Category Add Succcessfully !');
        redirect(base_url().'Admin/Add_category');
    }
    
  }
 

   public function update_add_category()
        {
           $id = $this->input->post('id');
           $this->form_validation->set_rules('product_category_name', 'Product_category_name', 'required');
 

          if($this->form_validation->run())
          {
           
        
            $product_category_name= $this->input->post('product_category_name');
            $updateArray = array('product_category_name'=>$product_category_name);
            $this->Adminuser->update_global_Record('tbl_product_category_name',$id,$updateArray);
            $this->session->set_flashdata('update','Your details has been updated');
            redirect(base_url().'Admin/Add_category');


          }
          else
          {
              echo "hello";
          }
        }

        public function delete_add_category($id)
         {
          
         $this->Adminuser->delete_Record('tbl_product_category_name',$id);
         $this->session->set_flashdata('delete','Your details has been deleted');
         redirect(base_url().'Admin/Add_category');

         }





}
 ?>