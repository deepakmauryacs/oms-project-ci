<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * 
 */
class Add_terms_and_conditions  extends CI_Controller 
{  
      function __construct()
  {
    parent::__construct();
    $this->load->model('Adminuser');
  }

    public function index(){
    
        $data['h']=$this->Adminuser ->select_Record('tbl_terms_and_conditions');;
        $this->load->view('dashboard/header');
        $this->load->view('dashboard/terms_and_ conditions',$data);
        $this->load->view('dashboard/footer');
                  }
   
    public function update_terms_and_conditions()
           {
             $id = $this->input->post('id');
   
            $description = $this->input->post('description');
            $updateArray = array('description'=>$description);

             // print_r($id);
             // die();

            $this->Adminuser->update_global_Record('tbl_terms_and_conditions',$id,$updateArray);
            $this->session->set_flashdata('update','Your details has been updated');
            redirect(base_url().'Admin/Add_terms_and_conditions');

          }

}
?>