<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * 
 */

class Add_sub_category  extends CI_Controller 
{  
     function __construct()
  {
    parent::__construct();
    $this->load->model('Adminuser');
  }
   
    public function index(){

        $data['product_category']=$this->Adminuser ->select_Record('tbl_building');
        $data['sub_category']=$this->Adminuser ->select_Record('tbl_floor');
        $this->load->view('dashboard/header');
        $this->load->view('dashboard/add_product_sub_category',$data);
        $this->load->view('dashboard/footer');



    }




    public function add_sub_category() {

     $this->form_validation->set_rules('building_id','building_id','required');
     $this->form_validation->set_rules('floor_name','floor_name','required');
    if ($this->form_validation->run() == FALSE) {
        $this->session->set_flashdata('error', 'Something went Wroung !');
        $data['product_category']=$this->Adminuser ->select_Record('tbl_product_category_name');
        $data['sub_category']=$this->Adminuser ->select_Record('tbl_floor');
        $this->load->view('dashboard/header');
        $this->load->view('dashboard/add_product_sub_category',$data);
        $this->load->view('dashboard/footer');

      //echo("hello");
    }else{

        $formArray= array();
        $formArray['building_id']=$this->input->post('building_id');
        $formArray['floor_name']=$this->input->post('floor_name');

        $this->Adminuser->insert_Record('tbl_floor',$formArray);
        $this->session->set_flashdata('success', 'Building Add Succcessfully !');
        redirect(base_url().'Admin/Add_sub_category');
    }
    
  }
 

   public function update_add_sub_category()
        {
           $id = $this->input->post('id');
           $this->form_validation->set_rules('building_id', 'building_id', 'required');
 

          if($this->form_validation->run())
          {
          
            $building_id= $this->input->post('building_id');
            $floor_name= $this->input->post('floor_name');
            $updateArray = array('building_id'=>$building_id, 'floor_name'=> $floor_name);

            $this->Adminuser->update_global_Record('tbl_floor',$id,$updateArray);
            $this->session->set_flashdata('update','Your details has been updated');
            redirect(base_url().'Admin/Add_sub_category');


          }
          else
          {
              echo "hello";
          }
        }

        public function delete_add_sub_category($id)
         {
          
         $this->Adminuser->delete_Record('tbl_floor',$id);
         $this->session->set_flashdata('delete','Your details has been deleted');
         redirect(base_url().'Admin/Add_sub_category');

         }





}
 ?>