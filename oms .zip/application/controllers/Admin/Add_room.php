<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * 
 */

class Add_room  extends CI_Controller 
{  
     function __construct()
  {
    parent::__construct();
    $this->load->model('Adminuser');
  }
   
    public function index($id=''){

        $data['edit_data']=array();
        if(!empty($id))
        {
            $data['edit_data']=$this->db->get_where('room',['id'=>$id])->row();
        }
        $data['buildings']=$this->Adminuser ->select_Record('tbl_building');
        $data['floors']=$this->Adminuser ->select_Record('tbl_floor');
        $data['apartments']=$this->Adminuser ->select_Record('apartment');
        $data['rooms']=$this->Adminuser ->select_Record('room');
        $this->load->view('dashboard/header');
        $this->load->view('dashboard/add_room',$data);
        $this->load->view('dashboard/footer');

    }


     public function viewallroom(){
        
        $this->load->view('dashboard/header');
        $this->load->view('dashboard/view_allroom');
        $this->load->view('dashboard/footer'); 

       }


       public function check_in(){
        
        $data['building']=$this->Adminuser->select_Record('tbl_building');
        $data['rooms']=$this->Adminuser->select_Record('room');
        $this->load->view('dashboard/header');
        $this->load->view('dashboard/cheak_in',$data);
        $this->load->view('dashboard/footer'); 

       }
     
       public function viewallguest(){
           
        $data['buildings']=$this->Adminuser->select_Record('tbl_building');
        $this->load->view('dashboard/header');
        $this->load->view('dashboard/view_allguest',$data);
        $this->load->view('dashboard/footer'); 

       }



     public function view_cheakin(){

        $data['Checkin']=$this->Adminuser ->selectRecord('checkin_checkout', ['status'=>'1']);
        $this->load->view('dashboard/header');
        $this->load->view('dashboard/view_allcheakin',$data);
        $this->load->view('dashboard/footer'); 

       }

      public function view_cheakout(){

        $data['Checkin']=$this->Adminuser ->selectRecord('checkin_checkout', ['status'=>'2']);
        $this->load->view('dashboard/header');
        $this->load->view('dashboard/view_allcheakout',$data);
        $this->load->view('dashboard/footer'); 

       }

       
   
       public function update_status(){
                
              $id = $this->input->post('id');
              if (!empty($this->input->post('date'))) {
               $days =$this->input->post('quarantine_days');
               $scheduled_exit_date = $this->input->post('date');
               $newdate = date('Y:m:d', strtotime($scheduled_exit_date. "+".$days."days"));
              }else{
                $newdate='';
              }
    
                $updateArray['status']= $this->input->post('status');
                 if(!empty($this->input->post('date'))) {
                  $updateArray['date']=$this->input->post('date');
                  }
                 if(!empty($newdate)) {
                  $updateArray['scheduled_exit_date']=  $newdate; 
                  }          
                
                $this->session->set_flashdata('update','Checked In Successfully .. ..!');
                $this->Adminuser->update_global_Record('checkin_checkout',$id,$updateArray);
                redirect(base_url().'Admin/Add_room/viewallguest');
    
           }

       public function update_cheakin_status(){
       
            $id = $this->input->post('id');
   
            $updateArray['status']= $this->input->post('status');
            if(!empty($this->input->post('cheakout_date'))) {
            $updateArray['cheakout_date']= $this->input->post('cheakout_date');
            }

            if(!empty($this->input->post('isolated'))) {
            $updateArray['isolated']= $this->input->post('isolated');
             }



            //print_r($updateArray);
            //exit();
            $this->Adminuser->update_global_Record('checkin_checkout',$id,$updateArray);
            $this->session->set_flashdata('update','Status Update Succcessfully .. ..!');
            redirect(base_url().'Admin/Add_room/viewallguest');

          }

        

     // public function update_cheakin_status(){
       
     //        $id = $this->input->post('id');
     //        $status= $this->input->post('status');
     //        $cheakout_date= $this->input->post('cheakout_date');
     //        $updateArray = array(
     //        'status'=> $status,
     //        'cheakout_date'=> $cheakout_date,
     //        );

     //        $this->Adminuser->update_global_Record('checkin_checkout',$id,$updateArray);
     //        $this->session->set_flashdata('update','Cheakout Succcessfully .. ..!');
     //        redirect(base_url().'Admin/Add_room/viewallguest');

     //   }
       

       
      public function get_appartment()
        {
          $id=$this->input->post('id');
          $result=$this->db->get_where('apartment',['building_id'=>$id])->result_array();
          echo '<option value="">All</option>';
          foreach($result as $value)
          {
            echo '<option value="'.$value['id'].'">'.$value['apartment'].'</option>';
          }
     }
   
   

     public function get_floor(){
        
        $buildingsids=$this->input->post('buildingsids');
        if(empty($buildingsids))
        {
          echo '<div class="col-md-12">No building is Selected </div>';
          die;
        }

        $html='';
        $buildingsids=explode(',', $buildingsids);
        foreach ($buildingsids as $key => $ids) {
          
          $floors=$this->db->get_where('tbl_floor',['building_id'=>$ids])->result();
          if(!empty($floors))
          {
            foreach ($floors as $key => $value) {
               $html .='<div class="col-md-3"><input type="checkbox" onclick="get_apartments();" class="floors"  value="'. $value->id.'">'. $value->floor_name.' </div>';
            }
          }

        }
        echo $html ;
        die;

       }


     public function get_apartments(){
        
        $roomsids=$this->input->post('floorsids');
        if(empty($roomsids))
        {
          echo '<div class="col-md-12">No building is Selected </div>';
          die;
        }

        $html='';
        $roomsids=explode(',', $roomsids);
        foreach ($roomsids as $key => $ids) {
          
          $floors=$this->db->get_where('apartment',['floor_id'=>$ids])->result();


          if(!empty($floors))
          {
            foreach ($floors as $key => $value) {
               $html .='<div class="col-md-3"><input type="checkbox" class="get_apartment" onclick="get_rooms();" id="" value="'. $value->id.'">'. $value->apartment.' </div>';
            }
          }

        }
        echo $html ;
        die;

       }



      public function get_rooms(){
     
        $appartmentid=$this->input->post('appartmentid');
        if(empty($appartmentid))
        {
          echo '<div class="col-md-12">No building is Selected </div>';
          die;
        }

        $html='';
        $appartmentid=explode(',', $appartmentid);
        foreach ($appartmentid as $key => $ids) {
          
          $floors=$this->db->get_where('room',['apartments'=>$ids])->result();

          if(!empty($floors))
          {
            foreach ($floors as $key => $value) {

              $sql="SELECT SUM(`bed_count`) as total FROM `checkin_checkout` WHERE `roomId`='".$value->id."' AND `status`='1'";
              $total_cheakin=$this->db->query($sql)->row_array();

             //print_r( $total_cheakin);

              $total_cheakin= !empty($total_cheakin)?$total_cheakin['total']:0;
              
             // $total_cheakout=$this->db->get_where('checkin_checkout',['room_id'=>$value->id,'status'=>'2'])->result();
              //$total_cheakout= !empty($total_cheakout)?count($total_cheakout):0;

               $html .='<div class="col-lg-3 col-md-6 col-12 col-sm-6">
                <div class="blogThumb">
                  <div class="white-box">
                    <p ><b>Room Number: '.$value->room_no.'</b> &nbsp; </p>
                    <p class="m-t-20" style="color: red;">Book Bed:'.$total_cheakin.'<span style="color: blue;"> </span></p>
                    <p class="m-t-20" style="color: green;">Available Bed:'.($value->total_bed-$total_cheakin).'<span style="color: blue;"> </span></p>
                  
                  </div>
                </div>
              </div>';
                      }
                    }
              }
            echo $html ;
            die;


       }

   public function Checkin() {

       $this->form_validation->set_rules('custmer_name','Custmer_name','required');
       if ($this->form_validation->run() == FALSE) {
        $this->session->set_flashdata('info', 'Something Went to Wroung !');
        $this->load->view('dashboard/header');
        $this->load->view('dashboard/add_room');
        $this->load->view('dashboard/footer');

      // echo("hello");
    }else{
        
        $formArray= array();

        if (!empty($this->input->post('date'))) {

           $days =$this->input->post('quarantine_days');
           $scheduled_exit_date = $this->input->post('date');
           $newdate = date('Y:m:d', strtotime($scheduled_exit_date. "+".$days."days"));
        }else{

            $newdate='';
        }

        
        $formArray['building_id']=$this->input->post('building_id');
        $formArray['floor_id']=$this->input->post('floor_id');
        $formArray['apartment_id']=$this->input->post('apartmentid');
        $formArray['roomId']=$this->input->post('roomId');
        $formArray['guest_id']=$this->input->post('guest_id');
        $formArray['custmer_name']=$this->input->post('custmer_name');
        // $formArray['arrival_date']=$this->input->post('arrival_date');
        $formArray['gender']=$this->input->post('gender');
        $formArray['contact_number']=$this->input->post('contact_number');
        $formArray['flight']=$this->input->post('flight');
        $formArray['sponsor_phone']=$this->input->post('sponsor_phone');
        $formArray['food_preference']=$this->input->post('food_preference');
        $formArray['blood_group']=$this->input->post('blood_group');
        $formArray['nationality']=$this->input->post('nationality');
        $formArray['passport_number']= $this->input->post('passport_number');
        $formArray['civilid_number']=$this->input->post('civilid_number');
        $formArray['emergency_contact_number']=$this->input->post('emergency_contact_number');
        $formArray['emergency_contact_relationship']=$this->input->post('emergency_contact_relationship');
        $formArray['about_guest']=$this->input->post('about_guest');
        $formArray['quarantine_days']=$this->input->post('quarantine_days');
        $formArray['bed_count']=$this->input->post('bed_count');
        $formArray['roomId']=$this->input->post('roomId');
        $formArray['bed_count']=$this->input->post('bed_count');
        $formArray['status']=$this->input->post('status');

        if(!empty($this->input->post('reserved_date'))) {
           $formArray['reserved_date']=$this->input->post('reserved_date');
          }
        if(!empty($this->input->post('date'))) {
          $formArray['date']=$this->input->post('date');
        }
         
         if(!empty($newdate)) {
           $formArray['scheduled_exit_date']=  $newdate; 
         }
        
       // echo "<pre>";print_r($formArray);
        //exit();

        $this->Adminuser->insert_Record('checkin_checkout',$formArray);
        $this->session->set_flashdata('success', 'User Checkin   Succcessfully !');
        redirect(base_url().'Admin/Admin');
    }
  }
  
   public function update_guest()
        {

             $id = $this->input->post('id');
             $updateArray= array();
              if (!empty($this->input->post('date'))) {
                 $days =$this->input->post('quarantine_days');
                 $scheduled_exit_date = $this->input->post('date');
                 $newdate = date('Y:m:d', strtotime($scheduled_exit_date. "+".$days."days"));
              }else{
    
                  $newdate='';
              }
             $updateArray['building_id']= $this->input->post('building_id');
             $updateArray['floor_id']= $this->input->post('floor_id');
             $updateArray['apartment_id']= $this->input->post('apartment_id');
             $updateArray['roomId']= $this->input->post('roomId');
             $updateArray['guest_id']= $this->input->post('guest_id');
             $updateArray['custmer_name']= $this->input->post('custmer_name');
             $updateArray['arrival_date']= $this->input->post('arrival_date');
             $updateArray['gender']= $this->input->post('gender');
             $updateArray['contact_number']= $this->input->post('contact_number');
             $updateArray['flight']= $this->input->post('flight');
             $updateArray['sponsor_phone']= $this->input->post('sponsor_phone');
             $updateArray['food_preference']= $this->input->post('food_preference');
             $updateArray['blood_group']= $this->input->post('blood_group');
             $updateArray['nationality']= $this->input->post('nationality');
             $updateArray['passport_number']= $this->input->post('passport_number');
             $updateArray['civilid_number']= $this->input->post('civilid_number');
             $updateArray['emergency_contact_number']= $this->input->post('emergency_contact_number');
             $updateArray['emergency_contact_relationship']= $this->input->post('emergency_contact_relationship');
             $updateArray['quarantine_days']=$this->input->post('quarantine_days');
             $updateArray['about_guest']= $this->input->post('about_guest');
             if(!empty($this->input->post('date'))) {
               $formArray['date']=$this->input->post('date');
              } 
             if(!empty($newdate)) {
               $updateArray['scheduled_exit_date']=  $newdate; 
              }
             $updateArray['isolated']= $this->input->post('isolated');
             $updateArray['bed_count']= $this->input->post('bed_count');
             $this->Adminuser->update_global_Record('checkin_checkout',$id,$updateArray);
             $this->session->set_flashdata('update','Your details has been updated');
             redirect(base_url().'Admin/Admin');

          }



    public function add_room() {

     $this->form_validation->set_rules('floor_name','Floor_name','required');
     if ($this->form_validation->run() == FALSE) {
        $this->session->set_flashdata('info', 'Something Went to Wroung !');
          $data['edit_data']=array();
          $id=$this->input->post('edit_id');
        if(!empty($id))
        {
            $data['edit_data']=$this->db->get_where('room',['id'=>$id])->row();
        }
        $data['building_name']=$this->Adminuser ->select_Record('tbl_building');
        $data['building_name']=$this->Adminuser ->select_Record('tbl_floor');
        $data['apartments']=$this->Adminuser ->select_Record('apartment');
        $data['rooms']=$this->Adminuser ->select_Record('room');
        $this->load->view('dashboard/header');
        $this->load->view('dashboard/add_room',$data);
        $this->load->view('dashboard/footer');

      // echo("hello");
    }else{
        
        $formArray= array();
        $formArray['building_name']=$this->input->post('building_name');
        $formArray['floor_name']=$this->input->post('floor_name');
        $formArray['apartments']=$this->input->post('apartments');
        $formArray['room_no']=$this->input->post('room_no');
        $formArray['total_bed']=$this->input->post('total_bed');
        $where['id']=$this->input->post('edit_id');
        if(!empty($where['id']))
        {
            $this->db->update('room',$formArray,$where);
            $this->session->set_flashdata('success', 'Room Update Succcessfully !');
        }else{
            $this->Adminuser->insert_Record('room',$formArray);
        $this->session->set_flashdata('success', 'Room Add Succcessfully !');
        }
        redirect(base_url().'Admin/Add_room');
    }
  }
 

   public function update_room()
        {

          $id = $this->input->post('id');
          $this->form_validation->set_rules('building_name', 'Building_name', 'required');
          if($this->form_validation->run())
        
            {
             
             $building_name= $this->input->post('building_name');
             $floor_name= $this->input->post('floor_name');
             $apartments= $this->input->post('apartments');
             $room_no= $this->input->post('room_no');
             $total_bed= $this->input->post('total_bed');
             $status= $this->input->post('status');
           

            $updateArray = array(
            'building_name'=>$building_name, 
            'floor_name'=> $floor_name,
            'apartments'=> $apartments,
            'room_no'=> $room_no,
            'total_bed'=> $total_bed,
            'status'=> $status,
            
            );

            $this->Adminuser->update_global_Record('room',$id,$updateArray);
            $this->session->set_flashdata('update','Your details has been updated');
            redirect(base_url().'Admin/Add_room');


          }
          else
          {
              echo "hello";
          }
        }

        public function delete_geust($id)
         {
          
         $this->Adminuser->delete_Record('checkin_checkout',$id);
         $this->session->set_flashdata('delete','Your details has been deleted');
         redirect(base_url().'Admin/Admin');

         }
         
        
}
 ?>