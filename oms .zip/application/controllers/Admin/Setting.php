<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * 
 */

class Setting  extends CI_Controller 
{  
     function __construct()
  {
    parent::__construct();
    $this->load->model('Adminuser');
  }
   
    public function index(){
        
        $data['h']=$this->Adminuser ->select_Record('tbl_footer_setting');
        $data['s']=$this->Adminuser ->select_Record('tbl_social_media');
        $this->load->view('dashboard/header');
        $this->load->view('dashboard/setting',$data);
        $this->load->view('dashboard/footer');

    }


 
     public function update_footer()
           
            {
              $id = $this->input->post('id');
              $image = $this->input->post('oldImage');
              if($_FILES['image']['name']){
                
                 if(file_exists("uploads/about".$image1)){
                   unlink("uploads/about".$image2);
                }

                $config = array(
                    'upload_path'=>'uploads/about',
                    'allowed_types'=>'jpg|jpeg|gif|png',
                    );
                $this->load->library('upload',$config);
                $this->upload->do_upload('image');
                $img=$this->upload->data();
                $image = $img['file_name'];
            }

        
            
            $description = $this->input->post('description');
            $address = $this->input->post('address');
            $contact = $this->input->post('contact');
            $support_link = $this->input->post('support_link');
            

            $updateArray = array('description'=>$description,'address'=>$address,'contact'=>$contact,'support_link'=>$support_link,'image'=>$image);

           // print_r($updateArray);
            //die();

            $this->Adminuser->update_global_Record('tbl_footer_setting',$id,$updateArray);
            $this->session->set_flashdata('update','Your details has been updated');
            redirect(base_url().'Admin/Setting');

          }

           public function update_social_media()
           
            {
            
            $id = $this->input->post('id');
            $facebook = $this->input->post('facebook');
            $instagram = $this->input->post('instagram');
            $twitter = $this->input->post('twitter');
            $linkedin = $this->input->post('linkedin');
            

             $updateArray = array('facebook'=>$facebook,'instagram'=>$instagram,'twitter'=>$twitter,'linkedin'=>$linkedin);
             
            // print_r($id);
            // die();
            // print_r($updateArray);
            // die();

            $this->Adminuser->update_global_Record('tbl_social_media',$id,$updateArray);
            $this->session->set_flashdata('update','Your details has been updated');
            redirect(base_url().'Admin/Setting');

          }

  



}
 ?>