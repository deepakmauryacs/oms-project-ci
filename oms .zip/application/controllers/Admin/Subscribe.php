<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * 
 */
class Subscribe  extends CI_Controller 
{  
     function __construct()
  {
    parent::__construct();
    $this->load->model('Adminuser');
  }



       public function index()
       {
        $data['h']=$this->Adminuser ->select_Record('tbl_subscribe');
        $this->load->view('dashboard/header');
        $this->load->view('dashboard/viewall_subscribe',$data);
        $this->load->view('dashboard/footer'); 
       }

     public function view_subscribe(){
         
        // $stddata=$this->session->userdata('StudentData');
        // $data['h']=$this->Adminuser ->selectRecord('academy_note', ['class'=>$stddata['class']]);

        $data['h']=$this->Adminuser ->select_Record('contact');
        $this->load->view('admin/header');
        $this->load->view('admin/viewall_contact',$data);
        $this->load->view('admin/footer');
                 
       }

   
    public function add_subscribe() {

    $this->form_validation->set_rules('email', 'Email', 'required');
   

    if ($this->form_validation->run() == FALSE) { 

            $this->load->view('header');
            $this->load->view('index');
            $this->load->view('header');

      // echo "hello";
      // exit();
      
       }else{

        $formArray= array();
        $formArray['email']=$this->input->post('email');
        $this->Adminuser->insert_Record('tbl_subscribe',$formArray);
        $this->session->set_flashdata('success', 'Thank You For Subscribe Our Newsletter...!');
        redirect(base_url().'Web');
    }
    
  }



        public function delete_subscribe($id)
         {
          
         $this->Adminuser->delete_Record('tbl_subscribe',$id);
         $this->session->set_flashdata('delete','Your details has been deleted');
         redirect(base_url().'Admin/Subscribe');

         }





}
 ?>
