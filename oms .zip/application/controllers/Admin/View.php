<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * 
 */

class View  extends CI_Controller 
{  
     function __construct()
  {
    parent::__construct();
    $this->load->model('Adminuser');
  }
   
  public function checkIn($apartmentid)
   {
     $sql="SELECT * FROM `checkin_checkout` WHERE `apartment_id`= '".$apartmentid."' AND (`status`='1' or `status`='4')";
    // "SELECT * FROM `checkin_checkout` WHERE `apartment_id`='".$apartmentid."' OR `status`='1' AND `status`='4'";
    //  print_r($sql);
    //  die;
    $data['list']=$this->db->query($sql)->result_array();
    // $data['list']=$this->db->get_where('checkin_checkout',['apartment_id'=>$apartmentid,'status'=>1])->result_array();
    $data['apartmentid']=$apartmentid;
    $this->load->view('dashboard/header');
    $this->load->view('dashboard/view',$data);
    $this->load->view('dashboard/footer');


   }
    
 
    
    

  }
 ?>