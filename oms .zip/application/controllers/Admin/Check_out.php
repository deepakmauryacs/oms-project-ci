<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * 
 */

class Check_out  extends CI_Controller 
{  
     function __construct()
  {
    parent::__construct();
    $this->load->model('Adminuser');
  }
   
    public function index(){
        
        $data['buildings']=$this->Adminuser->select_Record('tbl_building');
        $data['rooms']=$this->Adminuser->select_Record('room');
        $data['users']=$this->Adminuser->select_Record('checkin_checkout');
        $this->load->view('dashboard/header');
        $this->load->view('dashboard/view_allcheckout',$data);
        $this->load->view('dashboard/footer');
    
    }
    
       public function getBookingList()
       {
          $column = array('id','guest_id','custmer_name','apartment_id','roomId','gender','contact_number','passport_number','civilid_number','nationality','food_preference','flight','blood_group','sponsor_phone','emergency_contact_number','emergency_contact_relationship','status','reserved_date','date','cheakout_date','arrival_date','bed_count');
    
          $query = " SELECT * FROM checkin_checkout ";
          $query .=" WHERE status = 2";
    
          if(isset($_POST['food_type'])&&!empty($_POST['food_type']))
          {
            $query .=" AND food_preference ='".$_POST['food_type']."'";
          }
    
          if(isset($_POST['gender'])&&!empty($_POST['gender']))
          {
            $query .=" AND gender='".$_POST['gender']."'";
          }
    
          if(isset($_POST['Appartments'])&&!empty($_POST['Appartments']))
          {
            $query .=" AND apartment_id='".$_POST['Appartments']."'";
          }
    
          if(isset($_POST['building'])&&!empty($_POST['building']))
          {
            $apparments=$this->db->get_where('apartment',['building_id'=>$_POST['building']])->result();
            $query .=" AND ";
            $d='';
            foreach($apparments as $key=> $apparment)
            {
              if($key>0)
              {
                //$query .=" OR ";
                $d .=',';
              }
              $d .=$apparment->id;
              //$query .=" apartment_id = '".$apparment->id."'";
            }
            $query .=" apartment_id IN(".$d.")";
          }
    
          if(isset($_POST['status'])&&!empty($_POST['status']))
          {
            $query .=" AND status='".$_POST['status']."'";
          }
    
          
          if(isset($_POST['arrival_from'])&&!empty($_POST['arrival_from']))
          {
            $query .=" AND arrival_date >= '".date('Y-m-d',strtotime($_POST['arrival_from']))."'";
          }
          if(isset($_POST['arrival_to'])&&!empty($_POST['arrival_to']))
          {
            $query .=" AND arrival_date <= '".date('Y-m-d',strtotime($_POST['arrival_to']))."'";
          }
    
    
          
          if(isset($_POST['start_from'])&&!empty($_POST['start_from']))
          {
            $query .=" AND date >= '".date('Y-m-d',strtotime($_POST['start_from']))."'";
          }
          if(isset($_POST['end_form'])&&!empty($_POST['end_form']))
          {
              $query .=" AND date <= '".date('Y-m-d',strtotime($_POST['end_form']))."'";
          }
          
          if(isset($_POST['start_to'])&&!empty($_POST['start_to']))
          {
            $query .=" AND cheakout_date >= '".date('Y-m-d',strtotime($_POST['start_to']))."'";
          }
          if(isset($_POST['end_to'])&&!empty($_POST['end_to']))
          {
              $query .=" AND cheakout_date <= '".date('Y-m-d',strtotime($_POST['end_to']))."'";
          }
          
          
          if(isset($_POST['order']))
          {
           $query .= ' ORDER BY '.$column[$_POST['order']['0']['column']].' '.$_POST['order']['0']['dir'].' ';
          }
          else
          {
           $query .= ' ORDER BY id DESC ';
          }
          $number_filter_row= $this->db->query($query)->num_rows();
          $query1 = '';
    
          if(isset($_POST["length"])&&$_POST["length"] != -1)
          {
           $query1 = ' LIMIT ' . $_POST['start'] . ', ' . $_POST['length'];
          }
    
          //echo $query.$query1;
          $result =$this->db->query($query.$query1)->result();
          //print_r($_POST);
            //echo $this->db->last_query();
          $data = array();
          $status=array('4'=>'Reserved','1'=>'Checked-In','2'=>'Checked-Out','3'=>'Cancelled');
          foreach($result as $key=> $booking)
          {
            $buildingId = get_field_value('apartment','building_id',['id'=>$booking->apartment_id]);

           $sub_array   =   array();
           $sub_array[] = ++$key;
           $sub_array[] = $booking->guest_id;
           $sub_array[] = $booking->custmer_name;
           $sub_array[] = get_field_value('tbl_building','building_name',['id'=>$buildingId]);
           $sub_array[] = get_field_value('apartment','apartment',['id'=>$booking->apartment_id]);
           $sub_array[] = get_field_value('room','room_no',['id'=>$booking->roomId]);
           $sub_array[] = $booking->gender;
           $sub_array[] = $booking->contact_number;
           $sub_array[] = $booking->passport_number;
           $sub_array[] = $booking->civilid_number;
           $sub_array[] = $booking->nationality;
           $sub_array[] = $booking->food_preference;
           $sub_array[] = $booking->flight;
           $sub_array[] = $booking->blood_group;
           $sub_array[] = $booking->sponsor_phone;
           $sub_array[] = $booking->emergency_contact_number;
           $sub_array[] = $booking->emergency_contact_relationship; 
           $sub_array[] = $status[$booking->status]; 
           $sub_array[] = ($booking->reserved_date) ? date('d-m-Y',strtotime($booking->reserved_date)) : ''; 
           $sub_array[] = ($booking->date) ? date('d-m-Y',strtotime($booking->date)) : '';   
           $sub_array[] = ($booking->cheakout_date) ? date('d-m-Y',strtotime($booking->cheakout_date)) : ''; 
         
               
           $sub_array[] = '
          <div style="width: 111px;display: flex;">
           <a href="'.base_url().'Admin/Admin/update_status/'.$booking->id.'" class="btn btn-tbl-edit btn-xs"  style="background-color: orange;"><i class="fa fa-undo"></i></a>
           
           <a href="'.base_url().'Admin/Admin/edit_guest/'.$booking->id.'" class="btn btn-tbl-edit btn-xs" style="    background-color: #1e1ebbb5;"><i class="fa fa-pencil-square-o"></i></a>
            
          <a href="'.base_url().'Admin/Add_room/delete_geust/'.$booking->id.'" class="btn btn-tbl-delete btn-xs" onclick="return confirm(`Are you sure to Delete ?`)"> <i class="fa fa-trash-o "></i></a>
          </div>
          ' ;
           $data[] = $sub_array;
          }
           //print_r($data);
        $draw=!empty($_POST["draw"])?$_POST["draw"]:1;
          $output = array(
           "draw"       =>  intval($draw),
           "recordsTotal"   =>  $this->count_all_data(),
           "recordsFiltered"  =>  $number_filter_row,
           "data"       =>  $data
          );
          echo json_encode($output);
       }

        
          public function count_all_data()
          {
            $query = " SELECT * FROM  checkin_checkout ";
            $query .=" WHERE id > 0 ";
            $row= $this->db->query($query);
            return $row->num_rows();
          }

  }
 ?>