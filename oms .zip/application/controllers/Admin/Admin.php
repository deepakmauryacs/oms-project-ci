<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * 
 */
class Admin  extends CI_Controller 
{  
     function __construct()
  {
    parent::__construct();
    $this->load->model('Adminuser');
  }
   
    public function index(){
      
        $data['building']=$this->Adminuser->select_Record('tbl_building');
        $data['rooms']=$this->Adminuser->select_Record('room');
        $data['users']=$this->Adminuser->select_Record('checkin_checkout');
        $this->load->view('dashboard/header');
        $this->load->view('dashboard/index',$data);
        $this->load->view('dashboard/footer');

    }
    
     public function  capacity(){

        $data['building']=$this->Adminuser->select_Record('tbl_building');

        // $this->load->view('dashboard/header');
        echo $this->load->view('dashboard/capacity_list',$data,true);
        // $this->load->view('dashboard/footer');
    }
    

     public function  occupied_bed_list(){

        $data['building']=$this->Adminuser->select_Record('tbl_building');
        $data['rooms']=$this->Adminuser->select_Record('room');
        //$this->load->view('dashboard/header');
       echo  $this->load->view('dashboard/occupied_bed_list',$data,true);
        //$this->load->view('dashboard/footer');

    }

    public function  vacant_beds_list(){

        $data['building']=$this->Adminuser->select_Record('tbl_building');
        // $this->load->view('dashboard/header');
        $this->load->view('dashboard/vacant_beds_list',$data);
        // $this->load->view('dashboard/footer');

    }


    
     public function  reserved_beds_list(){
      
        $data['building']=$this->Adminuser->select_Record('tbl_building');
        // $this->load->view('dashboard/header');
        $this->load->view('dashboard/reserved_beds_list',$data);
        // $this->load->view('dashboard/footer');
      }
  
   
    public function  todays_checkin_lists(){
        
        $data['building']=$this->Adminuser->select_Record('tbl_building');
        // $this->load->view('dashboard/header');
        $this->load->view('dashboard/todays_checkin_list',$data);
        // $this->load->view('dashboard/footer');
      }

    public function  todays_checkout_lists(){
        
        $data['building']=$this->Adminuser->select_Record('tbl_building');
        // $this->load->view('dashboard/header');
        $this->load->view('dashboard/todays_checkout_lists',$data);
        // $this->load->view('dashboard/footer');
       }


     public function edit_guest($gid){
         
        $data['building']=$this->Adminuser->select_Record('tbl_building');
        $data['floor']=$this->Adminuser ->select_Record('tbl_floor');
        $data['apartments']=$this->Adminuser ->select_Record('apartment');
        $data['rooms']=$this->Adminuser->select_Record('room');
        $data['edit_data']=$this->db->get_where('checkin_checkout',['id'=>$gid])->row();
        $this->load->view('dashboard/header');
        $this->load->view('dashboard/edit_guest',$data);
        $this->load->view('dashboard/footer');

    }

       public function update_status($gid){
         
        $data['edit_data']=$this->db->get_where('checkin_checkout',['id'=>$gid])->row();
        $this->load->view('dashboard/header');
        $this->load->view('dashboard/update_status',$data);
        $this->load->view('dashboard/footer');

      }



    

    public function user_profile(){
      $userdata = $this->session->userdata('AdminData');
      $id = $userdata['id'];
      // echo $id."<br/>";
      // exit;
      if($this->session->userdata('usertype') == "admin"){
        $data['h']=$this->Adminuser->selectRecord('admin', ['id'=>$id]);
      }else{
        $data['h']=$this->Adminuser->selectRecord('user', ['id'=>$id]);
      }
      
      $this->load->view('dashboard/header');
      $this->load->view('dashboard/user_profile',$data);
      $this->load->view('dashboard/footer');

    }

        public function update_user_profile()
       {
         $id = $this->input->post('id');
        
         
        $username = $this->input->post('username');
        $email = $this->input->post('email');
       
       

        $updateArray = array('username'=>$username,'email'=>$email);

         // print_r($id);
        // die();

        $this->Adminuser->update_global_Record('admin',$id,$updateArray);
        $this->session->set_flashdata('update','Your details has been updated');
        redirect(base_url().'Admin/Admin/user_profile');

      }

      public function user_password(){
     
        $data['h']=$this->Adminuser ->select_Record('admin');
        $this->load->view('dashboard/header');
        $this->load->view('dashboard/update_password',$data);
        $this->load->view('dashboard/footer');

    }

    public function update_user_password()
    {   
        
        $id = $this->input->post('id');
        $password = $this->input->post('password');
        $new_password = $this->input->post('new_password');
        $con_password = $this->input->post('con_password');
        $check=1;
        
        if(empty($password))
        {
             $check=0;
           $this->session->set_flashdata('update','Please enter current password'); 
           
        }
        if(empty($new_password)&&$check)
        {  
             $check=0;
           $this->session->set_flashdata('update','Please enter new password'); 
        }
        if(empty($con_password)&&$check)
        {
            $check=0;
           $this->session->set_flashdata('update','Please enter confirm password'); 
        }
        
        $row=$this->db->get_where('admin',['id'=>$id,'password'=>md5($password)])->row();
        //echo $this->db->last_query();die;
        if(empty($row)&&$check)
        {
            $check=0;
            $this->session->set_flashdata('update','Please enter correct password');
        }
        
        if($new_password!=$con_password&&$check){
            $check=0; 
            $this->session->set_flashdata('update','New password and confirm password not match!');
        }
        //print_r($_POST);die;
        if($check)
        {
            $updateArray = array('password'=>md5($new_password));
            $this->Adminuser->update_global_Record('admin',$id,$updateArray);
            $this->session->set_flashdata('update','Your Psassword has been updated'); 
        }
        
        redirect(base_url().'Admin/Admin/user_password');
    }
   public function checkIn($apartmentid)
   {
        
        
    $rooms=$this->db->get_where('room',['apartments'=>$apartmentid])->result();
    $new_rooms=[];
    foreach($rooms as $room)
    {
        $sql="SELECT COUNT(*) total FROM checkin_checkout WHERE apartment_id='".$apartmentid ."' AND roomId ='".$room->id."'";
        $row=$this->db->query($sql)->row();
        if($row->total<$room->total_bed)
        {
           $new_rooms[] =$room;
        }
    }
    //print_r($rooms);die;
    
    $data['rooms']=$new_rooms;// $this->db->get_where('room',['apartments'=>$apartmentid])->result();
    
    
    $data['apartmentid']=$apartmentid;
    $this->load->view('dashboard/header');
    $this->load->view('dashboard/check-in',$data);
    $this->load->view('dashboard/footer');


   }

   public function view($apartmentid)
   {

    //$data['Checkin']=$this->db->get_where('room',['apartments'=>$apartmentid])->result();
    $data['Checkin']=$this->Adminuser ->selectRecord('checkin_checkout', ['status'=>'1','apartment_id'=>$apartmentid]);
   
    $this->load->view('dashboard/header');
    $this->load->view('dashboard/view',$data);
    $this->load->view('dashboard/footer');


   }


    public function getBookingList()
    {
      $column = array('id','guest_id','custmer_name','apartment_id','roomId','gender','contact_number','passport_number','civilid_number','nationality','food_preference','flight','blood_group','sponsor_phone','emergency_contact_number','emergency_contact_relationship','status','reserved_date','date','quarantine_days','scheduled_exit_date','isolated', 'cheakout_date','about_guest',
     'arrival_date','bed_count');

      $query = " SELECT * FROM checkin_checkout ";
      $query .=" WHERE id > 0";
      
      if(isset($_POST['isolated'])&&!empty($_POST['isolated']))
      {
        $query .=" AND isolated ='".$_POST['isolated']."'";
      }
      
      if(isset($_POST['food_type'])&&!empty($_POST['food_type']))
      {
        $query .=" AND food_preference ='".$_POST['food_type']."'";
      }

      if(isset($_POST['gender'])&&!empty($_POST['gender']))
      {
        $query .=" AND gender='".$_POST['gender']."'";
      }

      if(isset($_POST['Appartments'])&&!empty($_POST['Appartments']))
      {
        $query .=" AND apartment_id='".$_POST['Appartments']."'";
      }

      if(isset($_POST['building'])&&!empty($_POST['building']))
      {
        $apparments=$this->db->get_where('apartment',['building_id'=>$_POST['building']])->result();
        $query .=" AND ";
        $d='';
        foreach($apparments as $key=> $apparment)
        {
          if($key>0)
          {
            //$query .=" OR ";
            $d .=',';
          }
          $d .=$apparment->id;
          //$query .=" apartment_id = '".$apparment->id."'";
        }
        $query .=" apartment_id IN(".$d.")";
      }

      if(isset($_POST['status'])&&!empty($_POST['status']))
      {
        $query .=" AND status='".$_POST['status']."'";
      }
      
      
       //// 
      if(isset($_POST['scheduled_from'])&&!empty($_POST['scheduled_from']))
      {
        $query .=" AND scheduled_exit_date >= '".date('Y-m-d',strtotime($_POST['scheduled_from']))."'";
      }

      if(isset($_POST['scheduled_end'])&&!empty($_POST['scheduled_end']))
      {
        $query .=" AND scheduled_exit_date <= '".date('Y-m-d',strtotime($_POST['scheduled_end']))."'";
      }

      
      if(isset($_POST['arrival_from'])&&!empty($_POST['arrival_from']))
      {
        $query .=" AND arrival_date >= '".date('Y-m-d',strtotime($_POST['arrival_from']))."'";
      }
      if(isset($_POST['arrival_to'])&&!empty($_POST['arrival_to']))
      {
        $query .=" AND arrival_date <= '".date('Y-m-d',strtotime($_POST['arrival_to']))."'";
      }


      
      if(isset($_POST['start_from'])&&!empty($_POST['start_from']))
      {
        $query .=" AND date >= '".date('Y-m-d',strtotime($_POST['start_from']))."'";
      }
      if(isset($_POST['end_form'])&&!empty($_POST['end_form']))
      {
          $query .=" AND date <= '".date('Y-m-d',strtotime($_POST['end_form']))."'";
      }
      
      if(isset($_POST['start_to'])&&!empty($_POST['start_to']))
      {
        $query .=" AND cheakout_date >= '".date('Y-m-d',strtotime($_POST['start_to']))."'";
      }
      if(isset($_POST['end_to'])&&!empty($_POST['end_to']))
      {
          $query .=" AND cheakout_date <= '".date('Y-m-d',strtotime($_POST['end_to']))."'";
      }
      
      
      if(isset($_POST['order']))
      {
       $query .= ' ORDER BY '.$column[$_POST['order']['0']['column']].' '.$_POST['order']['0']['dir'].' ';
      }
      else
      {
       $query .= ' ORDER BY id DESC ';
      }
      $number_filter_row= $this->db->query($query)->num_rows();
      $query1 = '';

      if(isset($_POST["length"])&&$_POST["length"] != -1)
      {
       $query1 = ' LIMIT ' . $_POST['start'] . ', ' . $_POST['length'];
      }

      //echo $query.$query1;
      $result =$this->db->query($query.$query1)->result();
      //print_r($_POST);
        //echo $this->db->last_query();
      $data = array();
      $status=array('4'=>'Reserved','1'=>'Checked-In','2'=>'Checked-Out','3'=>'Cancelled');
      foreach($result as $key=> $booking)
      {

        $diff=0;
        if($booking->status==1)
        {
          
          $start = $booking->date;
          $end = date('d-m-Y');
          $diff = (strtotime($end)- strtotime($start))/24/3600; 
          //echo $diff;
        }
        //echo $booking->quarantine_days;
        //var_dump($booking->quarantine_days);
        $d = (int)$booking->quarantine_days-$diff;
        if ($d < 0) {
         $d=0;
        }

        $buildingId = get_field_value('apartment','building_id',['id'=>$booking->apartment_id]);
        
        
       $sub_array = array();
       $sub_array[] = ++$key;
       $sub_array[] = $booking->guest_id;
       $sub_array[] = $booking->custmer_name;
       $sub_array[] = get_field_value('tbl_building','building_name',['id'=>$buildingId]);
       $sub_array[] = get_field_value('apartment','apartment',['id'=>$booking->apartment_id]);
       $sub_array[] = get_field_value('room','room_no',['id'=>$booking->roomId]);
       $sub_array[] = $booking->gender;
       $sub_array[] = $booking->contact_number;
       $sub_array[] = $booking->passport_number;
       $sub_array[] = $booking->civilid_number;
       $sub_array[] = $booking->nationality;
       $sub_array[] = $booking->food_preference;
       $sub_array[] = $booking->flight;
       $sub_array[] = $booking->blood_group;
       $sub_array[] = $booking->sponsor_phone;
       $sub_array[] = $booking->emergency_contact_number;
       $sub_array[] = $booking->emergency_contact_relationship;
       $sub_array[] = $status[$booking->status]; 
       $sub_array[] = ($booking->reserved_date) ? date('d-m-Y',strtotime($booking->reserved_date)) : ''; 
       $sub_array[] = ($booking->date) ? date('d-m-Y',strtotime($booking->date)) : ''; 
       $sub_array[] = $d;
       $sub_array[] = ($booking->scheduled_exit_date) ? date('d-m-Y',strtotime($booking->scheduled_exit_date)) : ''; 
       $sub_array[] = $booking->isolated;  
       $sub_array[] = ($booking->cheakout_date) ? date('d-m-Y',strtotime($booking->cheakout_date)) : ''; 
       $sub_array[] = $booking->about_guest;
           
       $sub_array[] = '
       <div style="width: 111px;display: flex;">
        <a href="'.base_url().'Admin/Admin/update_status/'.$booking->id.'" class="btn btn-tbl-edit btn-xs"  style="background-color: orange;"><i class="fa fa-undo"></i></a>
        <a href="'.base_url().'Admin/Admin/edit_guest/'.$booking->id.'" class="btn btn-tbl-edit btn-xs" style="    background-color: #1e1ebbb5;"><i class="fa fa-pencil-square-o"></i></a>
        <a href="'.base_url().'Admin/Add_room/delete_geust/'.$booking->id.'"  class="btn btn-tbl-delete btn-xs"  onclick="return confirm(`Are you sure to Delete ?`)"> <i class="fa fa-trash-o "></i></a>
        </div>';
       $data[] = $sub_array;
      }
       //print_r($data);
     $draw=!empty($_POST["draw"])?$_POST["draw"]:1;
      $output = array(
       "draw"       =>  intval($draw),
       "recordsTotal"   =>  $this->count_all_data(),
       "recordsFiltered"  =>  $number_filter_row,
       "data"       =>  $data
      );
      echo json_encode($output);
   }



  public function count_all_data()
  {
    $query = " SELECT * FROM  checkin_checkout ";
    $query .=" WHERE id > 0 ";
    $row= $this->db->query($query);
    return $row->num_rows();
  }

}
 ?>