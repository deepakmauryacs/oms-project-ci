<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * 
 */

class Dashoard_room  extends CI_Controller 
{  
     function __construct()
    {
        parent::__construct();
        $this->load->model('Adminuser');
    }
   
    public function index(){
        
        $data['building_name']=$this->Adminuser ->select_Record('tbl_building');
        $data['building_name']=$this->Adminuser ->select_Record('tbl_floor');
        $data['apartments']=$this->Adminuser ->select_Record('apartment');
        $data['rooms']=$this->Adminuser ->select_Record('room');
        $this->load->view('dashboard/header');
        $this->load->view('dashboard/add_room',$data);
        $this->load->view('dashboard/footer');

    }

  
    public function cardlist($apid){

        $data['apid']=$apid;
        $name = $this->db->select("building_name")->from("tbl_building")->where(['id'=>$apid])->get()->row();
        $data['name'] = $name->building_name;
        $data['floors']=$this->db->get_where('apartment',['building_id'=>$apid])->result();
        $this->load->view('dashboard/header');
        $this->load->view('dashboard/cardlist',$data);
        $this->load->view('dashboard/footer');
    }



     public function viewallroom(){
        
        $data['building']=$this->Adminuser->select_Record('tbl_building');
        $data['rooms']=$this->Adminuser->select_Record('room');
        $this->load->view('dashboard/header');
        $this->load->view('dashboard/view_alluserroom',$data);
        $this->load->view('dashboard/footer'); 

       }


     public function view_cheakin(){

        $data['Checkin']=$this->Adminuser ->selectRecord('checkin_checkout', ['status'=>'1']);
        $this->load->view('dashboard/header');
        $this->load->view('dashboard/view_allcheakin',$data);
        $this->load->view('dashboard/footer'); 

       }

      public function view_cheakout(){

        $data['Checkin']=$this->Adminuser ->selectRecord('checkin_checkout', ['status'=>'2']);
        $this->load->view('dashboard/header');
        $this->load->view('dashboard/view_allcheakout',$data);
        $this->load->view('dashboard/footer'); 

       }

       
   
    public function update_status(){
       
          $id = $this->input->post('id');
          $this->form_validation->set_rules('status', 'Status', 'required');
          if($this->form_validation->run())
        
            {
            $status= $this->input->post('status');
            $updateArray = array(
            'status'=> $status,
            );

            $this->Adminuser->update_global_Record('checkin_checkout',$id,$updateArray);
            $this->session->set_flashdata('update','Cheakout Succcessfully .. ..!');
            redirect(base_url().'Admin/Add_room/view_cheakin');


          }
          else
          {
              echo "hello";
          }
        

       }
   

     public function get_appartment(){
        
        $buildingsids=$this->input->post('buildingsids');
        if(empty($buildingsids))
        {
          echo '<div class="col-md-12">No building is Selected </div>';
          die;
        }

           $html='';
           $buildingsids=explode(',', $buildingsids);
           foreach ($buildingsids as $key => $ids) {
          
          $floors=$this->db->get_where('apartment',['building_id'=>$ids])->result();
          if(!empty($floors))
          {
            foreach ($floors as $key => $value) {
                
              $floorName = get_field_value(' tbl_floor','floor_name',['id'=>$value->floor_id]);
              
              $sql="SELECT SUM(`bed_count`) as total FROM `checkin_checkout` WHERE `status`='1' AND `apartment_id`='".$value->id."'";
              $occupancy=$this->db->query($sql)->row_array();
              
              $sql="SELECT SUM(`bed_count`) as total FROM `checkin_checkout` WHERE `status`='4' AND `apartment_id`='".$value->id."'";
		      $reserved=$this->db->query($sql)->row_array();
		               
		               
              $sql="SELECT SUM(`total_bed`) as total FROM `room` WHERE `apartments`='".$value->id."'";
              $capacity=$this->db->query($sql)->row_array();
              
             $check_now=$capacity['total']-($occupancy['total']+ $reserved['total']);
                
               $html .=' <div class="col-xl-3 col-md-6 col-12"style="margin-top: 10px;">
                          <div class="white-box" style="text-align: center">
                              <div style="background: #89cff0;">
                              <p class="info-box-text" style="text-align: center;font-weight: 600;line-height: 60px;"> '.$floorName."&nbsp;/&nbsp;".$value->apartment.' <span></span></p>
                              </div>
                              <p class="info-box-text" style="color: #08417a;font-weight: 600;text-align: center;font-size: 14px;"> Total Capacity :  '.(!empty($capacity['total'])?$capacity['total']:'0').'<span></span></p>
                              <p class="info-box-text" style="color: #b60b0b;text-align: center;font-size: 14px;"> Occupied Beds : <span>'.(!empty($occupancy['total'])?$occupancy['total']:'0').'</span></p>
                              <p class="info-box-text" style="color: #eda061;text-align: center;font-size: 14px;"> Reserved Beds : <span>'.(!empty($reserved['total'])?$reserved['total']:'0').'</span></p>
                              <p class="info-box-text" style="color: #064b1a;text-align: center;font-size: 14px;"> Vacant Beds : <span>'.($capacity['total']-($occupancy['total']+ $reserved['total'])).'</span></p>
                              <div class="text-center">';
                              if($check_now>0){
                                $html .='<a class="btn btn-info" href="'.base_url().'Admin/Admin/checkIn/'.$value->id.'" style="margin:5px;font-size:10px" >Check In</a>';
                              }else{
                                $html .='<a class="btn btn-info" href="javascript:void(0);" style="margin:5px;font-size:10px">Fully Occupied</a>';  
                              }
                                $html .='<a class="btn" style="background-color:#ee8a0a;color:#ffff;font-size:10px" href="'.base_url().'Admin/View/checkIn/'.$value->id.'" >View</a>
                          </div>
                          </div>
                          <!-- /.info-box -->
                        </div>';
            }
          }

        }
        echo $html ;
        die;

      }


     // public function get_apartments(){
        
     //    $roomsids=$this->input->post('floorsids');
     //    if(empty($roomsids))
     //    {
     //      echo '<div class="col-md-12">No building is Selected </div>';
     //      die;
     //    }

     //    $html='';
     //    $roomsids=explode(',', $roomsids);
     //    foreach ($roomsids as $key => $ids) {
          
     //      $floors=$this->db->get_where('apartment',['floor_id'=>$ids])->result();


     //      if(!empty($floors))
     //      {
     //        foreach ($floors as $key => $value) {
     //           $html .='<div class="col-md-4">
     //           <div class="form-group form-check cus-form">
     //           <input type="radio" class="get_apartment" name="room" onclick="get_rooms();" id="" value="'. $value->id.'">'. $value->apartment.' 
     //           </div></div>';
     //        }
     //      }

     //    }
     //    echo $html ;
     //    die;

     //   }



      public function get_rooms(){
     
        $appartmentid=$this->input->post('appartmentid');
        if(empty($appartmentid))
        {
          echo '<div class="col-md-12">No building is Selected </div>';
          die;
        }

        $html='';
        $appartmentid=explode(',', $appartmentid);
        foreach ($appartmentid as $key => $ids) {
          
          $floors=$this->db->get_where('room',['apartments'=>$ids])->result();

          if(!empty($floors))
          {
            $occupancy = count($floors);
            foreach ($floors as $key => $value) {

              $sql="SELECT SUM(`bed_count`) as total FROM `checkin_checkout` WHERE `roomId`='".$value->id."' AND `status`='1'";
              $total_cheakin=$this->db->query($sql)->row_array();

             //print_r( $total_cheakin);

              $total_cheakin= !empty($total_cheakin)?$total_cheakin['total']:0;
              
            $total_cheakout=$this->db->get_where('checkin_checkout',['room_id'=>$value->id,'status'=>'2'])->result();
            $total_cheakout= !empty($total_cheakout)?count($total_cheakout):0;

    //            $html .='<div class="col-lg-3 col-md-6 col-12 col-sm-6">
    //   <div class="blogThumb">
    //     <div class="white-box">
    //       <p ><b>Room Number: '.$value->room_no.'</b> &nbsp; </p>
    //       <p class="m-t-20" style="color: red;">Book Bed:'.$total_cheakin.'<span style="color: blue;"> </span></p>
    //       <p class="m-t-20" style="color: green;">Available Bed:'.($value->total_bed-$total_cheakin).'<span style="color: blue;"> </span></p>
    //       <button class="btn btn-success btn-rounded waves-effect waves-light m-t-20" onclick="check_in_user('.$value->id.');">Cheak In</button>
    //     </div>
    //   </div>
    // </div>';


        $html .=' <div class="col-xl-3 col-md-6 col-12">
                <div class="info-box bg-blue">
                 
                  
                    <p class="info-box-text"> Total Capacity:  '.$occupancy.'<span></span></p>
                    <p class="info-box-text"> Room Number:  '.$value->room_no.'<span></span></p>
                    <p class="info-box-text"> Occupied Beds: <span>'.$total_cheakin.'</span></p>
                    <p class="info-box-text"> Vacant Beds: <span>'.($value->total_bed-$total_cheakin).'</span></p>
                   
                </div>
                <!-- /.info-box -->
       </div>';
            }
          }

        }
        echo $html ;
        die;


       }

   public function Checkin() {

       $this->form_validation->set_rules('custmer_name','Custmer_name','required');
       if ($this->form_validation->run() == FALSE) {
        $this->session->set_flashdata('info', 'Something Went to Wroung !');
        $this->load->view('dashboard/header');
        $this->load->view('dashboard/add_room');
        $this->load->view('dashboard/footer');

      // echo("hello");
    }else{
        
        $formArray= array();
        $formArray['roomId']=$this->input->post('roomId');
        $formArray['guest_id']=$this->input->post('guest_id');
        $formArray['custmer_name']=$this->input->post('custmer_name');
        $formArray['gender']=$this->input->post('gender');
        $formArray['contact_number']=$this->input->post('contact_number');
        $formArray['nationality']=$this->input->post('nationality');
        $formArray['civilid_number']=$this->input->post('civilid_number');
        $formArray['emergency_contact_number']=$this->input->post('emergency_contact_number');
        $formArray['emergency_contact_relationship']=$this->input->post('emergency_contact_relationship');
        $formArray['bed_count']=$this->input->post('bed_count');
        $formArray['roomId']=$this->input->post('roomId');
        $formArray['bed_count']=$this->input->post('bed_count');
        


        // print_r($formArray);
        // exit();

       
        $this->Adminuser->insert_Record('checkin_checkout',$formArray);
        $this->session->set_flashdata('success', 'Room Add Succcessfully !');
        redirect(base_url().'Admin/Add_user_room/viewallroom');
    }
  }



    public function add_room() {

     $this->form_validation->set_rules('floor_name','Floor_name','required');
     if ($this->form_validation->run() == FALSE) {
        $this->session->set_flashdata('info', 'Something Went to Wroung !');
        $this->load->view('dashboard/header');
        $this->load->view('dashboard/add_room');
        $this->load->view('dashboard/footer');

      // echo("hello");
    }else{
        
        $formArray= array();
        $formArray['building_name']=$this->input->post('building_name');
        $formArray['floor_name']=$this->input->post('floor_name');
        $formArray['apartments']=$this->input->post('apartments');
        $formArray['room_no']=$this->input->post('room_no');
        $formArray['total_bed']=$this->input->post('total_bed');
        
        $this->Adminuser->insert_Record('room',$formArray);
        $this->session->set_flashdata('success', 'Room Add Succcessfully !');
        redirect(base_url().'Admin/Add_room');
    }
  }
 

   public function update_room()
        {

          $id = $this->input->post('id');
          $this->form_validation->set_rules('building_name', 'Building_name', 'required');
          if($this->form_validation->run())
        
            {
             
             $building_name= $this->input->post('building_name');
             $floor_name= $this->input->post('floor_name');
             $apartments= $this->input->post('apartments');
             $room_no= $this->input->post('room_no');
             $total_bed= $this->input->post('total_bed');
             $status= $this->input->post('status');
           

            $updateArray = array(
            'building_name'=>$building_name, 
            'floor_name'=> $floor_name,
            'apartments'=> $apartments,
            'room_no'=> $room_no,
            'total_bed'=> $total_bed,
            'status'=> $status,
            
            );

            $this->Adminuser->update_global_Record('room',$id,$updateArray);
            $this->session->set_flashdata('update','Your details has been updated');
            redirect(base_url().'Admin/Add_room');


          }
          else
          {
              echo "hello";
          }
        }

        public function delete_product($id)
         {
          
         $this->Adminuser->delete_Record('tbl_product',$id);
         $this->session->set_flashdata('delete','Your details has been deleted');
         redirect(base_url().'Admin/Add_product/viewallproduct');

         }




}
 ?>