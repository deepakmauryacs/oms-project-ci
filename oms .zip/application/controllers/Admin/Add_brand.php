<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * 
 */

class Add_brand  extends CI_Controller 
{  
     function __construct()
  {
    parent::__construct();
    $this->load->model('Adminuser');
  }
   
    public function index(){
        
        $data['h']=$this->Adminuser ->select_Record('tbl_brand');
        $this->load->view('dashboard/header');
        $this->load->view('dashboard/add_brand',$data);
        $this->load->view('dashboard/footer');

    }


     

    public function add_brand() {

     $this->form_validation->set_rules('brand_name','Brand_name','required');
    if ($this->form_validation->run() == FALSE) {
      // $this->load->view(base_url().'Addcategory');
      echo("hello");
    }else{

        $formArray= array();
        $formArray['brand_name']=$this->input->post('brand_name');
        $this->Adminuser->insert_Record('tbl_brand',$formArray);
        $this->session->set_flashdata('success', 'Product Type Add Succcessfully !');
        redirect(base_url().'Admin/Add_brand');
    }
    
  }
 

   public function update_brand()
        {
           $id = $this->input->post('id');
          $this->form_validation->set_rules('brand_name', 'Brand_name', 'required');
 

          if($this->form_validation->run())
          {
           
            $brand_name = $this->input->post('brand_name');
            $updateArray = array('brand_name'=>$brand_name);
            $this->Adminuser->update_global_Record('tbl_brand',$id,$updateArray);
            $this->session->set_flashdata('update','Your details has been updated');
            redirect(base_url().'Admin/Add_brand');


          }
          else
          {
              echo "hello";
          }
        }

        public function delete_brand($id)
         {
          
         $this->Adminuser->delete_Record('tbl_brand',$id);
         $this->session->set_flashdata('delete','Your details has been deleted');
         redirect(base_url().'Admin/Add_brand');

         }





}
 ?>