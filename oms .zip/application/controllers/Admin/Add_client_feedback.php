<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * 
 */

class Add_client_feedback  extends CI_Controller 
{  
     function __construct()
  {
    parent::__construct();
    $this->load->model('Adminuser');
  }
   
    public function index(){
        
        $data['h']=$this->Adminuser ->select_Record('tbl_client_feedback');
        $this->load->view('dashboard/header');
        $this->load->view('dashboard/add_client_feedback',$data);
        $this->load->view('dashboard/footer');

    }




    public function add_client_feedback() {

     $this->form_validation->set_rules('description','Description','required');
    if ($this->form_validation->run() == FALSE) {
      // $this->load->view(base_url().'Addcategory');
      echo("hello");
    }else{

        $formArray= array();
        
         if($_FILES['image']['name'])
        {
            $config = array(
                'upload_path'=>'uploads/feedback',
                'allowed_types'=>'jpg|jpeg|gif|png',
                );
            $this->load->library('upload',$config);
            $this->upload->do_upload('image');
            $img=$this->upload->data();
            $formArray['image'] = $img['file_name'];
        }
       
        $formArray['description']=$this->input->post('description');
        $formArray['name']=$this->input->post('name');

        $this->Adminuser->insert_Record('tbl_client_feedback',$formArray);
        $this->session->set_flashdata('success', 'Client Feedback Add Succcessfully !');
        redirect(base_url().'Admin/Add_client_feedback');
    }
    
  }
 

   public function update__client_feedback()
        {
           $id = $this->input->post('id');
           $this->form_validation->set_rules('description', 'Description', 'required');
 

          if($this->form_validation->run())
          {
           
             $image = $this->input->post('oldImage');
             if($_FILES['image']['name']){ 

                if(file_exists("uploads/feedback".$image)){
                unlink("uploads/feedback".$image);
                  }
                $config = array(
                    'upload_path'=>'uploads/feedback',
                    'allowed_types'=>'jpg|jpeg|gif|png',
                    );
                $this->load->library('upload',$config);
                $this->upload->do_upload('image');
                $img=$this->upload->data();
                $image = $img['file_name'];
            }
        
            $description= $this->input->post('description');
            $name = $this->input->post('name');
            $updateArray = array('description'=>$description,'name'=>$name,'image'=>$image);
            $this->Adminuser->update_global_Record('tbl_client_feedback',$id,$updateArray);
            $this->session->set_flashdata('update','Your details has been updated');
            redirect(base_url().'Admin/Add_client_feedback');


          }
          else
          {
              echo "hello";
          }
        }

        public function delete_client_feedback($id)
         {

         $this->Adminuser->delete_Record('tbl_client_feedback',$id);
         $this->session->set_flashdata('delete','Your details has been deleted');
         redirect(base_url().'Admin/Add_client_feedback');

         }





}
 ?>