<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * 
 */

class Add_category  extends CI_Controller 
{  
     function __construct()
  {
    parent::__construct();
    $this->load->model('Adminuser');
  }
   
    public function index(){
        
        $data['h']=$this->Adminuser ->select_Record('tbl_product_category_name');
        $this->load->view('dashboard/header');
        $this->load->view('dashboard/add_product_category',$data);
        $this->load->view('dashboard/footer');

    }




    public function add_category() {

     $this->form_validation->set_rules('product_category_name','Product_category_name','required');
    if ($this->form_validation->run() == FALSE) {
      // $this->load->view(base_url().'Addcategory');
      echo("hello");
    }else{

        $formArray= array();
        
         if($_FILES['image']['name'])
        {
            $config = array(
                'upload_path'=>'uploads/category',
                'allowed_types'=>'jpg|jpeg|gif|png',
                );
            $this->load->library('upload',$config);
            $this->upload->do_upload('image');
            $img=$this->upload->data();
            $formArray['image'] = $img['file_name'];
        }
       
        $formArray['product_category_name']=$this->input->post('product_category_name');
        
        $this->Adminuser->insert_Record('tbl_product_category_name',$formArray);
        $this->session->set_flashdata('success', 'Product Category Add Succcessfully !');
        redirect(base_url().'Admin/Add_category');
    }
    
  }
 

   public function update_add_category()
        {
           $id = $this->input->post('id');
           $this->form_validation->set_rules('product_category_name', 'Product_category_name', 'required');
 

          if($this->form_validation->run())
          {
           
             $image = $this->input->post('oldImage');
             if($_FILES['image']['name']){
                unlink("uploads/category".$image);
                $config = array(
                    'upload_path'=>'uploads/category',
                    'allowed_types'=>'jpg|jpeg|gif|png',
                    );
                $this->load->library('upload',$config);
                $this->upload->do_upload('image');
                $img=$this->upload->data();
                $image = $img['file_name'];
            }
        
            $product_category_name= $this->input->post('product_category_name');
            $updateArray = array('product_category_name'=>$product_category_name,'image'=>$image);
            $this->Adminuser->update_global_Record('tbl_product_category_name',$id,$updateArray);
            $this->session->set_flashdata('update','Your details has been updated');
            redirect(base_url().'Admin/Add_category');


          }
          else
          {
              echo "hello";
          }
        }

        public function delete_add_category($id)
         {

         $this->Adminuser->delete_Record('tbl_product_category_name',$id);
         $this->session->set_flashdata('delete','Your details has been deleted');
         redirect(base_url().'Admin/Add_category');

         }





}
 ?>