<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 *  
 */

class Add_roomno  extends CI_Controller 
{  
     function __construct()
  {
    parent::__construct();
    $this->load->model('Adminuser');
  }
   
    public function index(){

  
        $data['building_name']=$this->Adminuser ->select_Record('tbl_building');
        $data['building_name']=$this->Adminuser ->select_Record('tbl_floor');
        $data['apartments']=$this->Adminuser ->select_Record('apartment');
        $data['rooms']=$this->Adminuser ->select_Record('room');
        $this->load->view('dashboard/header');
        $this->load->view('dashboard/add_room',$data);
        $this->load->view('dashboard/footer');

    }


     public function viewallroom(){
        
      

        $data['building']=$this->Adminuser->select_Record('tbl_building');
        $data['rooms']=$this->Adminuser->select_Record('room');
        $this->load->view('dashboard/header');
        $this->load->view('dashboard/view_allroom',$data);
        $this->load->view('dashboard/footer'); 

       }


         public function cheak_in(){
        
      
        $data['building']=$this->Adminuser->select_Record('tbl_building');
        $data['rooms']=$this->Adminuser->select_Record('room');
        $this->load->view('dashboard/header');
        $this->load->view('dashboard/cheak_in',$data);
        $this->load->view('dashboard/footer'); 

       }
     
     


     
       public function viewallguest(){
        
        $data['users']=$this->Adminuser->select_Record('checkin_checkout');
        $this->load->view('dashboard/header');
        $this->load->view('dashboard/view_allguest',$data);
        $this->load->view('dashboard/footer'); 

       }



     public function view_cheakin(){

        $data['cheakin']=$this->Adminuser ->selectRecord('checkin_checkout', ['status'=>'1']);
        $this->load->view('dashboard/header');
        $this->load->view('dashboard/view_allcheakin',$data);
        $this->load->view('dashboard/footer'); 

       }

      public function view_cheakout(){

        $data['cheakin']=$this->Adminuser ->selectRecord('checkin_checkout', ['status'=>'2']);
        $this->load->view('dashboard/header');
        $this->load->view('dashboard/view_allcheakout',$data);
        $this->load->view('dashboard/footer'); 

       }

       
   
    public function update_status(){
       
          $id = $this->input->post('id');
          $this->form_validation->set_rules('status', 'Status', 'required');
          if($this->form_validation->run())
        
            {
            $status= $this->input->post('status');
            $cheakout_date= $this->input->post('cheakout_date');
            $updateArray = array(
            'status'=> $status,
            'cheakout_date'=> $cheakout_date,
            );

            $this->Adminuser->update_global_Record('checkin_checkout',$id,$updateArray);
            $this->session->set_flashdata('update','Cheakout Succcessfully .. ..!');
            redirect(base_url().'Admin/Add_room/view_cheakin');


          }
          else
          {
              echo "hello";
          }
        

       }
   
        public function get_floors(){
        
       
          $buildingsids=$this->input->post('bilding_id');
          $html='<option value="">Select Floor</option>';   
          $floors=$this->db->get_where('tbl_floor',['building_id'=>$buildingsids])->result();
        
          if(!empty($floors))
          {
            foreach ($floors as $key => $value) {

                $html .='<option value="'. $value->id.'">'. $value->floor_name.'</option>';

               
            }
          }
        echo $html ;
        die;

       }


     public function get_apartment(){
        
        $floor_id=$this->input->post('floor_id');
        
        $html='<option value="">Select Apartment</option>';   
          
          $floors=$this->db->get_where('apartment',['floor_id'=>$floor_id])->result();
          if(!empty($floors))
          {
            foreach ($floors as $key => $value) {
               $html .='<option value="'. $value->id.'">'. $value->apartment.'</option>';
              
            }
          }
        echo $html ;
        die;

       }
       
       public function get_rooms(){
        
        $apartment_id=$this->input->post('apartment_id');
        
        $html='<option value="">Select Room</option>';   
        $rooms=$this->db->get_where('room',['apartments'=>$apartment_id])->result();
          //$new_rooms=[];
        foreach($rooms as $room)
        {
            $sql="SELECT COUNT(*) total FROM checkin_checkout WHERE apartment_id='".$apartment_id ."' AND roomId ='".$room->id."'";
            $row=$this->db->query($sql)->row();
            if($row->total<$room->total_bed)
            {
               $html .='<option value="'. $room->id.'">'. $room->room_no.'</option>';
            }
        }
          
        echo $html ;
        die;

       }


}
 ?>