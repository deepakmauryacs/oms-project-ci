<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * 
 */

class Add_apartment  extends CI_Controller 
{  
     function __construct()
  {
    parent::__construct();
    $this->load->model('Adminuser');
  }
   
    public function index(){

        $data['building_name']=$this->Adminuser ->select_Record('tbl_building');
        $data['floor_name']=$this->Adminuser ->select_Record('tbl_floor');
        $data['add_apartments']=$this->Adminuser ->select_Record('apartment');
        $this->load->view('dashboard/header');
        $this->load->view('dashboard/add_apartment',$data);
        $this->load->view('dashboard/footer');

   

    }




    public function add_apartment() {
     
    $this->form_validation->set_rules('building_name','building_name','required');
    if ($this->form_validation->run() == FALSE) {
        $this->session->set_flashdata('error', 'Something went Wroung !');
        $data['product_category']=$this->Adminuser ->select_Record('tbl_product_category_name');
        $data['sub_category']=$this->Adminuser ->select_Record('tbl_floor');
        $data['add_apartments']=$this->Adminuser ->select_Record('apartment');
        $this->load->view('dashboard/header');
        $this->load->view('dashboard/add_apartment',$data);
        $this->load->view('dashboard/footer');

      //echo("hello");
    }else{

        $formArray= array();
        $formArray['building_id']=$this->input->post('building_name');
        $formArray['floor_id']=$this->input->post('floor_name');
        $formArray['apartment']=$this->input->post('apartment');

        $this->Adminuser->insert_Record('apartment',$formArray);
        $this->session->set_flashdata('success', 'Apartment Add Succcessfully !');
        redirect(base_url().'Admin/Add_apartment');
    }
    
  }
 

   public function update_add_sub_category()
        {
           $id = $this->input->post('id');
           $this->form_validation->set_rules('building_id', 'building_id', 'required');
 

          if($this->form_validation->run())
          {
          
            $building_id= $this->input->post('building_id');
            $floor_name= $this->input->post('floor_name');
            $updateArray = array('building_id'=>$building_id, 'floor_name'=> $floor_name);

            $this->Adminuser->update_global_Record('tbl_floor',$id,$updateArray);
            $this->session->set_flashdata('update','Your details has been updated');
            redirect(base_url().'Admin/Add_sub_category');


          }
          else
          {
              echo "hello";
          }
        }

        public function delete_add_sub_category($id)
         {
          
         $this->Adminuser->delete_Record('apartment',$id);
         $this->session->set_flashdata('delete','Your details has been deleted');
         redirect(base_url().'Admin/Add_apartment');

         }





}
 ?>