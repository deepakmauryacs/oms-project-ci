<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * 
 */

class Add_user_room  extends CI_Controller 
{  
     function __construct()
  {
    parent::__construct();
    $this->load->model('Adminuser');
  }
   
    public function index(){

  
        $data['building_name']=$this->Adminuser ->select_Record('tbl_building');
        $data['building_name']=$this->Adminuser ->select_Record('tbl_floor');
        $data['apartments']=$this->Adminuser ->select_Record('apartment');
        $data['rooms']=$this->Adminuser ->select_Record('room');
        $this->load->view('dashboard/header');
        $this->load->view('dashboard/add_room',$data);
        $this->load->view('dashboard/footer');

    }


     public function viewallroom(){
        
      

        $data['building']=$this->Adminuser->select_Record('tbl_building');
        $data['rooms']=$this->Adminuser->select_Record('room');
        $this->load->view('dashboard/header');
        $this->load->view('dashboard/view_alluserroom',$data);
        $this->load->view('dashboard/footer'); 

       }

       public function viewallguest(){
        
        $data['users']=$this->Adminuser->select_Record('checkin_checkout');
        $this->load->view('dashboard/header');
        $this->load->view('dashboard/view_allguest',$data);
        $this->load->view('dashboard/footer'); 

       }



     public function view_cheakin(){

        $data['Checkin']=$this->Adminuser ->selectRecord('checkin_checkout', ['status'=>'1']);
        $this->load->view('dashboard/header');
        $this->load->view('dashboard/view_allcheakin',$data);
        $this->load->view('dashboard/footer'); 

       }

      public function view_cheakout(){

        $data['Checkin']=$this->Adminuser ->selectRecord('checkin_checkout', ['status'=>'2']);
        $this->load->view('dashboard/header');
        $this->load->view('dashboard/view_allcheakout',$data);
        $this->load->view('dashboard/footer'); 

       }

       
   
    public function update_status(){
       
          $id = $this->input->post('id');
          $this->form_validation->set_rules('status', 'Status', 'required');
          if($this->form_validation->run())
        
            {
            $status= $this->input->post('status');
            $updateArray = array(
            'status'=> $status,
            );

            $this->Adminuser->update_global_Record('checkin_checkout',$id,$updateArray);
            $this->session->set_flashdata('update','Cheakout Succcessfully .. ..!');
            redirect(base_url().'Admin/Add_room/view_cheakin');


          }
          else
          {
              echo "hello";
          }
        

       }
   

     public function get_floor(){
        
        $buildingsids=$this->input->post('buildingsids');
        if(empty($buildingsids))
        {
          echo '<div class="col-md-12">No building is Selected </div>';
          die;
        }

        $html='';
        $buildingsids=explode(',', $buildingsids);
        foreach ($buildingsids as $key => $ids) {
          
          $floors=$this->db->get_where('tbl_floor',['building_id'=>$ids])->result();
          if(!empty($floors))
          {
            foreach ($floors as $key => $value) {
               $html .='<div class="col-md-4"><input type="radio" onclick="get_apartments();" class="floors"  value="'. $value->id.'">'. $value->floor_name.' </div>';
            }
          }

        }
        echo $html ;
        die;

       }


     public function get_apartments(){
        
        $roomsids=$this->input->post('floorsids');
        if(empty($roomsids))
        {
          echo '<div class="col-md-12">No building is Selected </div>';
          die;
        }

        $html='';
        $roomsids=explode(',', $roomsids);
        foreach ($roomsids as $key => $ids) {
          
          $floors=$this->db->get_where('apartment',['floor_id'=>$ids])->result();


          if(!empty($floors))
          {
            foreach ($floors as $key => $value) {
               $html .='<div class="col-md-4"><input type="radio" class="get_apartment" onclick="get_rooms();" id="" value="'. $value->id.'">'. $value->apartment.' </div>';
            }
          }

        }
        echo $html ;
        die;

       }



      public function get_rooms(){
     
        $appartmentid=$this->input->post('appartmentid');
        if(empty($appartmentid))
        {
          echo '<div class="col-md-12">No building is Selected </div>';
          die;
        }

        $html='';
        $appartmentid=explode(',', $appartmentid);
        foreach ($appartmentid as $key => $ids) {
          
          $floors=$this->db->get_where('room',['apartments'=>$ids])->result();

          if(!empty($floors))
          {
            foreach ($floors as $key => $value) {

              $sql="SELECT SUM(`bed_count`) as total FROM `checkin_checkout` WHERE `roomId`='".$value->id."' AND `status`='1'";
              $total_cheakin=$this->db->query($sql)->row_array();

             //print_r( $total_cheakin);

              $total_cheakin= !empty($total_cheakin)?$total_cheakin['total']:0;
              
             // $total_cheakout=$this->db->get_where('checkin_checkout',['room_id'=>$value->id,'status'=>'2'])->result();
              //$total_cheakout= !empty($total_cheakout)?count($total_cheakout):0;

               $html .='<div class="col-lg-4 col-md-6 col-12 col-sm-4">
      <div class="blogThumb">
        <div class="white-box">
          <p ><b>Room Number: '.$value->room_no.'</b> &nbsp; </p>
          <p class="m-t-20" style="color: red;">Book Bed:'.$total_cheakin.'<span style="color: blue;"> </span></p>
          <p class="m-t-20" style="color: green;">Available Bed:'.($value->total_bed-$total_cheakin).'<span style="color: blue;"> </span></p>
          <button class="btn btn-success btn-rounded waves-effect waves-light m-t-20" onclick="check_in_user('.$value->id.');">Cheak In</button>
        </div>
      </div>
    </div>';
            }
          }

        }
        echo $html ;
        die;


       }

   public function Checkin() {

       $this->form_validation->set_rules('custmer_name','Custmer_name','required');
       if ($this->form_validation->run() == FALSE) {
        $this->session->set_flashdata('info', 'Something Went to Wroung !');
        $this->load->view('dashboard/header');
        $this->load->view('dashboard/add_room');
        $this->load->view('dashboard/footer');

      // echo("hello");
    }else{
        
        $formArray= array();
        $formArray['roomId']=$this->input->post('roomId');
        $formArray['guest_id']=$this->input->post('guest_id');
        $formArray['custmer_name']=$this->input->post('custmer_name');
        $formArray['gender']=$this->input->post('gender');
        $formArray['contact_number']=$this->input->post('contact_number');
        $formArray['nationality']=$this->input->post('nationality');
        $formArray['civilid_number']=$this->input->post('civilid_number');
        $formArray['emergency_contact_number']=$this->input->post('emergency_contact_number');
        $formArray['emergency_contact_relationship']=$this->input->post('emergency_contact_relationship');
        $formArray['bed_count']=$this->input->post('bed_count');
        $formArray['roomId']=$this->input->post('roomId');
        $formArray['bed_count']=$this->input->post('bed_count');
        


        // print_r($formArray);
        // exit();

       
        $this->Adminuser->insert_Record('checkin_checkout',$formArray);
        $this->session->set_flashdata('success', 'Room Add Succcessfully !');
        redirect(base_url().'Admin/Add_user_room/viewallroom');
    }
  }



    public function add_room() {

     $this->form_validation->set_rules('floor_name','Floor_name','required');
     if ($this->form_validation->run() == FALSE) {
        $this->session->set_flashdata('info', 'Something Went to Wroung !');
        $this->load->view('dashboard/header');
        $this->load->view('dashboard/add_room');
        $this->load->view('dashboard/footer');

      // echo("hello");
    }else{
        
        $formArray= array();
        $formArray['building_name']=$this->input->post('building_name');
        $formArray['floor_name']=$this->input->post('floor_name');
        $formArray['apartments']=$this->input->post('apartments');
        $formArray['room_no']=$this->input->post('room_no');
        $formArray['total_bed']=$this->input->post('total_bed');
        
        $this->Adminuser->insert_Record('room',$formArray);
        $this->session->set_flashdata('success', 'Room Add Succcessfully !');
        redirect(base_url().'Admin/Add_room');
    }
  }
 

   public function update_room()
        {

          $id = $this->input->post('id');
          $this->form_validation->set_rules('building_name', 'Building_name', 'required');
          if($this->form_validation->run())
        
            {
             
             $building_name= $this->input->post('building_name');
             $floor_name= $this->input->post('floor_name');
             $apartments= $this->input->post('apartments');
             $room_no= $this->input->post('room_no');
             $total_bed= $this->input->post('total_bed');
             $status= $this->input->post('status');
           

            $updateArray = array(
            'building_name'=>$building_name, 
            'floor_name'=> $floor_name,
            'apartments'=> $apartments,
            'room_no'=> $room_no,
            'total_bed'=> $total_bed,
            'status'=> $status,
            
            );

            $this->Adminuser->update_global_Record('room',$id,$updateArray);
            $this->session->set_flashdata('update','Your details has been updated');
            redirect(base_url().'Admin/Add_room');


          }
          else
          {
              echo "hello";
          }
        }

        public function delete_product($id)
         {
          
         $this->Adminuser->delete_Record('tbl_product',$id);
         $this->session->set_flashdata('delete','Your details has been deleted');
         redirect(base_url().'Admin/Add_product/viewallproduct');

         }




}
 ?>