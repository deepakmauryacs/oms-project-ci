<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * 
 */
class Add_slider  extends CI_Controller 
{  
     function __construct()
  {
    parent::__construct();
    $this->load->model('Adminuser');
  }
        public function index(){

        $data['h']=$this->Adminuser ->select_Record('tbl_slider');
        $this->load->view('dashboard/header');
        $this->load->view('dashboard/add_slider.php',$data);
        $this->load->view('dashboard/footer');
 }

     

    public function addslider() {

        $formArray= array();
        if($_FILES['image']['name'])
        {
            $config = array(
                'upload_path'=>'uploads/banner',
                'allowed_types'=>'jpg|jpeg|gif|png',
                );
            $this->load->library('upload',$config);
            $this->upload->do_upload('image');
            $img=$this->upload->data();
            $formArray['image'] = $img['file_name'];
        }

        $this->Adminuser->insert_Record('tbl_slider',$formArray);
        $this->session->set_flashdata('success', 'Banner Add Succcessfully.. !');
        redirect(base_url().'Admin/Add_slider');
    }
    
  
 

    public function update_slider()
          {

             $id = $this->input->post('id');
             $image = $this->input->post('oldImage');
             if($_FILES['image']['name']){
                unlink("uploads/banner".$image);
                $config = array(
                    'upload_path'=>'uploads/banner',
                    'allowed_types'=>'jpg|jpeg|gif|png',
                    );
                $this->load->library('upload',$config);
                $this->upload->do_upload('image');
                $img=$this->upload->data();
                $image = $img['file_name'];
            }

            $status = $this->input->post('status');
            $updateArray = array('status'=>$status,'image'=>$image);

            // print_r($updateArray);
            // die();

            $this->Adminuser->update_global_Record('tbl_slider',$id,$updateArray);
            $this->session->set_flashdata('update','Your details has been updated');
            redirect(base_url().'Admin/Add_slider');

          }
        

        public function delete_slider($id)
         {
          
         $this->Adminuser->delete_Record('tbl_slider',$id);
         $this->session->set_flashdata('delete','Your details has been deleted');
         redirect(base_url().'Admin/Add_slider');

         }





}
 ?>