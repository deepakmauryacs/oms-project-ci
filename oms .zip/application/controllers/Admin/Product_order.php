<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * 
 */

class Product_order  extends CI_Controller 
{  
     function __construct()
  {
    parent::__construct();
    $this->load->model('Adminuser');
  }
   
    public function view_order(){
        
        $data['h']=$this->Adminuser ->select_Record('tbl_product_order');
        $this->load->view('dashboard/header');
        $this->load->view('dashboard/view_allorder',$data);
        $this->load->view('dashboard/footer');
    }




    public function add_order() {

     $this->form_validation->set_rules('name','Name','required');
    if ($this->form_validation->run() == FALSE) {
      // $this->load->view(base_url().'Addcategory');
      echo("hello");
    }else{

        $formArray= array();
       
        $formArray['product_id']=$this->input->post('product_id');
        $formArray['product_name']=$this->input->post('product_name');
        $formArray['name']=$this->input->post('name');
        $formArray['email']=$this->input->post('email');
        $formArray['contact']=$this->input->post('contact');
        $formArray['address']=$this->input->post('address');

        
        $this->Adminuser->insert_Record('tbl_product_order',$formArray);
        $this->session->set_flashdata('success', 'Your Product Order  Succcessfully !');
        redirect(base_url().'Web/shop_list');
    }
    
  }
 

   // public function update_order()
   //      {
   //         $id = $this->input->post('id');
   //         $this->form_validation->set_rules('product_category_name', 'Product_category_name', 'required');
 

   //        if($this->form_validation->run())
   //        {
           
   //           $image = $this->input->post('oldImage');
   //           if($_FILES['image']['name']){
   //              unlink("uploads/category".$image);
   //              $config = array(
   //                  'upload_path'=>'uploads/category',
   //                  'allowed_types'=>'jpg|jpeg|gif|png',
   //                  );
   //              $this->load->library('upload',$config);
   //              $this->upload->do_upload('image');
   //              $img=$this->upload->data();
   //              $image = $img['file_name'];
   //          }
        
   //          $product_category_name= $this->input->post('product_category_name');
   //          $updateArray = array('product_category_name'=>$product_category_name,'image'=>$image);
   //          $this->Adminuser->update_global_Record('tbl_product_category_name',$id,$updateArray);
   //          $this->session->set_flashdata('update','Your details has been updated');
   //          redirect(base_url().'Admin/Add_category');


   //        }
   //        else
   //        {
   //            echo "hello";
   //        }
   //      }

        public function delete_order($id)
         {

         $this->Adminuser->delete_Record('tbl_product_order',$id);
         $this->session->set_flashdata('delete','Your details has been deleted');
         redirect(base_url().'Admin/Product_order/view_order');

         }





}
 ?>