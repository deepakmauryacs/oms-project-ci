<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * 
 */
class Contact  extends CI_Controller 
{  
     function __construct()
  {
    parent::__construct();
    $this->load->model('Adminuser');
  }


     public function index(){
        $data['h']=$this->Adminuser ->select_Record('tbl_contact');
        $this->load->view('dashboard/header');
        $this->load->view('dashboard/viewall_contact',$data);
        $this->load->view('dashboard/footer'); 
       }

    public function subscribed()
       {

        $data['h']=$this->Adminuser ->select_Record('tbl_subscribe');
        $this->load->view('dashboard/header');
        $this->load->view('dashboard/viewall_sbscribe',$data);
        $this->load->view('dashboard/footer');
         
       }

   
    public function add_contact() {

    $this->form_validation->set_rules('name', 'Name', 'required');
    $this->form_validation->set_rules('contact', 'Contact', 'required');
    $this->form_validation->set_rules('email', 'Email', 'required');
    $this->form_validation->set_rules('message', 'Message', 'required');


    if ($this->form_validation->run() == FALSE) {

            $this->load->view('header');
            $this->load->view('contact');
            $this->load->view('footer');

      // echo "hello";
      // exit();
      
       }else{

        $formArray= array();
        $formArray['name']=$this->input->post('name');
        $formArray['contact']=$this->input->post('contact');
        $formArray['email']=$this->input->post('email');
        $formArray['message']=$this->input->post('message');
        

        // print_r($formArray);
        // exit();
        $this->Adminuser->insert_Record('tbl_contact',$formArray);
        $this->session->set_flashdata('success', 'Thank Yor Contac Us. Our Team will be response soon....!');
        redirect(base_url().'Web/contact');
    }
    
  }



        public function delete_contact($id)
         {
          
         $this->Adminuser->delete_Record('tbl_contact',$id);
         $this->session->set_flashdata('delete','Your details has been deleted');
         redirect(base_url().'Admin/Contact');

         }





}
 ?>
