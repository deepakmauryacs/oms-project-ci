<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * 
 */
class Add_privacy_policy  extends CI_Controller 
{  
      function __construct()
  {
    parent::__construct();
    $this->load->model('Adminuser');
  }

    public function index(){
    
        $data['h']=$this->Adminuser ->select_Record('tbl_privacy_policy');
        $this->load->view('dashboard/header');
        $this->load->view('dashboard/privacy_policy',$data);
        $this->load->view('dashboard/footer');
                  }
   
    public function update_privacy_policy()
           {
             $id = $this->input->post('id');
   
            $description = $this->input->post('description');
            $updateArray = array('description'=>$description);

             // print_r($id);
             // die();

            $this->Adminuser->update_global_Record('tbl_privacy_policy',$id,$updateArray);
            $this->session->set_flashdata('update','Your details has been updated');
            redirect(base_url().'Admin/Add_privacy_policy');

          }

}
?>